import javax.swing.*;

public class BoxTeste extends JFrame {

    public BoxTeste() {
        super("Teste com BoxLayout");
        JPanel p1 = new JPanel();
        p1.setLayout(new BoxLayout(p1,
                BoxLayout.X_AXIS));
        JPanel p2 = new JPanel();
        p2.setLayout(new BoxLayout(p2,
                BoxLayout.X_AXIS));
        JPanel p3 = new JPanel();
        p3.setLayout(new BoxLayout(p3,
                BoxLayout.Y_AXIS));
        p2.setAlignmentX(0.5f);
        JButton b1 = new JButton("TOP-LEFT");
        b1.setAlignmentX(0.5f);
        JButton b2 = new JButton("TOP-RIGHT");
        b2.setAlignmentX(0.5f);
        JButton b3 = new JButton("BOTTOM-LEFT");
        b3.setAlignmentY(0.5f);
        JButton b4 = new JButton("BOTTOM-RIGHT");
        b4.setAlignmentY(0.5f);
        p1.add(b1);
        p1.add(Box.createHorizontalGlue());
        p1.add(b2);
        p2.add(b3);
        p2.add(Box.createHorizontalGlue());
        p2.add(b4);
        p3.add(p1);
        p3.add(Box.createVerticalGlue());
        p3.add(p2);
        add(p3);
        setSize(300, 170);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String atgs[]){
        BoxTeste b = new BoxTeste();
    }
}
