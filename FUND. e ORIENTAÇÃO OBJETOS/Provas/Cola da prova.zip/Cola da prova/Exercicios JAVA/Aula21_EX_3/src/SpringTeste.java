
import java.awt.*;
import javax.swing.*;

public class SpringTeste extends JFrame {

    public SpringTeste() {
        super("SpringLayout teste");
        String[] labels = {"Nome: ", "Endereço: ", "Telefone: ", "E-mail: "};
        int numPairs = labels.length;

        JPanel p = new JPanel(new SpringLayout());
        for (int i = 0; i < numPairs; i++) {
            JLabel l = new JLabel(labels[i], JLabel.TRAILING);
            p.add(l);
            JTextField textField = new JTextField(10);
            l.setLabelFor(textField);
            p.add(textField);
        }

        SpringUtilities.makeCompactGrid(p,
                numPairs, 2, //rows, cols
                6, 6, //initX, initY
                6, 6);       //xPad, yPad
        this.setVisible(true);
    }

    public static void main(String args[]) {
        SpringTeste s = new SpringTeste();
    }
}
