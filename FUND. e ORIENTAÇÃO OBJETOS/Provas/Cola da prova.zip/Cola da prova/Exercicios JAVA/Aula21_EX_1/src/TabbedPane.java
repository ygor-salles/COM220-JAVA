import javax.swing.*;

public class TabbedPane extends JFrame {

    private final String BUTTON_PANEL = "JPanel with JButtons";
    private final String TEXT_PANEL = "JPanel with JTextField";

    public TabbedPane() {
        JPanel p1 = new JPanel();
        p1.add(new JButton("Button 1"));
        p1.add(new JButton("Button 2"));
        p1.add(new JButton("Button 3"));
        JPanel p2 = new JPanel();
        p2.add(new JTextField("TextField", 20));
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab(BUTTON_PANEL, p1);
        tabbedPane.addTab(TEXT_PANEL, p2);
        this.add(tabbedPane);
        this.setSize(400, 170);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String args[]){
        TabbedPane t = new TabbedPane();
    }

}
