package prova1si;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class LimiteVenda {

    ControleVenda control;

    public LimiteVenda(ControleVenda c) {
        this.control = c;
        capturaDados();
    }

    private void capturaDados() {
        int escolha;
        do {
            do {
                escolha = Integer.parseInt(JOptionPane.showInputDialog(
                        "Escolha uma opção do menu:\n"
                        + "[1] Registrar Venda\n"
                        + "[2] Inserir Item Venda\n"
                        + "[3] Calculo Total vendido e Total Pago em impostos\n"
                        + "[4] Impressão da Nota\n"
                        + "[5] Finalizar"));
            } while ((escolha < 1) || (escolha > 5));
            if (escolha != 5) {
                execEscolha(escolha);
            } else {
                System.exit(0);
            }
        } while (true);
    }

    private void execEscolha(int escolha) {
        switch (escolha) {
            case 1:
                registrarVenda();
                break;
            case 2:
                inserirItemVenda();
                break;
            case 3:
                calculosTotais();
                break;
            case 4:
                imprimeNF();
                break;
            case 5:
                System.exit(0);
                break;
        }
    }

    private void registrarVenda() {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date data_convertida = null;
        boolean achou = false;

        try {
            int tipo = Integer.parseInt(JOptionPane.showInputDialog("Escolha o tipo de pessoa para realizar a venda:\n[1] Pessoa Física\n[2] Pessoa Jurídica"));
            int nroNF = Integer.parseInt(JOptionPane.showInputDialog("Informe o número da Nota Fiscal:"));
            String data = JOptionPane.showInputDialog("Informe a data de emissão da nota:");

            try {
                data_convertida = new java.sql.Date(format.parse(data).getTime());
            } catch (ParseException ex) {
            }

            if (tipo == 1) {
                String nome = JOptionPane.showInputDialog("Informe o nome da pessoa Física:");
                String cpf = JOptionPane.showInputDialog("Informe o cpf:");
                achou = control.inserirVendaPF(nroNF, data_convertida, cpf, nome);
            } else if (tipo == 2) {
                String nomeFantasia = JOptionPane.showInputDialog("Informe o nome da Fantasia:");
                String cnpj = JOptionPane.showInputDialog("Informe o cnpj:");
                achou = control.inserirVendaPJ(nroNF, data_convertida, cnpj, nomeFantasia);
            }

            if (achou == true) {
                JOptionPane.showMessageDialog(null, "Esse número de nota fiscal [" + nroNF + "] já existe.", "ERRO!", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception exc) {
            JOptionPane.showMessageDialog(null, exc.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void inserirItemVenda() {
        boolean achou = false;
        try {
            int nroNF = Integer.parseInt(JOptionPane.showInputDialog("Informe o número da Nota Fiscal:"));
            int codProd = Integer.parseInt(JOptionPane.showInputDialog("Informe o código do produto:"));
            double preco = Double.parseDouble(JOptionPane.showInputDialog("Informe o preço do produto:"));
            int qnt = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade do produto:"));
            achou = control.insereItemVenda(nroNF, codProd, qnt, preco);
            if (achou == false) {
                JOptionPane.showMessageDialog(null, "Esse número de nota fiscal [" + nroNF + "] não existe.", "ERRO!", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception exc) {
            JOptionPane.showMessageDialog(null, exc.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void calculosTotais() {
        JOptionPane.showMessageDialog(null,
                "Pessoa Física\nTotal Vendido: " + control.totalVendidoPF() + "\nTotal pago em impostos: " + control.totalImpostoPF() + "\nPessoa Jurídica\nTotal Vendido: " + control.totalVendidoPJ() + "\nTotal pago em impostos: " + control.totalImpostoPJ(), "Calculos Totais", JOptionPane.INFORMATION_MESSAGE);
    }

    private void imprimeNF() {
        int nroNF = Integer.parseInt(JOptionPane.showInputDialog("Informe o número da Nota Fiscal:"));
        JOptionPane.showMessageDialog(null, control.imprimeNF(nroNF), "Impressão nota Fiscal", JOptionPane.INFORMATION_MESSAGE);
    }
}
