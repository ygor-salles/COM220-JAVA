package prova1si;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public abstract class Venda {

    private int nroNota;
    private Date dataEmissao;
    private Vector itemVenda = new Vector();

    public Venda(int nroNota, Date dataEmissao) throws Exception {
        this.nroNota = nroNota;
        setDataEmissao(dataEmissao);
    }

    public abstract String geraNF();

    public abstract double calculoTotalVendido();

    public abstract double calculoImposto();

    public void adicionaItem(int codigoProduto, int qtd, double precoUnit) throws Exception {
        ItemVenda iv = new ItemVenda(codigoProduto, qtd, precoUnit);
        itemVenda.add(iv);
    }

    public void setDataEmissao(Date dataEmissao) throws Exception {
        Date data = new Date();
        SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
        formatador.format(data);
        Date minhaData = formatador.parse("01/01/2000");
        if ((dataEmissao.after(data)) || (dataEmissao.before(minhaData))) {
            throw new Exception( "A data deve estar entre 01/01/2000 e a data de hoje");
        }
        this.dataEmissao = dataEmissao;
    }

    public void setItemVenda(Vector itemVenda) {
        this.itemVenda = itemVenda;
    }

    public Date getDataEmissao() {
        return dataEmissao;
    }

    public Vector<ItemVenda> getItemVenda() {
        return itemVenda;
    }

    public int getNroNota() {
        return nroNota;
    }
}