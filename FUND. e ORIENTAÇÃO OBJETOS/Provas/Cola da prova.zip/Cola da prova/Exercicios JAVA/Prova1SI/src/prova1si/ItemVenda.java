package prova1si;

public class ItemVenda {

    private int codigoProduto, quantidade;
    private double precoUnit;

    public ItemVenda(int codigoProduto, int quantidade, double precoUnit) throws Exception {
        this.codigoProduto = codigoProduto;
        setQuantidade(quantidade);
        this.precoUnit = precoUnit;
    }

    public void setCodigoProduto(int codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public void setPrecoUnit(double precoUnit) {
        this.precoUnit = precoUnit;
    }

    public void setQuantidade(int quantidade) throws Exception {
        if ((quantidade < 1) || (quantidade > 20)) {
            throw new Exception("A quantidade deve estar entre 1 e 20.");
        }
        this.quantidade = quantidade;
    }

    public int getCodigoProduto() {
        return codigoProduto;
    }

    public double getPrecoUnit() {
        return precoUnit;
    }

    public int getQuantidade() {
        return quantidade;
    }
}
