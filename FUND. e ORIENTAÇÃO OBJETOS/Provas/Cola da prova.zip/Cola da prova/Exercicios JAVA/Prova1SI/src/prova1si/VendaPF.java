package prova1si;

import java.util.Date;

public class VendaPF extends Venda {

    String cpf, nome;

    public VendaPF(int nroNota, Date dataEmissao, String cpf, String nome) throws Exception {
        super(nroNota, dataEmissao);
        this.cpf = cpf;
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String geraNF() {
        String itens = "";
        String info = "";
        String fim = "";
        String result = "";
        for (int i = 0; i < getItemVenda().size(); i++) {
            ItemVenda iv = getItemVenda().elementAt(i);
            info = "Número Nota Fiscal: " + getNroNota()
                    + "\nData Emissão: " + getDataEmissao()
                    + "\nNome: " + getNome()
                    + "\nCPF: " + getCpf();
            itens += "\nCódigo Produto: " + iv.getCodigoProduto()
                    + "\nQuantidade: " + iv.getQuantidade()
                    + "\nValor: " + iv.getPrecoUnit()
                    + "\nTotal: " + (iv.getQuantidade() * iv.getPrecoUnit());
            fim = "\nTotal Vendido: " + this.calculoTotalVendido()
                    + "\nTotal Impostos: " + this.calculoImposto()
                    + "\nTotal da Venda: " + (this.calculoImposto() + this.calculoTotalVendido());
        }
        result = info + itens + fim;
        return result;
    }

    @Override
    public double calculoTotalVendido() {
        double totalVendido = 0;
        for (int i = 0; i < getItemVenda().size(); i++) {
            ItemVenda iv = getItemVenda().elementAt(i);
            totalVendido += iv.getPrecoUnit() * iv.getQuantidade();
        }
        return totalVendido;
    }

    @Override
    public double calculoImposto() {
        double totalVendido = 0;
        for (int i = 0; i < getItemVenda().size(); i++) {
            ItemVenda iv = getItemVenda().elementAt(i);
            totalVendido += iv.getPrecoUnit() * iv.getQuantidade();
        }
        return totalVendido * 0.07;
    }
}