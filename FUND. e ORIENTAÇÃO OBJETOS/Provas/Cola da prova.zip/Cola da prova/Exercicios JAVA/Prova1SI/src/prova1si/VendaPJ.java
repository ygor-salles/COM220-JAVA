package prova1si;

import java.util.Date;

public class VendaPJ extends Venda {

    String cnpj, nomeFantasia;

    public VendaPJ(int nroNota, Date dataEmissao, String cnpj, String nomeFantasia) throws Exception {
        super(nroNota, dataEmissao);
        this.cnpj = cnpj;
        this.nomeFantasia = nomeFantasia;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getCnpj() {
        return cnpj;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    @Override
    public String geraNF() {
        String itens = "";
        String info = "";
        String fim = "";
        String result = "";
        for (int i = 0; i < getItemVenda().size(); i++) {
            ItemVenda iv = getItemVenda().elementAt(i);
            info = "Número Nota Fiscal: " + getNroNota()
                    + "\nData Emissão: " + getDataEmissao()
                    + "\nNome Fantasia: " + getNomeFantasia()
                    + "\nCNPJ: " + getCnpj();
            itens += "\nCódigo Produto: " + iv.getCodigoProduto()
                    + "\nQuantidade: " + iv.getQuantidade()
                    + "\nValor: " + iv.getPrecoUnit()
                    + "\nTotal: " + (iv.getQuantidade() * iv.getPrecoUnit());
            fim = "\nTotal Vendido: " + this.calculoTotalVendido()
                    + "\nTotal Impostos: " + this.calculoImposto()
                    + "\nTotal da Venda: " + (this.calculoImposto() + this.calculoTotalVendido());
        }
        result = info + itens + fim;
        return result;
    }

    @Override
    public double calculoTotalVendido() {
        double totalVendido = 0;
        for (int i = 0; i < getItemVenda().size(); i++) {
            ItemVenda iv = getItemVenda().elementAt(i);
            totalVendido += iv.getPrecoUnit() * iv.getQuantidade();
        }
        return totalVendido;
    }

    @Override
    public double calculoImposto() {
        double totalVendido = 0;
        for (int i = 0; i < getItemVenda().size(); i++) {
            ItemVenda iv = getItemVenda().elementAt(i);
            totalVendido += iv.getPrecoUnit() * iv.getQuantidade();
        }
        return totalVendido * 0.05;
    }
}
