package prova1si;

public class Prova1SI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new ControleVenda();
    }
}
