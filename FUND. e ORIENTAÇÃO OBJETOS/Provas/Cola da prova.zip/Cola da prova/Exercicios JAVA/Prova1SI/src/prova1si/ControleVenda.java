package prova1si;

import java.util.ArrayList;
import java.util.Date;

public class ControleVenda {

    private LimiteVenda limite;
    ArrayList<Venda> vetor = new ArrayList<Venda>();

    public ControleVenda() {
        limite = new LimiteVenda(this);
    }

    public boolean inserirVendaPF(int nroNF, Date data, String cpf, String nome) throws Exception {
        boolean achou = false;
        for (Venda v : vetor) {
            if (v.getNroNota() == nroNF) {
                achou = true;
            }
        }
        if (achou == false) {
            VendaPF vendaPF = new VendaPF(nroNF, data, cpf, nome);
            vetor.add(vendaPF);
        }
        return achou;
    }

    public boolean inserirVendaPJ(int nroNF, Date data, String cnpj, String nomeFantasia) throws Exception {
        boolean achou = false;
        for (Venda v : vetor) {
            if (v.getNroNota() == nroNF) {
                achou = true;
            }
        }
        if (achou == false) {
            VendaPJ vendaPJ = new VendaPJ(nroNF, data, cnpj, nomeFantasia);
            vetor.add(vendaPJ);
        }
        return achou;
    }

    public boolean insereItemVenda(int nroNF, int codProd, int qnt, double precoUnit) throws Exception {
        boolean achou = false;
        for (Venda v : vetor) {
            if (v.getNroNota() == nroNF) {
                v.adicionaItem(codProd, qnt, precoUnit);
                achou = true;
            }
        }
        return achou;
    }

    public double totalVendidoPF() {
        double result = 0;
        for (Venda v : vetor) {
            if (v instanceof VendaPF) {
                result = v.calculoTotalVendido();
            }
        }
        return result;
    }

    public double totalVendidoPJ() {
        double result = 0;
        for (Venda v : vetor) {
            if (v instanceof VendaPJ) {
                result = v.calculoTotalVendido();
            }
        }
        return result;
    }

    public double totalImpostoPF() {
        double result = 0;
        for (Venda v : vetor) {
            if (v instanceof VendaPF) {
                result = v.calculoImposto();
            }
        }
        return result;
    }

    public double totalImpostoPJ() {
        double result = 0;
        for (Venda v : vetor) {
            if (v instanceof VendaPJ) {
                result = v.calculoImposto();
            }
        }
        return result;
    }

    public String imprimeNF(int nroNF) {
        String result = "";
        for (Venda v : vetor) {
            if (v.getNroNota() == nroNF) {
                result = v.geraNF();
            }
        }
        return result;
    }
}