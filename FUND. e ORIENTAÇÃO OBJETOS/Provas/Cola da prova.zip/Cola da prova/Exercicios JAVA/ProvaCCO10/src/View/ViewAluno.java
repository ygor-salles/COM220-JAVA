package View;

import Control.ControlAluno;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ViewAluno extends JFrame implements ActionListener, ListSelectionListener {

    ControlAluno control;
    private JPanel cards;
    private JButton bCadastraAluno;
    private JButton bConsultarAluno;
    private JPanel janelaPrincipal;
    private JTextField codigo;
    private JTextField nome;
    private JTextField dt_nasc;
    private JButton bCadastraProximo;
    private JTextField nomePai;
    private JTextField nomeMae;
    private JButton bCadastraProximo2;
    private JButton bFinalizar;
    private JTextField cidade;
    private JTextField endereco;
    private JComboBox estado;
    private DefaultListModel listaDinamica;
    private JList listaAluno;

    public ViewAluno(ControlAluno control) {
        this.control = control;
    }

    public void gerarInterface() {

        /* Cards */
        cards = new JPanel();
        cards.setLayout(new CardLayout());
        cards.add("Principal", geraSobre());
        cards.add("CadastraAluno", gerarP1());
        cards.add("NomePais", gerarP2());
        cards.add("Endereco", gerarP3());
        cards.add("ConsultarAluno", gerarP4());

        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.EAST;
        gc.insets = new Insets(0, 3, 0, 0);
        gc.gridwidth = 1;
        gc.gridheight = 1;

        JPanel principal = new JPanel(grid);
        gc.gridx = 0;
        gc.gridy = 0;
        principal.add(bCadastraAluno = new JButton("Cadastrar Aluno"), gc);
        bCadastraAluno.addActionListener(this);
        gc.gridx = 1;
        gc.gridy = 0;
        principal.add(bConsultarAluno = new JButton("Consultar Aluno"), gc);
        bConsultarAluno.addActionListener(this);

        janelaPrincipal = new JPanel(new BorderLayout());
        janelaPrincipal.add(principal, BorderLayout.PAGE_START);
        janelaPrincipal.add(cards, BorderLayout.CENTER);

        getContentPane().add(janelaPrincipal);
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Cadastramento de Alunos");
        setVisible(true);
    }

    public JPanel geraSobre() {
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.EAST;
        gc.insets = new Insets(0, 0, 0, 0);
        gc.gridwidth = 1;
        gc.gridheight = 1;

        JPanel sobre = new JPanel(grid);

        gc.gridx = 0;
        gc.gridy = 0;
        sobre.add(new JLabel("Aluno: André Mack Nardy - 17298"), gc);

        gc.gridx = 0;
        gc.gridy = 1;
        sobre.add(new JLabel("Curso: Sistemas de Informação"), gc);

        return sobre;
    }

    public JPanel gerarP1() {
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.EAST;
        gc.insets = new Insets(0, 3, 3, 0);
        gc.gridwidth = 1;
        gc.gridheight = 1;

        JPanel p1 = new JPanel(grid);

        gc.gridx = 0;
        gc.gridy = 0;
        p1.add(new JLabel("Código:"), gc);
        gc.gridx = 1;
        gc.gridy = 0;
        p1.add(codigo = new JTextField(3), gc);
        gc.gridx = 0;
        gc.gridy = 1;
        p1.add(new JLabel("Nome:"), gc);
        gc.gridx = 1;
        gc.gridy = 1;
        p1.add(nome = new JTextField(8), gc);
        gc.gridx = 0;
        gc.gridy = 2;
        p1.add(new JLabel("Dt. Nascimento:"), gc);
        gc.gridx = 1;
        gc.gridy = 2;
        p1.add(dt_nasc = new JTextField(5), gc);
        gc.gridx = 1;
        gc.gridy = 3;
        p1.add(bCadastraProximo = new JButton("Próximo"), gc);
        bCadastraProximo.addActionListener(this);

        return p1;
    }

    public JPanel gerarP2() {
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.EAST;
        gc.insets = new Insets(0, 3, 3, 0);
        gc.gridwidth = 1;
        gc.gridheight = 1;

        JPanel p2 = new JPanel(grid);

        gc.gridx = 0;
        gc.gridy = 0;
        p2.add(new JLabel("Nome mãe:"), gc);
        gc.gridx = 1;
        gc.gridy = 0;
        p2.add(nomeMae = new JTextField(8), gc);
        gc.gridx = 0;
        gc.gridy = 1;
        p2.add(new JLabel("Nome pai:"), gc);
        gc.gridx = 1;
        gc.gridy = 1;
        p2.add(nomePai = new JTextField(8), gc);
        gc.gridx = 1;
        gc.gridy = 2;
        p2.add(bCadastraProximo2 = new JButton("Próximo"), gc);
        bCadastraProximo2.addActionListener(this);

        return p2;
    }

    public JPanel gerarP3() {
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.EAST;
        gc.insets = new Insets(0, 3, 3, 0);
        gc.gridwidth = 1;
        gc.gridheight = 1;

        JPanel p3 = new JPanel(grid);

        gc.gridx = 0;
        gc.gridy = 0;
        p3.add(new JLabel("Rua/Número:"), gc);
        gc.gridx = 1;
        gc.gridy = 0;
        p3.add(endereco = new JTextField(8), gc);
        gc.gridx = 0;
        gc.gridy = 1;
        p3.add(new JLabel("Cidade:"), gc);
        gc.gridx = 1;
        gc.gridy = 1;
        p3.add(cidade = new JTextField(8), gc);
        gc.gridx = 0;
        gc.gridy = 2;
        p3.add(new JLabel("Estado:"), gc);
        gc.gridx = 1;
        gc.gridy = 2;
        p3.add(estado = new JComboBox(), gc);
        estado.addItem("SP");
        estado.addItem("MG");
        estado.addItem("RJ");
        gc.gridx = 1;
        gc.gridy = 3;
        p3.add(bFinalizar = new JButton("Finalizar"), gc);
        bFinalizar.addActionListener(this);

        return p3;
    }

    public JPanel gerarP4() {
        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.EAST;
        gc.insets = new Insets(0, 3, 3, 0);
        gc.gridwidth = 1;
        gc.gridheight = 1;

        JPanel p4 = new JPanel(grid);

        gc.gridx = 0;
        gc.gridy = 0;

        listaDinamica = new DefaultListModel();

        p4.add(listaAluno = new JList(listaDinamica), gc);
        listaAluno.addListSelectionListener(this);
        listaAluno.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        return p4;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        CardLayout layout = (CardLayout) cards.getLayout();
        int idade = 0;
        if (ae.getSource() == bConsultarAluno) {
            layout.show(cards, "ConsultarAluno");
            listaDinamica.removeAllElements();
            for (String item : control.listaAlunos()) {
                listaDinamica.addElement(item);
            }
        } else if (ae.getSource() == bCadastraAluno) {
            layout.show(cards, "CadastraAluno");
        } else if (ae.getSource() == bCadastraProximo) {
            // VALIDAR DATA AQUI
            idade = calcIdade(dt_nasc.getText());
            if (idade > 18) {
                layout.show(cards, "Endereco");
            } else {
                layout.show(cards, "NomePais");
            }
        } else if (ae.getSource() == bCadastraProximo2) {
            layout.show(cards, "Endereco");
        } else if (ae.getSource() == bFinalizar) {
            try {
                control.cadastraAluno(codigo.getText(), nome.getText(), dt_nasc.getText(), nomePai.getText(), nomeMae.getText(), endereco.getText(), cidade.getText(), estado.getSelectedItem().toString());
                JOptionPane.showMessageDialog(null, "Aluno cadastrado com sucesso!!");
                codigo.setText("");
                nome.setText("");
                dt_nasc.setText("");
                nomePai.setText("");
                nomeMae.setText("");
                endereco.setText("");
                cidade.setText("");
                layout.show(cards, "CadastraAluno");
            } catch (SQLException ex) {
                switch (ex.getErrorCode()) {
                    case 1062: // Violação chave primária
                        JOptionPane.showMessageDialog(null, ex.getMessage(), "Escolha outro código!!", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 1064:
                        JOptionPane.showMessageDialog(null, ex.getMessage(), "Não é permitido deixar campos em branco!!", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 1054:
                        JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro! Dado inválido!!", JOptionPane.ERROR_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro!!", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    public int calcIdade(String dataNasc) {
        Date hoje = new Date();
        Calendar cal = Calendar.getInstance();

        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date dt_nasc = null;
        try {
            dt_nasc = new java.sql.Date(format.parse(dataNasc).getTime());
        } catch (ParseException ex) {
            Logger.getLogger(ViewAluno.class.getName()).log(Level.SEVERE, null, ex);
        }

        cal.setTime(hoje);
        int day1 = cal.get(Calendar.DAY_OF_YEAR);
        int ano1 = cal.get(Calendar.YEAR);

        cal.setTime(dt_nasc);
        int day2 = cal.get(Calendar.DAY_OF_YEAR);
        int ano2 = cal.get(Calendar.YEAR);

        int nAno = ano1 - ano2;

        if (day1 < day2) {
            nAno--; //Ainda não completou aniversario esse ano.    
        }
        return nAno;
    }

    @Override
    public void valueChanged(ListSelectionEvent lse) {
        if (lse.getSource() == listaAluno) {
            if (lse.getValueIsAdjusting()) {
                return;
            }
            JList list = (JList) lse.getSource();
            if (list.isSelectionEmpty()) {
            } else {
                JOptionPane.showMessageDialog(null, control.consultaAluno((listaAluno.getSelectedIndex() + 1)));
            }
        }
    }
}