package provacco10;

import Control.ControlAluno;

public class ProvaCCO10 {

    public static void main(String[] args) {
        new ControlAluno();
    }
}
