package Control;

import View.ViewAluno;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

public class ControlAluno {

    private ViewAluno view;
    private Statement stmt;

    public ControlAluno() {
        this.view = new ViewAluno(this);
        view.gerarInterface();
        conectarBanco();
    }

    public void conectarBanco() {
        String hostname, database, user, pass;
        hostname = "localhost";
        database = "cadastraAluno";
        user = "root";
        pass = "comcs46ak";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c;
            c = (Connection) DriverManager.getConnection("jdbc:mysql://" + hostname + "/"
                    + database, user, pass);
            stmt = c.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Aplicativo não conectado ao banco" + " de dados.");
        }
    }

    public void cadastraAluno(String codigo, String nome, String dt_nasc, String nome_pai, String nome_mae, String endereco, String cidade, String estado) throws SQLException {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        Date dtNasc = null;
        try {
            dtNasc = new java.sql.Date(format.parse(dt_nasc).getTime());
        } catch (ParseException ex) {
        }
        stmt.executeUpdate("INSERT INTO Aluno VALUES ('" + codigo + "','" + nome + "','" + dtNasc + "','" + nome_pai + "','" + nome_mae + "','" + endereco + "','" + cidade + "','" + estado + "');");
    }

    public ArrayList<String> listaAlunos() {
        ArrayList<String> dados = new ArrayList<String>();
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery("SELECT codigo,nome FROM Aluno;");
            while (rs.next()) {
                dados.add(rs.getObject(1).toString() + " - " + rs.getObject(2).toString());
            }
        } catch (Exception ex) {
            throw new RuntimeException("Problemas no BD", ex);
        }
        return dados;
    }

    public String consultaAluno(int codigo) {
        ResultSet rs;
        String result = "";
        try {
            rs = stmt.executeQuery("SELECT * FROM Aluno where codigo='"+ codigo + "'");
            while (rs.next()) {
                result += ("Codigo: " + rs.getObject(1).toString()
                        + "\nNome: " + rs.getObject(2).toString()
                        + "\nDt. Nasc: " + rs.getObject(3).toString()
                        + "\nNome Pai: " + rs.getObject(4).toString()
                        + "\nNome Mãe: " + rs.getObject(5).toString()
                        + "\nEndereço: " + rs.getObject(6).toString()
                        + "\nCidade: " + rs.getObject(7).toString()
                        + "\nEstado: " + rs.getObject(8).toString());
            }
        } catch (SQLException ex) {
        }
        return result;
    }
}
