package prova1cco;

public class PontoFunc {

    private int mes, ano, nroFaltas, nroAtrasos;

    public PontoFunc(int mes, int ano) throws Exception {
        setMes(mes);
        setAno(ano);
    }

    public PontoFunc(int mes, int ano, int nroFaltas, int nroAtrasos) {
        this.mes = mes;
        this.ano = ano;
        this.nroFaltas = nroFaltas;
        this.nroAtrasos = nroAtrasos;
    }

    public void setAno(int ano) throws Exception {
        if ((ano < 1990) || (ano > 2011)) {
            throw new Exception("O ano deve estar entre 1990 e 2011.");
        }
        this.ano = ano;
    }

    public void setMes(int mes) throws Exception {
        if ((mes < 1) || (mes > 12)) {
            throw new Exception("O mês deve estar entre 1 e 12.");
        }
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public int getMes() {
        return mes;
    }

    public int getNroAtrasos() {
        return nroAtrasos;
    }

    public int getNroFaltas() {
        return nroFaltas;
    }

    public void lancarFaltas(int faltas) {
        this.nroFaltas += faltas;
    }

    public void lancarAtrasos(int atrasos) {
        this.nroAtrasos += atrasos;
    }
}
