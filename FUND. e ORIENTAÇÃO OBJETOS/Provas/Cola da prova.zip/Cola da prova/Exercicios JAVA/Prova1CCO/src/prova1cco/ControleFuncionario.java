package prova1cco;

import java.util.ArrayList;

public class ControleFuncionario {

    private limiteFuncionario limite;
    ArrayList<Funcionario> vetor = new ArrayList<Funcionario>();

    public ControleFuncionario() {
        limite = new limiteFuncionario(this);
    }

    public void insereProfessor(int codigo, String nome, String titulacao, double salarioHora, int nroAulas) {
        Professor professor = new Professor(codigo, nome, titulacao, salarioHora, nroAulas);
        vetor.add(professor);
    }

    public void insereTecAdm(int codigo, String nome, String funcao, double salarioMensal) {
        TecAdmin tecAdmin = new TecAdmin(codigo, nome, funcao, salarioMensal);
        vetor.add(tecAdmin);
    }

    public void inserePontoMensal(int codigo, int mes, int ano) throws Exception {
        for (Funcionario f : vetor) {
            if (f.getCodigo() == codigo) {
                f.adicionaPonto(mes, ano);
            }
        }
    }

    public void lancarFaltas(int codigo, int mes, int ano, int faltas) {
        for (Funcionario f : vetor) {
            if (f.getCodigo() == codigo) {
                f.lancaFaltas(mes, ano, faltas);
            }
        }
    }

    public void lancarAtrasos(int codigo, int mes, int ano, int atrasos) {
        for (Funcionario f : vetor) {
            if (f.getCodigo() == codigo) {
                f.lancaAtrasos(mes, ano, atrasos);
            }
        }
    }

    public String imprimirFolha(int codigo, int mesInicial, int anoInicial, int mesFinal, int anoFinal) {
        String result = "";
        for (Funcionario f : vetor) {
            PontoFunc pf = new PontoFunc(mesFinal, anoFinal);
            if (f.getCodigo() == codigo) {
                if (mesInicial == pf.getMes())
                result = f.imprimeFolha(mes, ano);
            }
        }
        return result;
    }
}
