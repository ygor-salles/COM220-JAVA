package prova1cco;

public class TecAdmin extends Funcionario {

    String funcao;
    double salarioMensal;

    public TecAdmin(int codigo, String nome, String funcao, double salarioMensal) {
        super(codigo, nome);
        this.funcao = funcao;
        this.salarioMensal = salarioMensal;
    }

    @Override
    public double calculaSalario(int pMes, int pAno) {
        double salarioTec = 0;
        for (int i = 0; i < getPontoMensal().size(); i++) {
            PontoFunc pf = getPontoMensal().elementAt(i);
            if ((pMes == pf.getMes()) && (pAno == pf.getAno())) {
                salarioTec = salarioMensal - ((salarioMensal / 30) * pf.getNroFaltas());
            }
        }
        return salarioTec;
    }

    @Override
    public double calculaBonus(int pMes, int pAno) {
        double bonusTec = 0;
        for (int i = 0; i < getPontoMensal().size(); i++) {
            PontoFunc pf = getPontoMensal().elementAt(i);
            if ((pMes == pf.getMes()) && (pAno == pf.getAno())) {
                double calculo = (8 - pf.getNroAtrasos());
                bonusTec = calculaSalario(pMes, pAno) * (calculo / 100);
            }
        }
        return bonusTec;
    }
}