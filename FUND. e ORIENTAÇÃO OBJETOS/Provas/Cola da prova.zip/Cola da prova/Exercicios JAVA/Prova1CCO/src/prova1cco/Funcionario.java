package prova1cco;

import java.util.Vector;

public abstract class Funcionario {

    private int codigo;
    private String nome;
    private Vector pontoMensal = new Vector();

    public Funcionario(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    public Vector<PontoFunc> getPontoMensal() {
        return pontoMensal;
    }

    public void adicionaPonto(int pMes, int pAno) throws Exception {
        PontoFunc pf = new PontoFunc(pMes, pAno);
        pontoMensal.add(pf);
    }

    public void lancaFaltas(int pMes, int pAno, int pFaltas) {
        for (int i = 0; i < pontoMensal.size(); i++) {
            PontoFunc pf = (PontoFunc) pontoMensal.elementAt(i);
            if ((pMes == pf.getMes()) && (pAno == pf.getAno())) {
                ((PontoFunc) pontoMensal.elementAt(i)).lancarFaltas(pFaltas);
            }
        }
    }

    public void lancaAtrasos(int pMes, int pAno, int pAtrasos) {
        for (int i = 0; i < pontoMensal.size(); i++) {
            PontoFunc pf = (PontoFunc) pontoMensal.elementAt(i);
            if ((pMes == pf.getMes()) && (pAno == pf.getAno())) {
                ((PontoFunc) pontoMensal.elementAt(i)).lancarAtrasos(pAtrasos);
            }
        }
    }

    public String imprimeFolha(int pMes, int pAno) {
        String result = "";
        for (int i = 0; i < pontoMensal.size(); i++) {
            PontoFunc pf = (PontoFunc) pontoMensal.elementAt(i);
            if ((pMes == pf.getMes()) && (pAno == pf.getAno())) {
                result += "Nome: " + nome
                        + "\nCódigo: " + codigo
                        + "\nSalario: " + calculaSalario(pMes, pAno)
                        + "\nBonus: " + calculaBonus(pMes, pAno);
            }
        }
        return result;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public abstract double calculaSalario(int pMes, int pAno);

    public abstract double calculaBonus(int pMes, int pAno);
}
