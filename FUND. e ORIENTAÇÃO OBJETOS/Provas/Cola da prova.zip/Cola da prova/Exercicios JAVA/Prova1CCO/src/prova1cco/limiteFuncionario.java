package prova1cco;

import javax.swing.JOptionPane;

public class limiteFuncionario {

    ControleFuncionario control;

    public limiteFuncionario(ControleFuncionario c) {
        this.control = c;
        capturaDados();
    }

    public void capturaDados() {
        int escolha;
        do {
            do {
                escolha = Integer.parseInt(JOptionPane.showInputDialog(
                        "Escolha uma opção do menu:\n"
                        + "[1] Inserir Funcionario\n"
                        + "[2] Inserir Ponto Mensal\n"
                        + "[3] Lançar Faltas\n"
                        + "[4] Lançar Atrasos\n"
                        + "[5] Gasto de um funcionáio num Periodo\n"
                        + "[5] Gasto total num Periodo\n"
                        + "[6] Finalizar"));
            } while ((escolha < 1) || (escolha > 6));
            if (escolha != 6) {
                execEscolha(escolha);
            } else {
                System.exit(0);
            }
        } while (true);
    }

    private void execEscolha(int escolha) {
        switch (escolha) {
            case 1:
                inserirFuncionario();
                break;
            case 2:
                inserirPontoMensal();
                break;
            case 3:
                lancarFaltas();
                break;
            case 4:
                lancarAtrasos();
                break;
            case 5:
                gastoFunc();
                break;
            case 6:
                System.exit(0);
                break;
        }
    }

    private void inserirFuncionario() {
        String nome, titulacao, funcao;
        double salarioHora, salarioMensal;
        int tipo = Integer.parseInt(JOptionPane.showInputDialog("Escolha o funcionário que deseja inserir:\n[1] Professor\n[2] Técnico Administrativo"));
        int codigo = Integer.parseInt(JOptionPane.showInputDialog("Informe o código:"));
        nome = JOptionPane.showInputDialog("Informe o nome:");
        if (tipo == 1) {
            titulacao = JOptionPane.showInputDialog("Informe a titulação:");
            salarioHora = Double.parseDouble(JOptionPane.showInputDialog("Informe o sálario:"));
            int nroAulas = Integer.parseInt(JOptionPane.showInputDialog("Informe o número de aulas:"));
            control.insereProfessor(codigo, nome, titulacao, salarioHora, nroAulas);
        } else {
            funcao = JOptionPane.showInputDialog("Informe a função:");
            salarioMensal = Double.parseDouble(JOptionPane.showInputDialog("Informe o sálario:"));
            control.insereTecAdm(codigo, nome, funcao, salarioMensal);
        }
    }

    private void inserirPontoMensal() {
        try {
            int codigoFunc = Integer.parseInt(JOptionPane.showInputDialog("Informe o código do funcionário:"));
            int mes = Integer.parseInt(JOptionPane.showInputDialog("Informe o mês:"));
            int ano = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano:"));
            control.inserePontoMensal(codigoFunc, mes, ano);
        } catch (Exception exc) {
            JOptionPane.showMessageDialog(null, exc.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void lancarFaltas() {
        int codigoFunc = Integer.parseInt(JOptionPane.showInputDialog("Informe o código do funcionário:"));
        int mes = Integer.parseInt(JOptionPane.showInputDialog("Informe o mês:"));
        int ano = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano:"));
        int nroFaltas = Integer.parseInt(JOptionPane.showInputDialog("Informe o número de faltas:"));
        control.lancarFaltas(codigoFunc, mes, ano, nroFaltas);
    }

    private void lancarAtrasos() {
        int codigoFunc = Integer.parseInt(JOptionPane.showInputDialog("Informe o código do funcionário:"));
        int mes = Integer.parseInt(JOptionPane.showInputDialog("Informe o mês:"));
        int ano = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano:"));
        int nroAtrasos = Integer.parseInt(JOptionPane.showInputDialog("Informe o número de atrasos:"));
        control.lancarAtrasos(codigoFunc, mes, ano, nroAtrasos);
    }

    private void gastoFunc() {
        int codigoFunc = Integer.parseInt(JOptionPane.showInputDialog("Informe o código do funcionário:"));
        int mesInicio = Integer.parseInt(JOptionPane.showInputDialog("Informe o mês inicial:"));
        int anoInicio = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano inicial:"));
        int mesFinal = Integer.parseInt(JOptionPane.showInputDialog("Informe o mês final:"));
        int anoFinal = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano final:"));
        JOptionPane.showMessageDialog(null, control.imprimirFolha(codigoFunc, mes, ano), "Folha de Pagamento", JOptionPane.INFORMATION_MESSAGE);
    }
}