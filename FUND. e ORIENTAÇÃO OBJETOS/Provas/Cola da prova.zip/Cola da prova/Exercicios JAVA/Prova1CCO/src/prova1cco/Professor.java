package prova1cco;

public class Professor extends Funcionario {

    private String titulacao;
    private double salarioHora;
    private int nroAulas;

    public Professor(int codigo, String nome, String titulacao, double salarioHora, int nroAulas) {
        super(codigo, nome);
        this.titulacao = titulacao;
        this.salarioHora = salarioHora;
        this.nroAulas = nroAulas;
    }

    @Override
    public double calculaSalario(int pMes, int pAno) {
        double salarioProf = 0;
        for (int i = 0; i < getPontoMensal().size(); i++) {
            PontoFunc pf = getPontoMensal().elementAt(i);
            if ((pMes == pf.getMes()) && (pAno == pf.getAno())) {
                salarioProf = ((salarioHora * nroAulas) - salarioHora) * pf.getNroFaltas();
            }
        }
        return salarioProf;
    }

    @Override
    public double calculaBonus(int pMes, int pAno) {
        double bonusProf = 0;
        for (int i = 0; i < getPontoMensal().size(); i++) {
            PontoFunc pf = getPontoMensal().elementAt(i);
            if ((pMes == pf.getMes()) && (pAno == pf.getAno())) {
                double calculo = 10 - pf.getNroAtrasos();
                bonusProf = (calculaSalario(pMes, pAno) * (calculo/100));
            }
        }
        return bonusProf;
    }
}