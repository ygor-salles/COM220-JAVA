package prova1cco;

public class Prova1CCO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new ControleFuncionario();
    }
}
