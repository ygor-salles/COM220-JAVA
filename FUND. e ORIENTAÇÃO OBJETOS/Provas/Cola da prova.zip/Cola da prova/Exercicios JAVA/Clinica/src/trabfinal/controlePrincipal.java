
package trabfinal;


public class controlePrincipal {
    private limitePrincipal limPrincipal;
    private controleFuncionarios ctrFuncionarios;
    private ControlePaciente ctrPaciente;
    private LimiteAtendente limAtendente;
    private ControleMedico ctrMedico;
    private ControleConsulta ctrConsulta;
    private ControleRealizConsulta ctrRealizaConsulta;
       
    
    public controlePrincipal(){
        limPrincipal = new limitePrincipal(this);
        ctrFuncionarios = new controleFuncionarios(this);
        ctrPaciente = new ControlePaciente(this);
        ctrConsulta = new ControleConsulta(this);
        ctrMedico = new ControleMedico(this);
        ctrRealizaConsulta = new ControleRealizConsulta(this);
    }

    public ControleConsulta getCtrConsulta() {
        return ctrConsulta;
    }
    
    public ControleMedico getCtrMedico() {
        return ctrMedico;
    }
    
    public controleFuncionarios getCtrFuncionarios() {
        return ctrFuncionarios;
    }
    public ControlePaciente getCtrPaciente(){
        return ctrPaciente;
    }

    public LimiteAtendente getLimatendente() {
        return limAtendente;
    }

    public ControleRealizConsulta getCtrRealizaConsulta() {
        return ctrRealizaConsulta;
    }
    
    public void limAte(){
        new LimiteAtendente(this);
    }
    
    
}
