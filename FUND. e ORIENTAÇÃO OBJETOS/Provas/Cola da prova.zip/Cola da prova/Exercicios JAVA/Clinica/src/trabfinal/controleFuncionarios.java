package trabfinal;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class controleFuncionarios {

    private ArrayList<funcionarios> listafuncionarios = new ArrayList<>();
    private String arquivo = "func.dat";
    private controlePrincipal ctrPrincipal;
    private String sessao;

    public controleFuncionarios(controlePrincipal pctrPrincipal) {
        try {
            recuperaFuncionarios();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
        ctrPrincipal = pctrPrincipal;
    }

    public void AddFuncionarios(String pnome, String pnumFuncional, String pfuncao,
            String pusuario, String psenha) throws Exception {

        listafuncionarios.add(new funcionarios(pnome, pnumFuncional, pfuncao,
                pusuario, psenha));
        gravaFuncionarios();
    }

    public String getSessao() {
        return sessao;
    }

    
    public funcionarios getLFuncionario(String nfun){
        for(funcionarios fu : listafuncionarios){
            if(fu.getNumFuncional().equals(nfun))
            {
                return fu;
            }
        }
        return null;
    }

    public controlePrincipal getCtrPrincipal() {
        return ctrPrincipal;
    }

    public void criaFuncionarios() {
        new limiteFuncionario(this);
    }
    public void LimAgenda(){
        new LimiteImpressaoAg(this);
    }
    public funcionarios buscarFunc(String pusuario, String psenha) {

        for (funcionarios f : listafuncionarios) {
            if (f instanceof funcionarios) {
                if (f.getUsuario().equals(pusuario)) {
                    if (f.getSenha().equals(psenha)) {
                        sessao = f.getNumFuncional();
                        return f;
                    }else{
                        JOptionPane.showMessageDialog(null, "senha errada!");
                    }
                }
            }
        }
        return null;
    }

    public void gravaFuncionarios() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream(arquivo);
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listafuncionarios);
        objOS.flush();
        objOS.close();
    }

    public void recuperaFuncionarios() throws Exception {
        File objFile = new File(arquivo);
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream(arquivo);
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listafuncionarios = (ArrayList) objIS.readObject();
            objIS.close();
        }
    }

}
