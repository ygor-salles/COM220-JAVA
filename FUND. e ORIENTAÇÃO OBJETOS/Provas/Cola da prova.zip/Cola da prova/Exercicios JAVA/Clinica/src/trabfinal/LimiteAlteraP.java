package trabfinal;

import java.awt.*;
import java.awt.event.*;
import static java.lang.Integer.parseInt;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class LimiteAlteraP extends JFrame implements ActionListener {

    ControlePaciente ctrPaciente;
    JTextField txtNome;
    JTextField txtnSus;
    JTextField txttelefone;
    JTextField txtend;
    JTextField dataaniversario;
    Date data =null;
    String[] pSexo = {"MASCULINO", "FEMININO"};
    JComboBox cb1 = new JComboBox(pSexo);
    JButton cad, cad1;

    public LimiteAlteraP(ControlePaciente pctrPaciente) {
        super("Alterar dados Paciente");
        ctrPaciente = pctrPaciente;
        //painel principal
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(3, 1));
        //PAINEL COM O CAMPOS DE NOME, DATA, NUMERO
        //PAINEL COM GRIDBAG
        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());
        painel.setBackground(Color.white);
        p.add(painel);
        //cria o GridBag
        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 5, 3, 2);

        //LABEL NUMERO SUS
        gbc.gridx = 0; //coluna
        gbc.gridy = 0; //linha
        JLabel label2 = new JLabel("Nº SUS: ");
        label2.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label2, gbc);

        //TXT NUMERO SUS
        gbc.gridx = 1; //coluna
        gbc.gridy = 0; //linha
        txtnSus = new JTextField(20);
        painel.add(txtnSus, gbc);

        //COMBO SEXO
        gbc.gridx = 2; //coluna
        gbc.gridy = 1; //linha
        JLabel labe = new JLabel("Sexo: ");
        labe.setFont(new Font("SansSerif", Font.BOLD, 14));
        painel.add(labe, gbc);
        gbc.gridx = 3; //coluna
        gbc.gridy = 1; //linha
        painel.add(cb1, gbc);

        //LABEL NOME
        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        JLabel label = new JLabel("Nome: ");
        label.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label, gbc);// label adicionado no p1 qe tbm vai ter  o txtlogin

        //TXT NOME
        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        txtNome = new JTextField(20);
        painel.add(txtNome, gbc);

        //LABEL DATA NASCIMENTO
        gbc.gridx = 2; //coluna
        gbc.gridy = 2; //linha
        JLabel label4 = new JLabel("Data Nasci.: ");
        label4.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label4, gbc);
        //txt data nasc
        gbc.gridx = 3;
        gbc.gridy = 2; //linha
        dataaniversario = new JTextField(12);
        painel.add(dataaniversario, gbc);

        //botao buscar
        gbc.gridx = 2; //coluna
        gbc.gridy = 0; //linha
        cad = new JButton("Buscar");
        cad.addActionListener(this);
        painel.add(cad, gbc);

        //PAINEL COM UMA BORDA, ONDE ESTA OS CAMPOS DE ENDERECO
        JPanel painelend = new JPanel();
        painelend.setBackground(Color.white);
        painelend.setLayout(new FlowLayout());
        painelend.setBorder(BorderFactory.createTitledBorder("Endereco"));
        painelend.add(new JLabel("Endereco:"));
        txtend = new JTextField(20);
        painelend.add(txtend);
        painelend.add(new JLabel("Telefone:"));
        txttelefone = new JTextField(10);
        painelend.add(txttelefone);
        p.add(painelend);

        //PAINEL ONDE ESTA O BOTAO
        JPanel Painelbotao1 = new JPanel();
        Painelbotao1.setBackground(Color.white);
        cad1 = new JButton("Alterar");
        cad1.addActionListener(this);
        Painelbotao1.add(cad1);
        p.add(Painelbotao1);

        add(p);
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == cad) {
            for (Paciente p : ctrPaciente.getListapacientes()) {
                if (p.getnSus() == parseInt(txtnSus.getText())) {
                    
                    DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
                    String dt = df.format(p.getDataAniver());
                    System.out.println(dt);
                    txtNome.setText(p.getNome());
                    cb1.setSelectedItem(p.getSexo());
                    dataaniversario.setText(dt);
                    txtend.setText(p.getEndereco());
                    txttelefone.setText(p.getTelefone());
                    txtNome.setEnabled(false);
                    cb1.setEnabled(false);
                    dataaniversario.setEnabled(false);
                    txtnSus.setEnabled(false);
                }
            }
        } else if (e.getSource() == cad1) {
            try {
                ctrPaciente.alterarPaciente(parseInt(txtnSus.getText()), txtend.getText(), txttelefone.getText());
                JOptionPane.showMessageDialog(null, "Dado alterado com sucesso!");
                txtNome.setText("");
                txtnSus.setText("");
                txtend.setText("");
                txttelefone.setText("");
                dataaniversario.setText("");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
