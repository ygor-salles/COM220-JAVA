package trabfinal;

import java.io.Serializable;
import java.util.Date;

public class RealizaConsulta implements Serializable {
    private String queixas;
    private String resumoex;
    private Date consulta;
    private String resumoDiag;
    private String tratamentCon;
    private int nroSus;
    
    public RealizaConsulta(){
        
    }

    public RealizaConsulta(String pqueixas, String presumoex, String presumoDiag, 
                                String ptratamentCon, int pnroSus) {
        queixas = pqueixas;
        resumoex = presumoex;
        resumoDiag = presumoDiag;
        tratamentCon = ptratamentCon;
        nroSus = pnroSus;
        consulta = new Date();
    }
    
    

    public String getQueixas() {
        return queixas;
    }

    public void setQueixas(String queixas) {
        this.queixas = queixas;
    }

    public String getResumoex() {
        return resumoex;
    }

    public void setResumoex(String resumoex) {
        this.resumoex = resumoex;
    }

    public String getResumoDiag() {
        return resumoDiag;
    }

    public void setResumoDiag(String resumoDiag) {
        this.resumoDiag = resumoDiag;
    }

    public String getTratamentCon() {
        return tratamentCon;
    }

    public void setTratamentCon(String tratamentCon) {
        this.tratamentCon = tratamentCon;
    }

    public int getNroSus() {
        return nroSus;
    }

    public void setNroSus(int nroSus) {
        this.nroSus = nroSus;
    }

    
    
    
    
}
