package trabfinal;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LimiteAtendente extends JFrame implements ActionListener {

    controlePrincipal ctrPrincipal;

    public LimiteAtendente(controlePrincipal pctrPrincipal) {
        super("ATENDENTE");
        ctrPrincipal = pctrPrincipal;

        //painel principal
        JPanel painel = new JPanel();
        painel.setLayout(new BorderLayout());
        painel.setBackground(Color.white);

        JMenuBar mb = new JMenuBar();
        mb.setBackground(Color.white);
        JMenu m = new JMenu("Paciente", true);
        mb.add(m);

        JMenuItem menuCria = new JMenuItem("Registrar dados", new ImageIcon("paci.gif"));
        menuCria.setMnemonic(KeyEvent.VK_R);
        menuCria.setBackground(Color.white);
        menuCria.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ctrPrincipal.getCtrPaciente().addPaciente();
            }

        });
        m.add(menuCria);

        JMenuItem menuAlterar = new JMenuItem("Alterar dados", new ImageIcon("alterar.gif"));
        menuAlterar.setMnemonic(KeyEvent.VK_A);
        menuAlterar.setBackground(Color.white);
        menuAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ctrPrincipal.getCtrPaciente().altPaciente();
            }
        });
        m.add(menuAlterar);

        JMenuItem menuBuscar = new JMenuItem("Buscar", new ImageIcon("buscar.gif"));
        menuBuscar.setMnemonic(KeyEvent.VK_B);
        menuBuscar.setBackground(Color.white);
        menuBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ctrPrincipal.getCtrPaciente().BuscP();
            }
        });
        m.add(menuBuscar);

        JMenuItem menuHist = new JMenuItem("Historico ", new ImageIcon("histo.gif"));
        menuHist.setMnemonic(KeyEvent.VK_O);
        menuHist.setBackground(Color.white);
        menuHist.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ctrPrincipal.getCtrPaciente().SistemadeInfo();
            }
        });
        m.add(menuHist);

        JMenuItem menuObito = new JMenuItem("Registrar Obito", new ImageIcon("obito.gif"));
        menuObito.setMnemonic(KeyEvent.VK_O);
        menuObito.setBackground(Color.white);
        menuObito.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ctrPrincipal.getCtrPaciente().ObtoPaciente();
            }
        });
        m.add(menuObito);

        ///menu agenda
        JMenu ma = new JMenu("Agenda", true);
        mb.add(ma);
        JMenuItem menuIm = new JMenuItem("Impressao Agenda", new ImageIcon("agenda.gif"));
        menuIm.setMnemonic(KeyEvent.VK_M);//TECLA DE ATALHO
        menuIm.setBackground(Color.white);
        menuIm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ctrPrincipal.getCtrFuncionarios().LimAgenda();
            }
        });
        ma.add(menuIm);

        ///menu Consulta
        JMenu mm = new JMenu("Consulta", true);
        mb.add(mm);
        JMenuItem menuMar = new JMenuItem("Marcar Consulta", new ImageIcon("calendar_1_.gif"));
        menuMar.setMnemonic(KeyEvent.VK_M);//TECLA DE ATALHO
        menuMar.setBackground(Color.white);
        menuMar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ctrPrincipal.getCtrConsulta().LimCons();
            }
        });
        mm.add(menuMar);
        JMenuItem menuCan = new JMenuItem("Cancelar Consulta", new ImageIcon("altcon.gif"));
        menuCan.setMnemonic(KeyEvent.VK_L);//TECLA DE ATALHO
        menuCan.setBackground(Color.white);
        menuCan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ctrPrincipal.getCtrConsulta().CancelaConsulta();
            }
        });
        mm.add(menuCan);

        JPanel imagem = new JPanel();
        imagem.setBackground(Color.white);
        JLabel image = new JLabel(new ImageIcon("LogoClinic.gif"));
        imagem.add(image);
        

        painel.add(mb, BorderLayout.PAGE_START);
        painel.add(imagem, BorderLayout.CENTER);
        this.add(painel);
        this.setSize(450, 300);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
