package trabfinal;

import java.io.Serializable;
import java.util.Date;


/**
 *
 * @author Samantha
 */
public class Paciente implements Serializable {
    private String nome, sexo, endereco, telefone;
    private Date dataAniver;
    private int nSus;
    private ObitoPaciente obito;
    private int vida;

    public Paciente(String pnome, String psexo,Date pdataAniver, String pendereco, String ptelefone, int pnSus) {
        
        nome = pnome;
        sexo = psexo;
        dataAniver = pdataAniver;
        endereco = pendereco;
        telefone = ptelefone;
        nSus = pnSus;
        vida = 1;
    }
    
    
    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Date getDataAniver() {
        return dataAniver;
    }

    public void setDataAniver(Date dataAniver) {
        this.dataAniver = dataAniver;
    }

   
   
    public String getNome() {
        return nome;
    }

    public void setNome(String pnome) {
        nome = pnome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String psexo) {
        sexo = psexo;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String pendereco) {
        endereco = pendereco;
    }

    public int getnSus() {
        return nSus;
    }

    public void setnSus(int pnSus) {
        nSus = pnSus;
    }

    public void setObito(String pCausa) {
        obito = new ObitoPaciente(pCausa);
    }

    public ObitoPaciente getObito() {
        return obito;
    }

    public void setObito(ObitoPaciente obito) {
        this.obito = obito;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }
    
    
}
