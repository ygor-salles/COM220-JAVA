package trabfinal;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class LimiteConsulta extends JFrame implements ActionListener {

    ControleConsulta ctrConsulta;
    JFrame marcaconsulta;
    String fun;
    Paciente p = null;
    JTextField txtnSus;
    JTextField txtnome;
    String[] hora = {"08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
        "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30"};
    JComboBox cmbhora;
    JComboBox cbxEspecialidades;
    JTextField dataConsulta;
    JButton btnConsulta;
    JButton btnMarcar = new JButton("Marcar");
    JLabel lbl, lblmedico;
    Medico medico;
    Date data = null;
    JTextField motivoConsulta;

    public LimiteConsulta(ControleConsulta pctrConsulta) {
        super("Marcar consulta");
        ctrConsulta = pctrConsulta;
        //instanciando os objetos
        cbxEspecialidades = new JComboBox();
        txtnSus = new JTextField(20);
        txtnome = new JTextField(20);
        dataConsulta = new JTextField(10);
        motivoConsulta = new JTextField(10);

        //painel principal
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(3, 1));

        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());// painel principal vai ser uma grid com 3 linhas e 1 coluna
        painel.setBackground(Color.white);
        p.add(painel);
        //cria o GridBag
        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 2, 2, 2);

        //LABEL SUS
        gbc.gridx = 0; //coluna
        gbc.gridy = 1; //linha
        JLabel label = new JLabel("Numero Sus: ");
        painel.add(label, gbc);

        gbc.gridx = 1; //coluna
        gbc.gridy = 1; //linha
        painel.add(txtnSus, gbc);
        txtnSus.addActionListener(this);

        //nome
        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        JLabel label1 = new JLabel("Nome: ");
        painel.add(label1, gbc);

        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        painel.add(txtnome, gbc);

        //especialidade
        gbc.gridx = 0; //coluna
        gbc.gridy = 3; //linha
        JLabel label3 = new JLabel("Esp.: ");
        painel.add(label3, gbc);
        gbc.gridx = 1; //coluna
        gbc.gridy = 3; //linha
        ArrayList<Medico> listaMedico = ctrConsulta.getControlePrincipal().getCtrMedico().getListaMedico();
        for (Medico m : listaMedico) {
            int a = 0;

            for (int i = 0; i < cbxEspecialidades.getItemCount(); i++) {
                if (cbxEspecialidades.getItemAt(i).toString().equals(m.getEspecialidade())) {
                    a = 1;
                }
            }
            if (a == 0) {
                cbxEspecialidades.addItem(m.getEspecialidade());
            }
        }
        painel.add(cbxEspecialidades, gbc);

        //Consulta
        //PAINEL COM UMA BORDA, ONDE ESTA OS CAMPOS DE datas
        JPanel paineldata = new JPanel();
        paineldata.setBackground(Color.white);
        paineldata.setLayout(new GridBagLayout());// painel principal vai ser uma grid com 3 linhas e 1 coluna
        paineldata.setBorder(BorderFactory.createTitledBorder("Agendamento"));
        //cria o GridBag
        GridBagConstraints c = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        c.insets = new Insets(2, 2, 2, 2);
        //Data Consulta
        c.gridx = 0; //coluna
        c.gridy = 1; //linha
        JLabel label4 = new JLabel("Data Consulta: ");
        paineldata.add(label4, c);
        c.gridx = 1; //coluna
        c.gridy = 1; //linha
        paineldata.add(dataConsulta, c);

        //Hora Consulta
        c.gridx = 2; //coluna
        c.gridy = 1; //linha
        JLabel label6 = new JLabel("Hora Consulta: ");
        paineldata.add(label6, c);
        cmbhora = new JComboBox(hora);
        c.gridx = 3; //coluna
        c.gridy = 1; //linha
        paineldata.add(cmbhora, c);

        JPanel pbotao = new JPanel();
        pbotao.setBackground(Color.white);
        pbotao.setLayout(new FlowLayout());
        btnConsulta = new JButton("Consultar");
        pbotao.add(btnConsulta);
        btnConsulta.addActionListener(this);
        btnMarcar.addActionListener(this);
        p.add(paineldata);
        p.add(pbotao);
        add(p);
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);

    }
    
    //funcao para pegar sempre o primeiro medico disponivel para aquele horario ou
    //o proximo medico disponivel da especialidade

    public Medico medicoDisp(ArrayList<Medico> medEsp, Date data) {
        ArrayList<Consulta> consulta = ctrConsulta.getListaConsultas();
        for (Medico m : medEsp) {
            int a = 0;
            if (consulta.size() == 0) { // returna o primeiro medico pq nao tem nenhuma consulta marcada
                return m;
            }
            for (Consulta c : consulta) { //
                a++;
                if ((c.getDataConsulta().compareTo(data) == 0) && (c.getnMed() == Integer.parseInt(m.getNumFuncional()))) {
                    break;
                } else if (a == (consulta.size())) {
                    return m;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "medico indisponivel");
        return null;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == txtnSus) {
            int sus = Integer.parseInt(txtnSus.getText());
            p = ctrConsulta.getControlePrincipal().getCtrPaciente().getPaciente(sus);
            if (p != null) {
                if (p.getVida() == 0) {
                    JOptionPane.showMessageDialog(null, "Nao é possivel, paciente morto");
                } else {
                    txtnome.setText(p.getNome());
                    txtnome.setEnabled(false);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Nao foi encontrado nenhum Paciente");
            }
        }
        if (e.getSource() == btnConsulta) {
            ArrayList<Medico> listaEspMedicos;
            ArrayList<Medico> listaMedicos;

            String h;
            DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);

            try {
                data = df.parse(dataConsulta.getText());

            } catch (ParseException ex) {
                Logger.getLogger(LimiteConsulta.class.getName()).log(Level.SEVERE, null, ex);
            }
            h = cmbhora.getSelectedItem().toString();
            data.setHours(Integer.parseInt(h.substring(0, 2)));
            data.setMinutes(Integer.parseInt(h.substring(3, 5)));
            System.out.println(data);

            listaEspMedicos = ctrConsulta.getControlePrincipal().getCtrMedico().getEspecialidade(cbxEspecialidades.getSelectedItem().toString());
            listaMedicos = ctrConsulta.getControlePrincipal().getCtrMedico().getListaMedico();

            medico = medicoDisp(listaEspMedicos, data);

            if (medico != null) {
                marcaconsulta = new JFrame("Marcar consulta");
                marcaconsulta.setLayout(new GridLayout(6, 1));
                //informacoes paciente
                JPanel informacoesPaciente = new JPanel();
                informacoesPaciente.add(new JLabel("Nome paciente: " + p.getNome() + " "));
                informacoesPaciente.add(new JLabel("Numero Sus: " + p.getnSus()));
                //informacoes medico
                JPanel informacoesMedico = new JPanel();
                informacoesMedico.add(new JLabel("Nome medico: " + medico.getNome() + " "));
                informacoesMedico.add(new JLabel("Especialidade: " + medico.getEspecialidade()));
                //informacoes consulta
                JPanel informacoesConsulta = new JPanel();
                informacoesConsulta.add(new JLabel("Data Consulta: " + df.format(data) + " "));
                informacoesConsulta.add(new JLabel("Hora: " + data.getHours() + ":" + data.getMinutes()));
                marcaconsulta.add(informacoesPaciente);
                marcaconsulta.add(informacoesMedico);
                marcaconsulta.add(informacoesConsulta);
                marcaconsulta.add(new JLabel("Motivo da Consulta: "));
                marcaconsulta.add(motivoConsulta);
                marcaconsulta.add(btnMarcar);
                marcaconsulta.setVisible(ctrConsulta.verificaDispPaciente(data, p.getnSus()));
                marcaconsulta.pack();
                marcaconsulta.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                marcaconsulta.setLocationRelativeTo(null);
            }
        }
        if (e.getSource() == btnMarcar) {
            fun = ctrConsulta.getControlePrincipal().getCtrFuncionarios().getSessao();
            int nmed = Integer.parseInt(medico.getNumFuncional());
            int nfun = Integer.parseInt(fun);
            try {
                ctrConsulta.addConsulta(cbxEspecialidades.getSelectedItem().toString(),
                        p.getnSus(), data, new Date(), nfun, nmed, motivoConsulta.getText());

            } catch (Exception ex) {
                Logger.getLogger(LimiteConsulta.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Consulta marcada com sucesso");
            marcaconsulta.dispose();
            txtnSus.setText("");
            txtnome.setText("");
            dataConsulta.setText("");
        }
    }

}
