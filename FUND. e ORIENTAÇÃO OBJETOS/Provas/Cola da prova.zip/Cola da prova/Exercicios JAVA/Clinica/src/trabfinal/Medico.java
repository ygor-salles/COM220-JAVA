package trabfinal;
import java.io.Serializable;

public class Medico extends Dados implements Serializable{
    private String especialidade;
    
    public Medico(String pnome, String pnumFuncional, String pfuncao, 
                    String pespecialidade, String pusuario, String psenha) {
        super(pnome, pnumFuncional, pfuncao, pusuario, psenha);
        especialidade = pespecialidade;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }
    
    
    
}
