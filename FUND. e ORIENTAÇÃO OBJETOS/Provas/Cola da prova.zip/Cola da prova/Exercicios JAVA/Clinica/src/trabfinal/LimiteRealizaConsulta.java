package trabfinal;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class LimiteRealizaConsulta extends JFrame implements ActionListener {

    ControleRealizConsulta ctrrealizconsulta;
    Paciente p = null;
    JFrame realizacon;
    JLabel motivo;
    JComboBox cbmHora;
    JLabel nome;
    JTextField txtqueixas;
    JTextField txtresumoex;
    JTextField txtresumoDiag;
    JTextField txttrat;
    JButton inicia, reg;
    Consulta consulta;

    public LimiteRealizaConsulta(ControleRealizConsulta pctrrealizconsulta) {
        super("Realização de Consulta");
        ctrrealizconsulta = pctrrealizconsulta;

        //instanciando os objetos 
        nome = new JLabel();
        cbmHora = new JComboBox();

        //PAINEL PRINCIPALS
        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());// painel principal vai ser uma grid com 3 linhas e 1 coluna
        painel.setBackground(Color.white);
        //cria o GridBag
        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 2, 2, 2);

        //combo hora
        gbc.gridx = 0; //coluna
        gbc.gridy = 1; //linha
        JLabel label = new JLabel("Selecione o Horario: ");
        painel.add(label, gbc);
        gbc.gridx = 1; //coluna
        gbc.gridy = 1; //linha
        painel.add(cbmHora, gbc);

        //LABEL NOME
        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        JLabel label1 = new JLabel("Paciente: ");
        painel.add(label1, gbc);
        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        nome = new JLabel();
        painel.add(nome, gbc);

        //botao
        gbc.gridx = 1; //coluna
        gbc.gridy = 3; //linha
        inicia = new JButton("Iniciar");
        inicia.setEnabled(false);
        painel.add(inicia, gbc);

        preencheComboBox();
        cbmHora.addActionListener(this);

        add(painel);
        setSize(400, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void preencheComboBox() {
        int medico = Integer.parseInt(ctrrealizconsulta.getCtrPrincipal().
                getCtrMedico().getSessao());
        ArrayList<Consulta> con = ctrrealizconsulta.getCtrPrincipal().
                getCtrConsulta().getListaConsultas();
        Date hoje = new Date();
        for (Consulta c : con) {
            if ((hoje.getDate() == c.getDataConsulta().getDate()) && (medico == c.getnMed())) {
                String hora = String.format("%02d", c.getDataConsulta().getHours());
                String min = String.format("%02d", c.getDataConsulta().getMinutes());
                cbmHora.addItem(hora + ":" + min);
                
            }
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cbmHora) {
            Date cons = new Date();
            String h = cbmHora.getSelectedItem().toString();
            cons.setHours(Integer.parseInt(h.substring(0, 2)));
            cons.setMinutes(Integer.parseInt(h.substring(3, 5)));
            cons.setSeconds(0);
            int medico = Integer.parseInt(ctrrealizconsulta.getCtrPrincipal().
                    getCtrMedico().getSessao());
            ArrayList<Consulta> con = ctrrealizconsulta.getCtrPrincipal().
                    getCtrConsulta().getListaConsultas();
            for (Consulta c : con) {
                if ((cons.getHours() == c.getDataConsulta().getHours())
                        && (cons.getMinutes() == c.getDataConsulta().getMinutes())
                        && (medico == c.getnMed() && (cons.getDate()
                        == c.getDataConsulta().getDate()))) {
                    nome.setText(ctrrealizconsulta.getCtrPrincipal().
                            getCtrPaciente().getPaciente(c.getnSus()).getNome());
                    consulta = c;
                }
            }
            inicia.setEnabled(true);
                inicia.addActionListener(this);
        }
        if (e.getSource() == inicia) {
            //NOVA JANELA QUANDO APERTAR CONSULTA PRA INICIAR A CONSULTA
            realizacon = new JFrame("Dados consulta");
            realizacon.setLayout(new GridBagLayout());
            realizacon.setBackground(Color.white);
            
            //instanciando os obj
            txtqueixas = new JTextField(20);
            txtresumoex = new JTextField(20);
            txtresumoDiag = new JTextField(20);
            motivo = new JLabel();
            txttrat = new JTextField(20);

            //cria o GridBag
            GridBagConstraints gbc = new GridBagConstraints();
            // controla o espaço entre os componentes
            // e as linhas do GridBagLayout.
            // aqui nós definimos 2 pixels para os
            // lados de cima, esquerda, inferior e direita
            gbc.insets = new Insets(2, 2, 2, 2);

            //LABEL Numero SUS
            gbc.gridx = 0; //coluna
            gbc.gridy = 1; //linha
            JLabel label = new JLabel("Nome Paciente: ");
            label.setFont(new Font("SansSerif", Font.BOLD, 14));
            realizacon.add(label, gbc);

            //TXT sus
            gbc.gridx = 1; //coluna
            gbc.gridy = 1; //linha
            nome.setFont(new Font("SansSerif", Font.BOLD, 14));
            realizacon.add(nome, gbc);;

            // NOME
            gbc.gridx = 0; //coluna
            gbc.gridy = 2; //linha
            JLabel lbl = new JLabel("Motivo Consulta: ");
            lbl.setFont(new Font("SansSerif", Font.BOLD, 14));
            realizacon.add(lbl, gbc);
            gbc.gridx = 1; //coluna
            gbc.gridy = 2; //linha 
            motivo.setText(consulta.getMotivoConsulta());
            realizacon.add(motivo, gbc);

            //LABEL Queixas
            gbc.gridx = 0; //coluna
            gbc.gridy = 3; //linha
            JLabel label2 = new JLabel("Queixas: ");
            label2.setFont(new Font("SansSerif", Font.BOLD, 14));
            realizacon.add(label2, gbc);
            gbc.gridx = 1; //coluna
            gbc.gridy = 3; //linha
            realizacon.add(txtqueixas, gbc);

            //resumo
            gbc.gridx = 0; //coluna
            gbc.gridy = 4; //linha
            JLabel label3 = new JLabel("Resumo exame: ");
            label3.setFont(new Font("SansSerif", Font.BOLD, 14));
            realizacon.add(label3, gbc);
            gbc.gridx = 1; //coluna
            gbc.gridy = 4; //linha
            realizacon.add(txtresumoex, gbc);

            //RESUMO DIAGNOSTICO
            gbc.gridx = 0; //coluna
            gbc.gridy = 5; //linha
            JLabel label4 = new JLabel("Resumo diagnostico: ");
            label4.setFont(new Font("SansSerif", Font.BOLD, 14));
            realizacon.add(label4, gbc);
            gbc.gridx = 1; //coluna
            gbc.gridy = 5; //linha
            realizacon.add(txtresumoDiag, gbc);

            //tratamentos
            gbc.gridx = 0; //coluna
            gbc.gridy = 6; //linha
            JLabel label5 = new JLabel("Tratamentos: ");
            label5.setFont(new Font("SansSerif", Font.BOLD, 14));
            realizacon.add(label5, gbc);
            gbc.gridx = 1; //coluna
            gbc.gridy = 6; //linha
            realizacon.add(txttrat, gbc);

            //botao
            gbc.gridx = 1; //coluna
            gbc.gridy = 7; //linha
            reg = new JButton("Registrar consulta");
            realizacon.add(reg, gbc);
            reg.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        RealizaConsulta r = new RealizaConsulta(txtqueixas.getText(), txtresumoex.getText(),
                                txtresumoDiag.getText(), txttrat.getText(),
                                consulta.getnSus());
                        ctrrealizconsulta.getCtrPrincipal().getCtrConsulta().saltaAtendimento(consulta, r);

                        JOptionPane.showMessageDialog(null, "Consulta Realizada!");
                        txtqueixas.setText("");
                        txtresumoDiag.setText("");
                        txtresumoex.setText("");
                        txttrat.setText("");
                        realizacon.dispose();
                        nome.setText(" ");
                        inicia.setEnabled(false);
                    } catch (Exception ex) {
                        Logger.getLogger(LimiteRealizaConsulta.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            revalidate();
            realizacon.pack();
            realizacon.setLocationRelativeTo(null);
            realizacon.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            realizacon.setVisible(true);
        }
    }

}
