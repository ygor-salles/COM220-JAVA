package trabfinal;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class limiteFuncionario extends JFrame implements ActionListener {

    controleFuncionarios ctrFuncionarios;
    ArrayList<Dados> listadados = new ArrayList<>();
    JTextField txtNome;
    JTextField txtNum;
    JTextField txtesp;
    JTextField txtlog;
    JTextField txtsen;
    JComboBox cmbfuncao;

    public limiteFuncionario(controleFuncionarios pctrFuncionarios) {
        super("Cadastrar funcionarios");
        ctrFuncionarios = pctrFuncionarios;

        //painel principal
        JPanel painelP = new JPanel();
        painelP.setLayout(new BorderLayout());
        
        //PAINEL DADOS
        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());// painel principal vai ser uma grid com 3 linhas e 1 coluna
        painel.setBackground(Color.white);// fundo cinza claro

        //cria o GridBag
        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 2, 2, 2);

        //LABEL NOME
        gbc.gridx = 0; //coluna
        gbc.gridy = 1; //linha
        JLabel label = new JLabel("Nome: ");
        label.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label, gbc);// label adicionado no p1 qe tbm vai ter  o txtlogin

        //TXT NOME
        gbc.gridx = 1; //coluna
        gbc.gridy = 1; //linha
        txtNome = new JTextField(10);
        painel.add(txtNome, gbc);

        //LABEL NUMERO FUNCIONAL
        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        JLabel label2 = new JLabel("Nº Funcional: ");
        label2.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label2, gbc);

        //TXT NUMERO FUNCIONAL
        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        txtNum = new JTextField(10);
        painel.add(txtNum, gbc);

        //LABEL USUARUIO
        gbc.gridx = 0; //coluna
        gbc.gridy = 3; //linha
        JLabel label3 = new JLabel("Usuario: ");
        label3.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label3, gbc);

        //TXT USUARIO
        gbc.gridx = 1; //coluna
        gbc.gridy = 3; //linha
        txtlog = new JTextField(10);
        painel.add(txtlog, gbc);

        //LABEL FUNCAO
        gbc.gridx = 3; //coluna
        gbc.gridy = 1; //linha
        JLabel label4 = new JLabel("Função: ");
        label4.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label4, gbc);

        //COMBO FUNCAO
        gbc.gridx = 4; //coluna
        gbc.gridy = 1; //linha
        cmbfuncao = new JComboBox();
        cmbfuncao.addItem("Atendente");
        cmbfuncao.addItem("Medico");
        cmbfuncao.addItem("Enfermeiro");
        painel.add(cmbfuncao, gbc);

        //LABEL ESPECIALODADE
        gbc.gridx = 3; //coluna
        gbc.gridy = 2; //linha
        final JLabel label5 = new JLabel("Especialidade: ");
        label5.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        label5.setVisible(false);
        painel.add(label5, gbc);

        //TXT ESPECIALIDADE
        gbc.gridx = 4; //coluna
        gbc.gridy = 2; //linha
        txtesp = new JTextField(10);
        txtesp.setVisible(false);
        painel.add(txtesp, gbc);

        cmbfuncao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int indice = cmbfuncao.getSelectedIndex();//pega o índice do item selecionado
                if (indice == 1) {
                    label5.setVisible(true);
                    txtesp.setVisible(true);
                    
                } else { // faz sumir o label e o txt de especialidade quando muda 
                    //para outra funcao
                    label5.setVisible(false);
                    txtesp.setVisible(false);
                }
            }
        });

        //LABEL SENHA
        gbc.gridx = 3; //coluna
        gbc.gridy = 3; //linha
        JLabel label6 = new JLabel("Senha: ");
        label6.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label6, gbc);

        //TXT SENHA
        gbc.gridx = 4; //coluna
        gbc.gridy = 3; //linha
        txtsen = new JTextField(10);
        painel.add(txtsen, gbc);

        gbc.gridx = 2; //coluna
        gbc.gridy = 4; //linha
        //botao
        JButton btnCad = new JButton("Cadastrar");
        btnCad.addActionListener(this);
        painel.add(btnCad, gbc);
        painelP.add(painel,BorderLayout.CENTER);
        
        //LABEL TEXTO
        JPanel paineltxt = new JPanel();
        JLabel lbltexto = new JLabel("              CADASTRO FUNCIONARIO");
        lbltexto.setFont(new Font("Times New Roman", Font.BOLD, 16));
        paineltxt.setBackground(Color.white);
        paineltxt.add(lbltexto);
        painelP.add(paineltxt,BorderLayout.PAGE_START);
        
        add(painelP);
        setSize(600, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String nome, nrof,login, sen, esp, funcao;
        //recebendo os dados digitados
        nome = txtNome.getText();
        nrof = txtNum.getText();
        esp = txtesp.getText();
        login = txtlog.getText();
        sen = txtsen.getText();
        funcao = (String) cmbfuncao.getSelectedItem();

        // verefica se todos  os campos foram preenchidas
        if (nome.isEmpty() || nrof.isEmpty() || login.isEmpty()
                 || sen.isEmpty() || funcao.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Você deve preencher todos os campos!");
        } else //senao ele adiciona o funcionario
        {
            try {
                
                    if(funcao.equals("Atendente"))
                    {
                        ctrFuncionarios.AddFuncionarios(nome, nrof, funcao,login, sen);
                    }
                    else if(funcao.equals("Medico")){
                        ctrFuncionarios.getCtrPrincipal().getCtrMedico().AddMedico(nome, nrof, funcao, esp, login, sen);
                    }
                
               
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
            JOptionPane.showMessageDialog(this, "Funcionario cadastrado!");
            super.dispose();
        }

    }
    

}
