package trabfinal;

import java.awt.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class LimiteImpressaoAg extends JFrame implements ActionListener {

    controleFuncionarios ctrFuncionarios;
    JTextField dataI, dataF;
    Date data1, data2;
    JTextArea agenda;
    JButton pesquisar;
    ArrayList<String> especialidade = new ArrayList();
    ArrayList<Consulta> agend = new ArrayList();

    public LimiteImpressaoAg(controleFuncionarios pctrFuncionarios) {
        super("Impressao Agenda");
        ctrFuncionarios = pctrFuncionarios;
        //instanciando
        dataI = new JTextField(8);
        dataF = new JTextField(8);
        pesquisar = new JButton("PESQUISAR");
        pesquisar.addActionListener(this);
        agenda = new JTextArea();
        //painel principal
        JPanel painel = new JPanel();
        painel.setLayout(new BorderLayout());

        JPanel p1 = new JPanel();
        p1.setLayout(new FlowLayout());
        p1.setBackground(Color.white);
        p1.add(new JLabel("Datas: "));
        p1.add(dataI);
        p1.add(dataF);
        p1.add(pesquisar);

        JPanel p2 = new JPanel();
        p2.setBackground(Color.white);
        p2.add(agenda);

        painel.add(p1, BorderLayout.PAGE_START);
        painel.add(p2, BorderLayout.CENTER);
        add(painel);
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void buscaAg(Date data1, Date data2) {
        ArrayList<Consulta> listaconsulta = ctrFuncionarios.getCtrPrincipal().getCtrConsulta().getListaConsultas();
        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        for (Consulta c : listaconsulta) {
            if ((c.getDataConsulta().before(data2)) && (c.getDataConsulta().after(data1)) || (df.format(c.getDataConsulta()).equals(df.format(data2))) || (df.format(c.getDataConsulta()).equals(df.format(data1)))) {
               
                agend.add(c);
            }
        }
    }

    private ArrayList<String> getArrayEspecialidade() {
        ArrayList<Medico> listaMedico = ctrFuncionarios.getCtrPrincipal().getCtrMedico().getListaMedico();
        for (Medico m : listaMedico) {
            int a = 0;
            for (String e : especialidade) {
                if (e.equals(m.getEspecialidade())) {
                    a = 1;
                }
            }
            if (a == 0) {
                especialidade.add(m.getEspecialidade());
            }
        }
        return especialidade;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //datas
        agenda.setText("");
        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        try {
            data1 = df.parse(dataI.getText());
            data2 = df.parse(dataF.getText());

        } catch (ParseException ex) {
            Logger.getLogger(LimiteConsulta.class.getName()).log(Level.SEVERE, null, ex);
        }

        ArrayList<String> especi = getArrayEspecialidade();
        agend = new ArrayList();
        buscaAg(data1, data2);

        for (String k : especi) {
            agenda.setFont(new Font("SansSerif", Font.BOLD, 14));
            agenda.append("\n" + "Especialidade: " + k + "\n");
            for (Consulta c : agend) {
                if (c.getEspecialidade().equals(k)) {
                    agenda.append("Data: " + df.format(c.getDataConsulta())
                            + " - Paciente: " + ctrFuncionarios.getCtrPrincipal()
                            .getCtrPaciente().getPaciente(c.getnSus()).
                            getNome() + " - Medico : "
                            + ctrFuncionarios.getCtrPrincipal().getCtrMedico().
                            getMedicopNro(c.getnMed()).getNome() + "\n");
                }
            }
        }
        pack();
    }

}
