package trabfinal;

import java.io.Serializable;



public class funcionarios extends Dados implements Serializable {
   
   public funcionarios(String pnome, String pnumFuncional,String pfuncao, 
                                 String pusuario, String psenha){
        
        super(pnome, pnumFuncional ,pfuncao, pusuario, psenha);
    }
    
 
   
}
