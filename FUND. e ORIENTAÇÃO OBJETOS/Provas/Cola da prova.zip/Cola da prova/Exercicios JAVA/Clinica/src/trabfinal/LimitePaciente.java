package trabfinal;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import static java.lang.Integer.parseInt;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LimitePaciente extends JFrame implements ActionListener {

    ControlePaciente ctrPaciente;
    JTextField txtNome;
    JTextField txtnSus;
    JTextField txttelefone;
    JTextField txtend;
    JTextField dataniver;
    Date dataniv = null;
    String[] pSexo = {"MASCULINO", "FEMININO"};
    JComboBox cb1 = new JComboBox(pSexo);
    JButton cad;

    public LimitePaciente(ControlePaciente pctrPaciente) {
        super("Registrar Pacientes");
        ctrPaciente = pctrPaciente;
        //painel principal
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(3, 1));

        //PAINEL COM O CAMPOS DE NOME, DATA, NUMERO
        //PAINEL COM GRIDBAG
        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());
        painel.setBackground(Color.white);
        p.add(painel);
        //cria o GridBag
        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 5, 3, 2);

        //LABEL NOME
        gbc.gridx = 0; //coluna
        gbc.gridy = 1; //linha
        JLabel label = new JLabel("Nome: ");
        label.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label, gbc);// label adicionado no p1 qe tbm vai ter  o txtlogin

        //TXT NOME
        gbc.gridx = 1; //coluna
        gbc.gridy = 1; //linha
        txtNome = new JTextField(20);
        painel.add(txtNome, gbc);

        //RADIO BUTTON SEXO
        gbc.gridx = 3; //coluna
        gbc.gridy = 1; //linha
        JLabel labe = new JLabel("Sexo: ");
        labe.setFont(new Font("SansSerif", Font.BOLD, 14));
        painel.add(labe, gbc);
        gbc.gridx = 4; //coluna
        gbc.gridy = 1; //linha
        painel.add(cb1, gbc);
        //LABEL NUMERO SUS
        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        JLabel label2 = new JLabel("Nº SUS: ");
        label2.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label2, gbc);

        //TXT NUMERO SUS
        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        txtnSus = new JTextField(20);
        painel.add(txtnSus, gbc);

        //LABEL DATA NASCIMENTO
        gbc.gridx = 3; //coluna
        gbc.gridy = 2; //linha
        JLabel label4 = new JLabel("Data Nasci.: ");
        label4.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label4, gbc);

        //txt data nasc
        gbc.gridx = 4;
        gbc.gridy = 2; //linha
        dataniver = new JTextField(12);
        painel.add(dataniver, gbc);
        

        //PAINEL COM UMA BORDA, ONDE ESTA OS CAMPOS DE ENDERECO
        JPanel painelend = new JPanel();
        painelend.setBackground(Color.white);
        painelend.setLayout(new FlowLayout());
        painelend.setBorder(BorderFactory.createTitledBorder("Endereco"));
        painelend.add(new JLabel("Endereco:"));
        txtend = new JTextField(20);
        painelend.add(txtend);
        painelend.add(new JLabel("Telefone:"));
        txttelefone = new JTextField(10);
        painelend.add(txttelefone);
        p.add(painelend);

        //PAINEL ONDE ESTA O BOTAO
        JPanel Painelbotao = new JPanel();
        Painelbotao.setBackground(Color.white);
        cad = new JButton("Salvar");
        cad.addActionListener(this);
        Painelbotao.add(cad);
        p.add(Painelbotao);

        add(p);
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
         DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);

            try {
                dataniv = df.parse(dataniver.getText());

            } catch (ParseException ex) {
                Logger.getLogger(LimiteConsulta.class.getName()).log(Level.SEVERE, null, ex);
            }
        try {
            ctrPaciente.AddPacientes(txtNome.getText(), (String) cb1.getSelectedItem(),
                    dataniv, txtend.getText(), txttelefone.getText(), parseInt(txtnSus.getText()));
            JOptionPane.showMessageDialog(null, "Paciente Cadastrado!");
            txtNome.setText("");
            txtnSus.setText("");
            txtend.setText("");
            dataniver.setText("");
            txttelefone.setText("");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }

    }

}
