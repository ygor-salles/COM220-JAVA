package trabfinal;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author Samantha
 */
public class LimiteCancelamento extends JFrame implements ActionListener{
    ControleConsulta ctrControleCon;
    JTextField txtnSus;
    JTextField txtnome;
    JComboBox diascon;
    Paciente p = null;
    JLabel label5;
    JTextField motivoCan;
    Date data = null;
    JButton btncancelar;
    
    
    public LimiteCancelamento(ControleConsulta pctrControleC){
        super("Cancelar consulta");
        ctrControleCon = pctrControleC;
        //instanciar
        diascon = new JComboBox();
        txtnSus = new JTextField(20);
        txtnome = new JTextField(20);
        motivoCan = new JTextField(20);
        btncancelar = new JButton("Cancelar CONSULTA");
        
        //painel principal
        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());// painel principal vai ser uma grid com 3 linhas e 1 coluna
        painel.setBackground(Color.white);
        //cria o GridBag
        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 2, 2, 2);

        //LABEL SUS
        gbc.gridx = 0; //coluna
        gbc.gridy = 1; //linha
        JLabel label = new JLabel("Numero Sus: ");
        painel.add(label, gbc);

        gbc.gridx = 1; //coluna
        gbc.gridy = 1; //linha
        painel.add(txtnSus, gbc);
        txtnSus.addActionListener(this);

        //nome
        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        JLabel label1 = new JLabel("Nome: ");
        painel.add(label1, gbc);

        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        painel.add(txtnome, gbc);
        
        //datas de consultas
        gbc.gridx = 0; //coluna
        gbc.gridy = 3; //linha
        JLabel label3 = new JLabel("Datas: ");
        painel.add(label3, gbc);
        gbc.gridx = 1; //coluna
        gbc.gridy = 3; //linha
        painel.add(diascon,gbc);       
        
        diascon.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                label5.setVisible(true);
                motivoCan.setVisible(true);
            }
        });
        
        //MOTIVO
        gbc.gridx = 0; //coluna
        gbc.gridy = 4; //linha
        label5 = new JLabel("Motivo: ");
        painel.add(label5, gbc);
        label5.setVisible(false);
        gbc.gridx = 1; //coluna
        gbc.gridy = 4; //linha
        painel.add(motivoCan,gbc);
        motivoCan.setVisible(false);
        
        //botao
        gbc.gridx = 1; //coluna
        gbc.gridy = 5; //linha
        painel.add(btncancelar, gbc);
        btncancelar.addActionListener(this);
        
        
        add(painel);
        setSize(450,200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
    
    
    public ArrayList<Consulta> geraporData(int pnumeroSus){
        Date hoje = new Date();
        ArrayList<Consulta> consultas = ctrControleCon.getControlePrincipal().getCtrConsulta().getListaConsultas();
        ArrayList<Consulta> conPaciente = null;
        System.out.println("Entrei na função!");
        for(Consulta c: consultas){
            if(pnumeroSus == c.getnSus()){
                System.out.println("Achei a Samantha!");
                if(c.getDataConsulta().after(hoje)){
                    diascon.addItem(c.getDataConsulta());
                    System.out.println("Achei essa data: " + c.getDataConsulta()+"\n");
                }
            }
        }
        return conPaciente;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        //acao para o enter do txtsus
        if (e.getSource() == txtnSus) {
            int sus = Integer.parseInt(txtnSus.getText());
            this.geraporData(sus);
            p = ctrControleCon.getControlePrincipal().getCtrPaciente().getPaciente(sus);
            if (p != null) {
                txtnome.setText(p.getNome());
                txtnome.setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(null, "Nao foi encontrado nenhum Paciente");
            }
        }
        if(e.getSource() == btncancelar){
            int sus = Integer.parseInt(txtnSus.getText());
            Date data = (Date) diascon.getSelectedItem();
            try {
                ctrControleCon.getCtrPrincipal().getCtrConsulta().cancelaConsulta(sus,data,motivoCan.getText());
                JOptionPane.showMessageDialog(null, "Consulta Cancelada");
                txtnSus.setText("");
                motivoCan.setText("");
                txtnome.setText("");
            } catch (Exception ex) {
                Logger.getLogger(LimiteCancelamento.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
}
