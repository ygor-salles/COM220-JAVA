package trabfinal;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class ControlePaciente {

    private ArrayList<Paciente> listapacientes = new ArrayList<Paciente>();
    private String arquivo = "pacie.dat";
    private controlePrincipal ctrPrincipal;

    public ControlePaciente(controlePrincipal pctrPrincipal) {
       
        try {
            recuperaPacientes();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
        ctrPrincipal = pctrPrincipal;
    }

    //adiciona o paciente no array de pacientes
    public void AddPacientes(String pnome, String psexo, Date pdataAniver,
            String pendereco, String ptelefone, int pnSus) throws Exception {

        listapacientes.add(new Paciente(pnome, psexo, pdataAniver, pendereco, ptelefone, pnSus));
        
        gravaPacientes();
    }

    public ArrayList<Paciente> getListapacientes() {
        return listapacientes;
    }
    public Paciente getPaciente(int Nsus){
        for(Paciente pac : listapacientes){
            if(pac.getnSus() == Nsus){
                return pac;
            }
        }
        return null;
    }
    public controlePrincipal getCtrPrincipal() {
        return ctrPrincipal;
    }
    
    public void setCtrPrincipal(controlePrincipal ctrPrincipal) {
        this.ctrPrincipal = ctrPrincipal;
    }
    
    public void obitoPaciente(int pnSus, String pCausa) throws Exception {
        for (Paciente p : listapacientes) {
            if (p.getnSus() == pnSus) {
                p.setObito(pCausa);
                p.setVida(0);
                try {
                    gravaPacientes();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

    }
    

    public void alterarPaciente(int pnSus, String pendereco, String ptelefone) throws Exception {
        for (Paciente p : listapacientes) {
            if (p.getnSus() == pnSus) {
                p.setEndereco(pendereco);
                p.setTelefone(ptelefone);
            }
        }
        try {
            gravaPacientes();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void addPaciente() {
        new LimitePaciente(this);
    }
    public void BuscP(){
        new LimiteBuscPac(this);
    }
    public void altPaciente() {
        new LimiteAlteraP(this);
    }
    public void ObtoPaciente(){
        new LimiteObito(this);
    }
    public void SistemadeInfo(){
        new LimiteHistorico(this);
    }
    public void gravaPacientes() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream(arquivo);
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listapacientes);
        objOS.flush();
        objOS.close();
    }

    public void recuperaPacientes() throws Exception {
        File objFile = new File(arquivo);
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream(arquivo);
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listapacientes = (ArrayList<Paciente>) objIS.readObject();
            objIS.close();
            
        }
    }
}
