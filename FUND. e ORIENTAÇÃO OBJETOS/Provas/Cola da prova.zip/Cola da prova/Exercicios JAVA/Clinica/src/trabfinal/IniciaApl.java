package trabfinal;

public class IniciaApl {
    
    //instancia a classe controle principal
    public static void main(String[] args){
        controlePrincipal cp = new controlePrincipal();
    }
}
