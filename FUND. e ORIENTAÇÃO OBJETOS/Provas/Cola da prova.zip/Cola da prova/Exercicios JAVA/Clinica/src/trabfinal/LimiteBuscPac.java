package trabfinal;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class LimiteBuscPac extends JFrame implements ActionListener {

    ControlePaciente ctrPaciente;
    JLabel lbl;
    JTextField txtnSus;
    JTextArea textopaciente;

    public LimiteBuscPac(ControlePaciente pctrPaciente) {
        super("Buscar Pacientes");
        ctrPaciente = pctrPaciente;
        //Instanciando os objetos
        lbl = new JLabel("Numero SUS: ");
        txtnSus = new JTextField(10);
        textopaciente = new JTextArea();

        //painel 
        JPanel painel1 = new JPanel();
        painel1.setLayout(new FlowLayout());
        painel1.setBackground(Color.white);
        painel1.add(lbl);
        painel1.add(txtnSus);

        JPanel painel = new JPanel();
        painel.setLayout(new BorderLayout());
        painel.add(painel1, BorderLayout.PAGE_START);
        painel.add(textopaciente, BorderLayout.CENTER);
        //acao de enter para o textfield
        txtnSus.addActionListener(this);
        this.add(painel);

        setSize(450,300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        textopaciente.setText("");
        int codigo = Integer.parseInt(txtnSus.getText());
        Paciente p = ctrPaciente.getPaciente(codigo);
        if (p != null) {
            textopaciente.append("Nome: "+ " " + p.getNome() + "\n" 
                    + "Endereço:"+ " " + p.getEndereco() + "\n" + 
                    "Telefone:" + " " + p.getTelefone());
        } else {
            textopaciente.append("Não existe pacientes com esse numero de SUS!\n");
        }
        
    }

}
