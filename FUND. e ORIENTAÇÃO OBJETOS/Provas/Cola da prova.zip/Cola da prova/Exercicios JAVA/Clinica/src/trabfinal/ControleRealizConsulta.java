package trabfinal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ControleRealizConsulta {
    private ArrayList<RealizaConsulta> historico = new ArrayList<>();
    private controlePrincipal ctrPrincipal;
    private String arquivo = "historicoConsulta.dat";
    
     public ControleRealizConsulta(controlePrincipal pCtrPrincipal){
        try {
            recuperaRConsulta();
        } catch (Exception ex) {
           JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
        ctrPrincipal = pCtrPrincipal;
    }
    
    public void addHistorico(String pqueixas,String presumoex,String presumoDiag,
                            String ptratamentCon, int pnroSus) throws Exception{
        historico.add(new RealizaConsulta(pqueixas,presumoex,presumoDiag,
                                            ptratamentCon,pnroSus));
        gravaRConsulta();
    }
    public void limRealizCons(){
        new LimiteRealizaConsulta(this);
    }

    public controlePrincipal getCtrPrincipal() {
        return ctrPrincipal;
    }
    
    
    public void gravaRConsulta() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream(arquivo);
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(historico);
        objOS.flush();
        objOS.close();
    }
    
    public void recuperaRConsulta() throws Exception {
        File objFile = new File(arquivo);
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream(arquivo);
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            historico = (ArrayList<RealizaConsulta>) objIS.readObject();
            objIS.close();
        }
    }
    
    
}
