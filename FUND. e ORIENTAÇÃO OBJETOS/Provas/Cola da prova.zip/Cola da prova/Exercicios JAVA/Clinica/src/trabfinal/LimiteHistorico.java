package trabfinal;

import java.awt.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class LimiteHistorico extends JFrame implements ActionListener {

    ControlePaciente ctrPaciente;
    JFrame dados;
    Paciente p;
    JTextField txtnSus;
    JLabel nome;
    JTextArea proximaC;
    JComboBox cons;
    JButton veri;

    public LimiteHistorico(ControlePaciente pctrPaciente) {
        super("Historico");
        ctrPaciente = pctrPaciente;

        //instanciando os obj
        txtnSus = new JTextField(20);
        nome = new JLabel();
        proximaC = new JTextArea(4, 5);
        cons = new JComboBox();
        veri = new JButton("Verificar");
        veri.setEnabled(false);

        // Cria barra de rolagem e adiciona a area de texto
        JScrollPane scrooll = new JScrollPane(proximaC);

        // Adiciona valores as propriedades da barra de rolagem
        // Barra vertical
        scrooll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // Tamanho da barra
        scrooll.setPreferredSize(new Dimension(100, 100));

        //painel principal
        JPanel p1 = new JPanel();
        p1.setLayout(new GridLayout(3, 1));

        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());// painel principal vai ser uma grid com 3 linhas e 1 coluna
        painel.setBackground(Color.white);
        //cria o GridBag
        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 2, 2, 2);

        //LABEL Numero SUS
        gbc.gridx = 0; //coluna
        gbc.gridy = 1; //linha
        JLabel label = new JLabel("Numero SUS: ");
        label.setFont(new Font("SansSerif", Font.BOLD, 14));
        painel.add(label, gbc);
        //TXT sus
        gbc.gridx = 1; //coluna
        gbc.gridy = 1; //linha
        painel.add(txtnSus, gbc);
        txtnSus.addActionListener(this);

        // NOME
        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        JLabel lbl = new JLabel("Nome Paciente: ");
        lbl.setFont(new Font("SansSerif", Font.BOLD, 14));
        painel.add(lbl, gbc);
        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        nome.setFont(new Font("SansSerif", Font.BOLD, 14));
        painel.add(nome, gbc);

        JPanel p3 = new JPanel();
        p3.setLayout(new BorderLayout());
        p3.setBackground(Color.white);
        p3.add(scrooll, BorderLayout.CENTER);

        JPanel p4 = new JPanel();
        p4.setLayout(new GridBagLayout());
        p4.setBackground(Color.white);
        //cria o GridBag
        GridBagConstraints c = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        c.insets = new Insets(2, 2, 2, 2);
        cons.addActionListener(this);
        //TXT sus
        c.gridx = 1; //coluna
        c.gridy = 1; //linha
        p4.add(cons, c);
        c.gridx = 2;
        c.gridy = 1;
        p4.add(veri, c);
        veri.addActionListener(this);
        p1.add(painel);
        p1.add(p3);
        p1.add(p4);
        add(p1);
        setSize(450, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public ArrayList<Consulta> preencheCBox(int pnumeroSus) {
        Date hoje = new Date();
        ArrayList<Consulta> consultas = ctrPaciente.getCtrPrincipal().getCtrConsulta().getListaConsultas();
        ArrayList<Consulta> conPaciente = null;
        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        for (Consulta c : consultas) {
            if (pnumeroSus == c.getnSus()) {
                if (c.getDataConsulta().before(hoje)) {
                    String hora = String.format("%02d", c.getDataConsulta().getHours());
                    String min = String.format("%02d", c.getDataConsulta().getMinutes());
                    cons.addItem(df.format(c.getDataConsulta()) + " " + hora + ":" + min);
                    veri.setEnabled(true);
                }
            }
        }
        return conPaciente;
    }
    
    //Funcao responsavel por preencher a text area que contem informacoes das proximas consultas
    public ArrayList<Consulta> preencheTxArea(int pnumeroSus) {
        Date hoje = new Date();
        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        ArrayList<Consulta> consultas = ctrPaciente.getCtrPrincipal().getCtrConsulta().getListaConsultas();
        ArrayList<Consulta> conPaciente = null;
        proximaC.setText("");
        proximaC.setFont(new Font("SansSerif", Font.BOLD, 12));
        proximaC.append("Data das proximas consultas: " + "\n");
        for (Consulta c : consultas) {
            if (pnumeroSus == c.getnSus()) {
                if (c.getDataConsulta().after(hoje)) {
                    String hora = String.format("%02d", c.getDataConsulta().getHours());//pega dois numeros
                    String min = String.format("%02d", c.getDataConsulta().getMinutes());
                    proximaC.append(df.format(c.getDataConsulta()) + " " + " Hora: "
                            + hora + ":" + min + " Medico : " + ctrPaciente.
                            getCtrPrincipal().getCtrMedico().
                            getMedicopNro(c.getnMed()).getNome()
                            + " Especialidade: " + ctrPaciente.
                            getCtrPrincipal().getCtrMedico().
                            getMedicopNro(c.getnMed()).getEspecialidade()
                            + " \n");
                }
            }
        }
        return conPaciente;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == txtnSus) {
            int sus = Integer.parseInt(txtnSus.getText());
            p = ctrPaciente.getCtrPrincipal().getCtrPaciente().getPaciente(sus);
            if (p != null) {
                if (p.getVida() == 0) {
                    JOptionPane.showMessageDialog(null, "PACIENTE MORTO");
                    veri.setEnabled(false);
                    cons.removeAllItems();
                    nome.setText("");
                    revalidate();
                } else {
                    nome.setText(p.getNome());
                    preencheCBox(sus);
                    preencheTxArea(sus);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Nao foi encontrado nenhum Paciente");
                veri.setEnabled(false);
                cons.removeAllItems();
                nome.setText("");
                revalidate();
            }

        }
        if (e.getSource() == veri) {
            ArrayList<Consulta> consultas = ctrPaciente.getCtrPrincipal().
                    getCtrConsulta().getListaConsultas();
            int nSus = Integer.parseInt(txtnSus.getText());
            Date dia = new Date();

            DateFormat x = DateFormat.getDateInstance(DateFormat.MEDIUM);
            try {
                dia = x.parse(cons.getSelectedItem().toString().substring(0, 10));

            } catch (ParseException ex) {
                Logger.getLogger(LimiteConsulta.class.getName()).log(Level.SEVERE, null, ex);
            }
            dia.setHours(Integer.parseInt(cons.getSelectedItem().toString().substring(11, 13)));
            dia.setMinutes(Integer.parseInt(cons.getSelectedItem().toString().substring(14, 16)));

            System.out.println(dia);

            Consulta consulta = null;
            for (Consulta c : consultas) {
                if ((c.getDataConsulta().compareTo(dia) == 0) && (c.getnSus() == nSus)) {
                    consulta = c;
                }
            }

            DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);

            dados = new JFrame("Dados consulta");
            dados.setLayout(new GridLayout(6, 1));
            JPanel infDConsulta = new JPanel();
            infDConsulta.setBackground(Color.white);
            infDConsulta.add(new JLabel("Data Consulta: " + df.format(consulta.getDataConsulta()) + "\n")); //colocar aqui a data 

            JPanel infmConsulta = new JPanel();
            infmConsulta.setBackground(Color.white);
            infmConsulta.add(new JLabel("Medico: " + ctrPaciente.getCtrPrincipal()
                    .getCtrMedico().getMedicopNro(consulta.getnMed()).getNome() + "\n")); //passar o medico da consulta

            JPanel infDadosQ = new JPanel();
            infDadosQ.setBackground(Color.white);
            infDadosQ.add(new JLabel("Queixas: " + consulta.getAtendimento().getQueixas() + "\n"));

            JPanel infDadosE = new JPanel();
            infDadosE.setBackground(Color.white);
            infDadosE.add(new JLabel("Resumo Exame: " + consulta.getAtendimento().getResumoex() + "\n"));

            JPanel infDadosd = new JPanel();
            infDadosd.setBackground(Color.white);
            infDadosd.add(new JLabel("Resumo Diagnostico: " + consulta.getAtendimento().getResumoDiag() + "\n"));

            JPanel infDadosT = new JPanel();
            infDadosT.setBackground(Color.white);
            infDadosT.add(new JLabel("Tratamentos: " + consulta.getAtendimento().getTratamentCon() + "\n"));
            dados.add(infDConsulta);
            dados.add(infmConsulta);
            dados.add(infDadosQ);
            dados.add(infDadosE);
            dados.add(infDadosd);
            dados.add(infDadosT);
            dados.setVisible(true);
            dados.setSize(300, 200);
            dados.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            dados.setLocationRelativeTo(null);
            dados.pack();
        }
    }

}
