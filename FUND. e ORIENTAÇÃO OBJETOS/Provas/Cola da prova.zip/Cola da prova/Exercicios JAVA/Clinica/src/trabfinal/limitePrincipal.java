package trabfinal;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class limitePrincipal extends JFrame implements ActionListener {

    controlePrincipal ctrPrincipal;
    JTextField txtlogin;
    JPasswordField txtsenha;
    JLabel image;

    public limitePrincipal(controlePrincipal pctrPrincipal) {
        super("LOGIN");
        ctrPrincipal = pctrPrincipal;
        txtlogin = new JTextField(10);
        txtsenha = new JPasswordField(10);

        //painel principal
        JPanel painelP = new JPanel();
        painelP.setLayout(new BorderLayout());
        
        
        //PAINEL CAIXAS DE LOGIN E SENHA
        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());// painel principal vai ser uma grid com 3 linhas e 1 coluna
        painel.setBackground(Color.white);// fundo cinza claro

        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 2, 2, 2);

        gbc.gridx = 0; //coluna
        gbc.gridy = 1; //linha
        JLabel label = new JLabel("Usuario: ");
        label.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label, gbc);// label adicionado no p1 qe tbm vai ter  o txtlogin

        gbc.gridx = 1; //coluna
        gbc.gridy = 1; //linha
        painel.add(txtlogin, gbc);

        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        // cria a label da senha
        JLabel label2 = new JLabel("Senha: ");
        label2.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label senha
        painel.add(label2, gbc);

        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        painel.add(txtsenha, gbc);
        txtsenha.addActionListener(this);
        gbc.gridx = 1; //coluna
        gbc.gridy = 3; //linha
        //botao
        JButton btnCad = new JButton("Entrar");
        btnCad.addActionListener(this);
        painel.add(btnCad, gbc);
        painelP.add(painel,BorderLayout.CENTER);
        
        //PAINEL IMAGEM 
        JPanel imagem = new JPanel();
        imagem.setBackground(Color.white);
        image = new JLabel(new ImageIcon("LogoClinic.gif"));   
        imagem.add(image);
        painelP.add(imagem,BorderLayout.LINE_START);
        
        add(painelP);
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        funcionarios fun = null;
        Medico funM = null;
        String usuario = "admin", senha = "admin";
        String pusuario, psenha;
        pusuario = txtlogin.getText();
        psenha = txtsenha.getText();
        //ve se é administrador
        if (txtlogin.getText().equals(usuario)) {
            if (txtsenha.getText().equals(senha)) {
                ctrPrincipal.getCtrFuncionarios().criaFuncionarios();
                txtlogin.setText("");
                txtsenha.setText("");
            }else{
                JOptionPane.showMessageDialog(this, "Senha de administrador Errada");
            }
        } else {
            fun = ctrPrincipal.getCtrFuncionarios().buscarFunc(pusuario, psenha);
            funM = ctrPrincipal.getCtrMedico().buscarMed(pusuario, psenha);
            if (fun == null) {
                if (funM == null) {
                    txtlogin.setText("");
                    txtsenha.setText("");
                }
                else  {
                    ctrPrincipal.getCtrRealizaConsulta().limRealizCons();
                    txtlogin.setText("");
                    txtsenha.setText("");
                   JOptionPane.showMessageDialog(this, "usuario encontrado");
                }
            } else {
                    ctrPrincipal.limAte();
                    txtlogin.setText("");
                    txtsenha.setText("");
                //chamar a tela de menu do respectivo funcionario
                JOptionPane.showMessageDialog(this, "usuario encontrado");
            }
        }

    }
}
