package trabfinal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ControleConsulta {

    private ArrayList<Consulta> listaConsultas = new ArrayList<>();
    private controlePrincipal ctrPrincipal;
    private String arquivo = "consulta2.dat";

    public ControleConsulta(controlePrincipal pCtrPrincipal) {
        try {
            recuperaConsulta();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
        ctrPrincipal = pCtrPrincipal;
    }

    public void setListaConsultas(ArrayList<Consulta> listaConsultas) {
        this.listaConsultas = listaConsultas;
    }

    public ArrayList<Consulta> getListaConsultas() {
        return listaConsultas;
    }

    public controlePrincipal getCtrPrincipal() {
        return ctrPrincipal;
    }
    
    public void saltaAtendimento(Consulta pCons ,RealizaConsulta pAtend) throws Exception{
        for (Consulta cons : listaConsultas) {
            if(cons == pCons){
                cons.setAtendimento(pAtend);
                gravaConsulta();
            }
        }
    }
    
    public boolean verificaDispPaciente(Date pDataConsulta, int pnumSus){
        for(Consulta c: listaConsultas){
            if((c.getDataConsulta().compareTo(pDataConsulta)==0)&&(c.getnSus()==pnumSus)){
                JOptionPane.showMessageDialog(null,"Paciente possui uma consulta neste horário!");
                return false;
            }
        }
        return true;
    }

    public void cancelaConsulta(int nSus, Date data, String motivo) throws Exception {
        //calma
        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        Date hoje = df.parse("01/01/0001");
        for (Consulta c : listaConsultas) {
            if (nSus == c.getnSus()) {
                if (c.getDataConsulta().compareTo(data)==0){
                    c.setDataCan(hoje);
                    c.setDataConsulta(hoje);
                    c.setMotivoCancelamento(motivo);
                    System.out.println(c.getDataCan());
                    System.out.println(c.getMotivoCancelamento());
                    
                    gravaConsulta();
                }
            }
        }
    }

    public void addConsulta(String especialidade, int nSus, Date dataConsulta, Date dataMarcacao,
            int nfun, int nMed, String motivoConsulta) throws Exception {

        listaConsultas.add(new Consulta(especialidade, nSus, dataConsulta, dataMarcacao,
                nfun, nMed, motivoConsulta));

        gravaConsulta();

    }

    public controlePrincipal getControlePrincipal() {
        return ctrPrincipal;
    }

    public void LimCons() {
        new LimiteConsulta(this);
    }

    public void CancelaConsulta() {
        new LimiteCancelamento(this);
    }

    public void gravaConsulta() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream(arquivo);
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listaConsultas);
        objOS.flush();
        objOS.close();
    }

    public void recuperaConsulta() throws Exception {
        File objFile = new File(arquivo);
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream(arquivo);
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listaConsultas = (ArrayList<Consulta>) objIS.readObject();
            objIS.close();
        }
    }

}
