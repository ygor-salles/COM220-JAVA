package trabfinal;

import java.io.Serializable;
import java.util.Date;


public class Consulta implements Serializable{
    private String especialidade;
    private int nSus;
    private String motivoConsulta;
    private Date dataConsulta;
    private Date dataMarcacao;
    private Date dataCan;
    private int nfun;
    private int nMed;
    private String motivoCancelamento;
    private RealizaConsulta atendimento;

    public RealizaConsulta getAtendimento() {
        return atendimento;
    }

    public void setAtendimento(RealizaConsulta atendimento) {
        this.atendimento = atendimento;
    }
    
    public Consulta(){ }

    public Consulta(String especialidade, int nSus,Date dataConsulta, Date dataMarcacao, 
                        int nfun, int nMed, String motivoConsulta ) {
        this.especialidade = especialidade;
        this.nSus = nSus;
        this.dataConsulta = dataConsulta;
        this.dataMarcacao = dataMarcacao;
        this.nfun = nfun;
        this.nMed = nMed;
        this.motivoConsulta = motivoConsulta;
    } 
    
    
    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public Date getDataCan() {
        return dataCan;
    }

    public String getMotivoCancelamento() {
        return motivoCancelamento;
    }

    public void setDataCan(Date dataCan) {
        this.dataCan = dataCan;
    }

    public void setMotivoCancelamento(String motivoCancelamento) {
        this.motivoCancelamento = motivoCancelamento;
    }

    public String getMotivoConsulta() {
        return motivoConsulta;
    }

    public void setMotivoConsulta(String motivoConsulta) {
        this.motivoConsulta = motivoConsulta;
    }

    public int getnSus() {
        return nSus;
    }

    public void setnSus(int nSus) {
        this.nSus = nSus;
    }

    public int getNfun() {
        return nfun;
    }

    public void setNfun(int nfun) {
        this.nfun = nfun;
    }

    public int getnMed() {
        return nMed;
    }

    public void setnMed(int nMed) {
        this.nMed = nMed;
    }

    public Date getDataConsulta() {
        return dataConsulta;
    }

    public void setDataConsulta(Date dataConsulta) {
        this.dataConsulta = dataConsulta;
    }

    public Date getDataMarcacao() {
        return dataMarcacao;
    }

    public void setDataMarcacao(Date dataMarcacao) {
        this.dataMarcacao = dataMarcacao;
    }

    
}
