package trabfinal;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

public class ControleMedico {

    private ArrayList<Medico> listaMedico = new ArrayList<>();
    private String arquivo = "med.dat";
    private controlePrincipal ctrPrincipal;
    private ArrayList<Medico> medicos = new ArrayList<>();
    private String sessao;

    public ArrayList<Medico> getMedicos() {
        return medicos;
    }

    public void setMedicos(ArrayList<Medico> medicos) {
        this.medicos = medicos;
    }

    public String getSessao() {
        return sessao;
    }

    public void setSessao(String sessao) {
        this.sessao = sessao;
    }

    public ControleMedico(controlePrincipal pctrPrincipal) {
        try {
            recuperaMedicos();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
        ctrPrincipal = pctrPrincipal;
    }

    public void AddMedico(String pnome, String pnumFuncional, String pfuncao,
            String pespecialidades, String pusuario, String psenha) throws Exception {
        listaMedico.add(new Medico(pnome, pnumFuncional, pfuncao, pespecialidades,
                pusuario, psenha));
        gravaMedicos();
    }

    public controlePrincipal getCtrPrincipal() {
        return ctrPrincipal;
    }

    public ArrayList<Medico> getListaMedico() {
        return listaMedico;
    }

    public Medico buscarMed(String pusuario, String psenha) {
        for (Medico m : listaMedico) {
            if (m.getUsuario().equals(pusuario)) {
                if (m.getSenha().equals(psenha)) {
                    System.out.println(m.getUsuario() + " " + m.getSenha());
                    sessao = m.getNumFuncional();
                    return m;
                }
            }
        }
        return null;

    }

    public ArrayList<Medico> getEspecialidade(String especialidade) {
        for (Medico m : listaMedico) {
            if (m.getEspecialidade().equals(especialidade)) {
                medicos.add(m);
                System.out.println("Adicionei o " + m.getNome() + "/n" + "Especialidade recebida: " + m.getEspecialidade() + "Parametro: " + especialidade + "/n");
            }
        }
        return medicos;
    }

    public Medico getMedicopNro(int pNMed) {
        for (Medico med : listaMedico) {
            if (Integer.parseInt(med.getNumFuncional()) == pNMed) {
                return med;
            }
        }
        return null;
    }

    public void gravaMedicos() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream(arquivo);
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listaMedico);
        objOS.flush();
        objOS.close();
    }

    public void recuperaMedicos() throws Exception {
        File objFile = new File(arquivo);
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream(arquivo);
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listaMedico = (ArrayList<Medico>) objIS.readObject();
            objIS.close();
        }
    }
}
