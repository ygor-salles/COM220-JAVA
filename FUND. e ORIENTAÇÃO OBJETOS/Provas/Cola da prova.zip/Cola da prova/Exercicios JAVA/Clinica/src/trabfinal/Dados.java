package trabfinal;

import java.io.Serializable;

public abstract class Dados implements Serializable {
    private String nome;
    private String funcao, numFuncional;
    private String usuario;
    private String senha;
    
     public Dados (String pNome,String pNumero, String pFuncao,String pusuario, String pSenha){
        nome=pNome;
        numFuncional = pNumero;
        usuario = pusuario;
        senha=pSenha;
        funcao=pFuncao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public String getNumFuncional() {
        return numFuncional;
    }

    public void setNumFuncional(String numFuncional) {
        this.numFuncional = numFuncional;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
     
    
    
}
