/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabfinal;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Samantha
 */
public class ObitoPaciente implements Serializable{
    private String causa;
    private Date obto = new Date();
    
    
    public ObitoPaciente(String pCausa){
         causa=pCausa;   
    }

    public String getCausa() {
        return causa;
    }
    
    
}
