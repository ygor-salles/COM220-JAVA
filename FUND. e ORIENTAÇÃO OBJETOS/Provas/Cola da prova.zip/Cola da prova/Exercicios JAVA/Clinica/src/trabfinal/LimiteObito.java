package trabfinal;

import java.awt.*;
import java.awt.event.*;
import static java.lang.Integer.parseInt;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.*;

public class LimiteObito extends JFrame implements ActionListener {

    ControlePaciente ctrPaciente;
    Paciente p;
    JTextField txtnSus;
    JLabel txtnome;
    JTextField txtcausa;

    JButton cad;

    public LimiteObito(ControlePaciente pctrPaciente) {
        super("Registrar Obito de Paciente");
        ctrPaciente = pctrPaciente;
        //painel principal
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(2, 1));

        //PAINEL COM O CAMPOS DE NOME, DATA, NUMERO
        //PAINEL COM GRIDBAG
        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());
        painel.setBackground(Color.white);
        p.add(painel);
        //cria o GridBag
        GridBagConstraints gbc = new GridBagConstraints();
        // controla o espaço entre os componentes
        // e as linhas do GridBagLayout.
        // aqui nós definimos 2 pixels para os
        // lados de cima, esquerda, inferior e direita
        gbc.insets = new Insets(2, 5, 3, 2);

        //LABEL NUMERO SUS
        gbc.gridx = 0; //coluna
        gbc.gridy = 2; //linha
        JLabel label2 = new JLabel("Nº SUS: ");
        label2.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label2, gbc);

        //TXT NUMERO SUS
        gbc.gridx = 1; //coluna
        gbc.gridy = 2; //linha
        txtnSus = new JTextField(20);
        painel.add(txtnSus, gbc);
        txtnSus.addActionListener(this);
        // NOME
        gbc.gridx = 0; //coluna
        gbc.gridy = 3; //linha
        JLabel lbl = new JLabel("Nome Paciente: ");
        lbl.setFont(new Font("SansSerif", Font.BOLD, 14));
        painel.add(lbl, gbc);
        gbc.gridx = 1; //coluna
        gbc.gridy = 3; //linha
        txtnome = new JLabel();
        txtnome.setFont(new Font("SansSerif", Font.BOLD, 14));
        painel.add(txtnome, gbc);

        //LABEL Causa
        gbc.gridx = 0; //coluna
        gbc.gridy = 4; //linha
        JLabel label3 = new JLabel("Causa: ");
        label3.setFont(new Font("SansSerif", Font.BOLD, 14)); // Define a fonte do label usuario
        painel.add(label3, gbc);

        //TXT CAUSA
        gbc.gridx = 1; //coluna
        gbc.gridy = 4; //linha
        txtcausa = new JTextField(20);
        painel.add(txtcausa, gbc);

        //PAINEL ONDE ESTA O BOTAO
        JPanel Painelbotao = new JPanel();
        Painelbotao.setBackground(Color.white);
        cad = new JButton("Salvar");
        cad.addActionListener(this);
        Painelbotao.add(cad);
        p.add(Painelbotao);
        
        add(p);
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
    
     public void mataPaciente(int pnumeroSus) throws Exception {
        Date hoje = new Date();
        ArrayList<Consulta> consultas = ctrPaciente.getCtrPrincipal().getCtrConsulta().getListaConsultas();
        for (Consulta c : consultas) {
            if (pnumeroSus == c.getnSus()) {
                if (c.getDataConsulta().after(hoje)) {
                    ctrPaciente.getCtrPrincipal().getCtrConsulta().cancelaConsulta(pnumeroSus, c.getDataConsulta(), "Morreu");
                }
            }
        }
        ctrPaciente.getCtrPrincipal().getCtrPaciente().obitoPaciente(pnumeroSus, txtcausa.getText());
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == txtnSus) {
            int sus = Integer.parseInt(txtnSus.getText());
            p = ctrPaciente.getPaciente(sus);
            if (p != null) {
                txtnome.setText(p.getNome());
            } else {
                JOptionPane.showMessageDialog(null, "Nao foi encontrado nenhum Paciente");
            }
        }
        if (e.getSource() == cad) {
            try {
                mataPaciente(Integer.parseInt(txtnSus.getText()));
                JOptionPane.showMessageDialog(null, "Obito cadastrado!");
                txtcausa.setText("");
                txtnSus.setText("");
                txtnome.setText("");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
