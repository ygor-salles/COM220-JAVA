
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.*;
import javax.swing.*;

/**
 *
 * @author Samantha
 */
public class html extends JFrame implements ActionListener {

    JTextField endereco;
    JButton go;
    JEditorPane pagina;
    JLabel aviso;
    URL url;

    public html(String titulo) {
        super(titulo);
    }

    public void addComp() {
        Container top = getContentPane();
        JPanel p1 = new JPanel();
        endereco = new JTextField(65);
        endereco.setText("http://");
        pagina = new JEditorPane();
        go = new JButton("GO");
        p1.add(endereco);
        p1.add(go);

        go.addActionListener(this);
        aviso = new JLabel();

        top.setLayout(new BorderLayout());
        top.add(p1, BorderLayout.PAGE_START);
        top.add(pagina, BorderLayout.CENTER);
        top.add(aviso, BorderLayout.PAGE_END);

        setSize(800, 600);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        html chrome = new html("Navegador");
        chrome.addComp();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == go) {
            try {
                url = new URL(endereco.getText());
            } catch (MalformedURLException e1) {
                aviso.setText("Endereço WEB mal formada");
                e1.printStackTrace();
            }
            try {
                pagina.setPage(url);
            } catch (IOException e1) {
                aviso.setText(null);
                aviso.setText("Erro ao abrir página");
                e1.printStackTrace();
            }
        }
    }

}
