package info.academico.Disciplina;

public class Disciplina {
	private final String nomeDis;
	private final int cargaHoraria;

	public Disciplina(String pnomeDis, int pcargaHoraria) {
		nomeDis = pnomeDis;
		cargaHoraria = pcargaHoraria;
	}

	public String getDescricaoDisciplina() {
		return " Disciplina: " + nomeDis + " Carga Horaria: " + cargaHoraria;
	}
}