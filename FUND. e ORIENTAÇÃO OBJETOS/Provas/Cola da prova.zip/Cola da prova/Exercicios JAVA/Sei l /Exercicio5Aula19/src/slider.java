
import javax.swing.*;
import javax.swing.event.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
//changeListener é para quando voce altera algo e nao é notificado
public class slider extends JFrame implements ChangeListener{
    JSlider slider;
    JProgressBar progressbar;
    
    public slider(String titulo){
        super(titulo);
    }
    
    public void addslider(){
        slider = new JSlider();
        progressbar = new JProgressBar();
        slider.addChangeListener(this);
        if(slider.getValue() != progressbar.getValue()){
            progressbar.setValue(slider.getValue());
        }
        JPanel painel = new JPanel();
        painel.add(slider);
        painel.add(progressbar);
        this.add(painel);
        this.setSize(300,20);
        this.setBounds(400,300,300,400);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public static void main(String[] args){
        slider sl = new slider("Movendo slider");
        sl.addslider();
    }
    @Override
    public void stateChanged(ChangeEvent e) {
        if(e.getSource()==slider){
			if(slider.getValue()!=progressbar.getValue()){
				progressbar.setValue(slider.getValue());
			}
		}
    }
    
    
}
