/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class Horista extends EmpDomestica{
    private int HorasTrabalhadas;
    private float ValorPorHora;
    
    //Construtor
    public void setHoras(int Horas) {
        HorasTrabalhadas = Horas;
    }
    
    public void setValorH(int ValorH) {
        ValorPorHora = ValorH;
    }
    
    @Override
    public float getSalario() {
        return HorasTrabalhadas*ValorPorHora;
    }
    
}
