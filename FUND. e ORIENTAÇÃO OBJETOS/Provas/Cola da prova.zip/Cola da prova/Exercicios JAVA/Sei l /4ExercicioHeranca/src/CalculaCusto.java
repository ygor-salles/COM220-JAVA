/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class CalculaCusto {

    public static void main(String[] args) {
        Horista empregadaH = new Horista();
        Diarista empregadaD = new Diarista();
        Mensalista empregadaM = new Mensalista();

        empregadaH.setNome("Julia");
        empregadaH.setTelefone("2222-2222");
        empregadaH.setHoras(100);
        empregadaH.setValorH(3);

        empregadaD.setNome("Carla");
        empregadaD.setTelefone("3333-3333");
        empregadaD.setDias(10);
        empregadaD.setValorD(2);

        empregadaM.setNome("Barbara");
        empregadaM.setTelefone("1234-5678");
        empregadaM.setValorM(1);

        System.out.println("Nome " + empregadaH.getNome() + "\nTelefone " + empregadaH.getTelefone() + "\nSalario R$ " + empregadaH.getSalario() + "\n\n");
        System.out.println("Nome " + empregadaD.getNome() + "\nTelefone " + empregadaD.getTelefone() + "\nSalario R$ " + empregadaD.getSalario() + "\n\n");
        System.out.println("Nome " + empregadaM.getNome() + "\nTelefone " + empregadaM.getTelefone() + "\nSalario R$ " + empregadaM.getSalario() + "\n\n");
       
        if (empregadaH.getSalario() < empregadaD.getSalario() && empregadaH.getSalario() < empregadaM.getSalario()) {
            System.out.println("A Horista " + empregadaH.getNome() + " é mais barata, seu telefone é " + empregadaH.getTelefone());
            }
        if (empregadaD.getSalario() < empregadaH.getSalario() && empregadaD.getSalario() < empregadaM.getSalario()) {
            System.out.println("A Diarista " + empregadaD.getNome() + " é mais barata, seu telefone é " + empregadaD.getTelefone());
            }
        if (empregadaM.getSalario() < empregadaH.getSalario() && empregadaM.getSalario() < empregadaD.getSalario()) {
            System.out.println("A Mensalista " + empregadaM.getNome() + " é mais barata, seu telefone é " + empregadaM.getTelefone());
            }
    }
}

