/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class Diarista extends EmpDomestica {
    private int DiasTrabalhados;
    private float valorPorDiaria;
    
    //Construtor
    public void setDias(int Dias) {
        DiasTrabalhados = Dias;
    }
    
    public void setValorD(int ValorD) {
        valorPorDiaria = ValorD;
    }
    
    @Override
    public float getSalario() {
        return DiasTrabalhados*valorPorDiaria;
    }
}
