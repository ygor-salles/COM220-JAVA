/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class EmpDomestica {
    private String Nome = "";
    private String Telefone;
    
    public void setNome (String pNome) {
        Nome = pNome;
    }
    
    public void setTelefone (String pTelefone) {
        Telefone = pTelefone;
    }
    
    public String getNome() {
        return Nome;
    }
    
    public String getTelefone() {
        return Telefone;
    }
    
    public float getSalario() {
       return 0;
    }
}
