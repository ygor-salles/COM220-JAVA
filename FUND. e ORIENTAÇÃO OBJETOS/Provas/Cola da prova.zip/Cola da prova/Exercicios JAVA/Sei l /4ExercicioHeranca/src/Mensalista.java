/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class Mensalista extends EmpDomestica {
    private float valorMensalidade;
    
    //Construtor
    public void setValorM(int ValorM) {
        valorMensalidade = ValorM;
    }
    
    @Override
    public float getSalario() {
        return valorMensalidade;
    }
    
}
