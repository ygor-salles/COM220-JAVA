
import java.awt.event.*;
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class Menu extends JFrame implements MouseListener {

    public Menu(String titulo){
        super(titulo);
    }
    public void addJanela(){
        addMouseListener(this);
        this.setSize(300,300);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[] args){
        Menu men = new Menu("Menu Popup");
        men.addJanela();
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getButton() != 1){
            JPopupMenu popupmenu = new JPopupMenu("Menu Pop-UP");
            JMenuItem item1 = new JMenuItem("Item 1");
            item1.setMnemonic(KeyEvent.VK_S);
            popupmenu.add(item1);
            
            JMenuItem item2 = new JMenuItem("Item 2");
            item2.setMnemonic(KeyEvent.VK_S);
            popupmenu.add(item2);
            
            JMenuItem item3 = new JMenuItem("Item 3");
            item3.setMnemonic(KeyEvent.VK_S);
            popupmenu.add(item3);
            
            popupmenu.show(rootPane, e.getX(), e.getY());
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        //
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
