public class ProfessorHorista extends Professor {
    private Double salarioHora;

    public ProfessorHorista(String n, int m, int ch, Double sh){
        super(n,m,ch);
        this.salarioHora=sh;
        }
    
    public Double getSalarioHora(){
        return salarioHora;
    }
            
    public void setSalarioHora(Double sh){
        this.salarioHora = sh;
    }

     public Double getSalario(){
        return salarioHora;
    }
     
    @Override
    public String imprimirDados(){
        String resp = "Professor Horista\n";
        resp+="Nome:"+getNome()+"\n";
        resp+="Matricula:"+getMatricula()+"\n";
        resp+="Carga Horária:"+getCargaHoraria()+"\n";
        resp+="Salário Hora:"+getSalario()+"\n";
        resp+="Salario:"+getSalario()*getCargaHoraria()+"\n";
        return resp;
    }
}
