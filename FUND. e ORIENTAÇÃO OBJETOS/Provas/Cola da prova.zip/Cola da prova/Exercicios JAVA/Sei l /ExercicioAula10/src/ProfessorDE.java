public class ProfessorDE extends Professor{
    Double salario;

    public ProfessorDE(String n, int m, int ch, Double s){
        super(n,m,ch);
        this.salario=s;
    }
    
   public Double getSalario(){
        return salario;
    }
 
    @Override
    public String imprimirDados(){
        String resp = "Professor DE\n";
        resp+="Nome:"+getNome()+"\n";
        resp+="Matricula:"+getMatricula()+"\n";
        resp+="Caga Horária:"+getCargaHoraria()+"\n";
        resp+="Salario:"+getSalario()+"\n\n";
        return resp;
    }
}

