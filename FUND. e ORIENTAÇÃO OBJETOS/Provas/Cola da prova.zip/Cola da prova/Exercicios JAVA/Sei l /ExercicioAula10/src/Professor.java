public abstract class Professor {
    private String nome;
    private int matricula;
    private int cargaHoraria;
   // private Double salario;


    public Professor(String n, int m, int ch){
        setNome(n);    
        setMatricula(m);
        setCargaHoraria(ch);
    }

    public abstract String imprimirDados();

    public String getNome(){
        return nome;
    }

    public final void setNome(String n){
        this.nome = n;
    }

    public int getMatricula(){
        return matricula;
    }

    public final void setMatricula(int m){
        this.matricula = m;
    }

    public int getCargaHoraria(){
        return cargaHoraria;
    }

    public final void setCargaHoraria(int ch){
        this.cargaHoraria = ch;
    }
  /*  public Double getSalario(){
        return salario;
    }

    public final void setSalario(Double s){
        this.salario = s;
    } */
}
