
import java.util.ArrayList;

public class TestaProfessor{    
   private static ArrayList<Professor> professor = new ArrayList<Professor>();
    public static void main(String[] args){
  
        professor.add(new ProfessorDE("Márcia",1, 10, 1123.56));
        professor.add(new ProfessorDE("Marcelo",2, 20, 1200.00));
        professor.add(new ProfessorHorista("Joao",5, 20, 12.5));
        professor.add(new ProfessorHorista("Lucas",4, 12, 12.5));

        for (Professor p : professor){
            System.out.println(p.imprimirDados());
        }
    }
}
