package info.geral;
public class Util {
	public static final String MASCULINO = "M";
	public static final String FEMININO = "F";
	public static final int MIN_IDADE = 10;
	public static final int MAX_IDADE = 120;
	public static final String GRADUACAO = "Gradua��o";
	public static final String ESPECIALIZACAO = "Especializacao";
	public static final String MESTRADO = "Mestrado";
	public static final String DOUTORADO = "Doutorado";
	public static final String CC = "Ciencias da Computacao";
	public static final String SI = "Sistemas de Informacao";

}
