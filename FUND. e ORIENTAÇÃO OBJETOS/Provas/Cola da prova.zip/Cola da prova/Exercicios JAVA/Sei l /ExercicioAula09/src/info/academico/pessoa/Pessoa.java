package info.academico.pessoa;

import info.academico.Disciplina.Disciplina;
import info.geral.Util;

public abstract class Pessoa {
	protected String aNome = "";
	private String aEndereco = "", aSexo = "";
	private int aIdade = 0;
	protected Disciplina aDisc[];

	public Pessoa(String pNome, String pEndereco, String pSexo, int pIdade) {
		aNome = pNome;
		aEndereco = pEndereco;
		aSexo = pSexo;
		aIdade = pIdade;
	}

	public Pessoa(String pNome, String pEndereco, String pSexo, int pIdade,
			Disciplina pDisc[]) {
		this(pNome, pEndereco, pSexo, pIdade);
		aDisc = pDisc;
	}

	public Pessoa() {
	}
	public String getDescricao() {
		String mensagem = aNome + " reside na " + aEndereco + " e possui "
				+ aIdade + " anos de idade";
		if (aSexo.equalsIgnoreCase(Util.MASCULINO))
			return mensagem = "O Sr. " + mensagem;
		else
			return mensagem = "A Sra. " + mensagem;
	}
}