package info.academico.pessoa;

import info.academico.Disciplina.Disciplina;

public class Aluno extends Pessoa {
	private String aNomeCurso = "";

	public Aluno(String pNome, String pEndereco, String pSexo, int pIdade,
			String pNomeCurso) {
		super(pNome, pEndereco, pSexo, pIdade);
		aNomeCurso = pNomeCurso;
	}

	public Aluno(String pNome, String pEndereco, String pSexo, int pIdade,
			String pNomeCurso, Disciplina pDisc[]) {
		super(pNome, pEndereco, pSexo, pIdade, pDisc);
		aNomeCurso = pNomeCurso;
	}

	public Aluno() {
	}

	public String getDescricao() {
		String msg = "";
		Disciplina disc[] = super.aDisc;
		String disciplinas = "";
		disciplinas = getDisciplinasVetor(disc);
		msg = super.aNome;
		msg = msg + "\nCursa " + disciplinas + "\nem " + aNomeCurso;
		return msg;
	}

	private String getDisciplinasVetor(Disciplina[] disc) {
		String dp = "";
		for(int i = 0;i<disc.length;i++) dp += "\n"+disc[i].getDescricaoDisciplina(); 
		return dp;
	}

}
