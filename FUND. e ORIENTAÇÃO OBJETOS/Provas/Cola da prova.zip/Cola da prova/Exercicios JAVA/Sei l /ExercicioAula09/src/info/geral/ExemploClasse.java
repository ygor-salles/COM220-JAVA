package info.geral;
import info.academico.Disciplina.Disciplina;
import info.academico.pessoa.Aluno;


public class ExemploClasse {
	public static void main(String par[]) {
		Disciplina[] discCursadas = {
				new Disciplina("Programacao Orientada a Objetos", 60),
				new Disciplina("Programacao Funcional", 30),
				new Disciplina("Processos de Tomada de Decis�o", 60)
		};
		Aluno objAluno = new Aluno("Hipolito","R das Oliveiras 45", Util.MASCULINO, 20, Util.SI,discCursadas);
		System.out.println(objAluno.getDescricao());
	}
}