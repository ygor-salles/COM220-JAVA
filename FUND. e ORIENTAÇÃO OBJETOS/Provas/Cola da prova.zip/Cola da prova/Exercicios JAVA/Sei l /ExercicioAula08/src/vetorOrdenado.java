import javax.swing.*;

public class vetorOrdenado {

	public static void main(String[] args) {
		String buscarnumero;
		int numero, vet[] = new int[10];
		insere10vet(vet);
		ordenaBolha(vet);

		buscarnumero = JOptionPane.showInputDialog("Digite o Numero para buscar no vetor");

		numero = Integer.parseInt(buscarnumero);

		numero = buscaBinaria(vet, numero);

		if (numero == -1)
			JOptionPane.showMessageDialog(null, "Valor nao encontrado");
		else
			JOptionPane.showMessageDialog(null, "Valor encontrado na posiçao "
					+ numero + " do vetor");

		System.out.println("---------------------");
                imprime(vet);
	}

	public static int buscaBinaria(int[] array, int valor) {
		int esq = 0;
		int dir = array.length - 1;
		int valorMeio;

		while (esq <= dir) {
			valorMeio = (esq + dir) / 2;
			if (array[valorMeio] < valor) 
                        {
                            esq = valorMeio + 1;
			} else if (array[valorMeio] > valor) 
                        {
				dir = valorMeio - 1;
			} else 
                        {
				return valorMeio;
			}
		}
		return -1;
	}

	private static void imprime(int[] vet) {
		System.out.println("Valores no vetor:");
		for (int i = 0; i < 10; i++) {
			System.out.println(vet[i]);
		}

	}

	private static int[] insere10vet(int[] vet) {
                 
		for (int i = 0; i < 10; i++) {
                        String entrenum = JOptionPane.showInputDialog("Entre com o valor do vetor " + i);
			int num = Integer.parseInt(entrenum);
			vet[i] = num;
		}
		return vet;
	}

	private static void ordenaBolha(int[] vet) {
		for (int passagem = 1; passagem < vet.length; passagem++) {
			for (int elemento = 0; elemento < vet.length - 1; elemento++) {
				if (vet[elemento] > vet[elemento + 1])
					troca(vet, elemento, elemento + 1);
			}
		}
	}

	public static void troca(int array3[], int prim, int sec) {
		int elemento;
		elemento = array3[prim];
		array3[prim] = array3[sec];
		array3[sec] = elemento;
	}
}
