
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author Samantha
 */
public class calculadora extends JFrame implements ActionListener {

    JTextField texto;
    JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, bsoma, bmenos, bvezes, bdiv, bequal,benter;
    
    int valor1, y, result,operacao;

    public calculadora(String titulo) {
        super(titulo);
    }

    public void grid() {
        Container conteinerpainel = this.getContentPane();
        texto = new JTextField(5);
        texto.addActionListener(this);
        b1 = new JButton("1");
        b1.addActionListener(this);
        b2 = new JButton("2");
        b2.addActionListener(this);
        b3 = new JButton("3");
        b3.addActionListener(this);
        b4 = new JButton("4");
        b4.addActionListener(this);
        b5 = new JButton("5");
        b5.addActionListener(this);
        b6 = new JButton("6");
        b6.addActionListener(this);
        b7 = new JButton("7");
        b7.addActionListener(this);
        b8 = new JButton("8");
        b8.addActionListener(this);
        b9 = new JButton("9");
        b9.addActionListener(this);
        b0 = new JButton("0");
        b0.addActionListener(this);
        bsoma = new JButton("+");
        bsoma.addActionListener(this);
        bmenos = new JButton("-");
        bmenos.addActionListener(this);
        bvezes = new JButton("*");
        bvezes.addActionListener(this);
        bdiv = new JButton("/");
        bdiv.addActionListener(this);
        benter = new JButton("C");
        benter.addActionListener(this);
        bequal = new JButton("=");
        bequal.addActionListener(this);
        

        conteinerpainel.setLayout(new BorderLayout());
        conteinerpainel.add(texto, BorderLayout.PAGE_START);
        Container numeros = new Container();
        numeros.setLayout(new GridLayout(4, 3));
        numeros.add(b1);
        numeros.add(b2);
        numeros.add(b3);
        numeros.add(b4);
        numeros.add(b5);
        numeros.add(b6);
        numeros.add(b7);
        numeros.add(b8);
        numeros.add(b9);
        numeros.add(b0);
        numeros.add(bequal);
        numeros.add(benter);
        conteinerpainel.add(numeros);

        Container operacoes = new Container();
        operacoes.setLayout(new GridLayout(4, 1));
        operacoes.add(bsoma);
        operacoes.add(bmenos);
        operacoes.add(bvezes);
        operacoes.add(bdiv);
        conteinerpainel.add(operacoes, BorderLayout.LINE_END);


        setSize(250, 190);//tamanho do painel
        setLocation(500,300);//posiciona na tela
        setVisible(true);
        setBackground(Color.gray);// Muda a Cor de Fundo
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        calculadora calc = new calculadora("Calculadora");
        calc.grid();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bsoma) {
            valor1 = Integer.parseInt(texto.getText());
            operacao = 1;
        } else if (e.getSource() == bmenos) {
            valor1 = Integer.parseInt(texto.getText());
            operacao = 2;
            
        } else if (e.getSource() == bvezes) {
             valor1 = Integer.parseInt(texto.getText());
             operacao = 3;
        } else if (e.getSource() == bdiv) {
             valor1 = Integer.parseInt(texto.getText());
             operacao = 4;
        } else if(e.getSource() == bequal){
               switch(operacao)
               {
                   //somar
                   case 1:
                   {
                        operacao = 0;
                        texto.setText(Integer.toString(valor1 + Integer.parseInt(texto.getText())));
                   break;
                   }
                   //subtrair
                   case 2:
                   {
                       operacao=0;
                       texto.setText(Integer.toString(valor1 - Integer.parseInt(texto.getText())));
                       break;
                   }
                   //mult
                   case 3:
                   {
                       operacao=0;
                       texto.setText(Integer.toString(valor1 * Integer.parseInt(texto.getText())));
                       break;
                   }
                   //div
                   case 4:
                   {
                       operacao=0;
                       texto.setText(Integer.toString(valor1 / Integer.parseInt(texto.getText())));
                       break;
                   }
               }
        
        }else if (e.getSource() == benter) {
            texto.setText(null);
            
        } else if (e.getSource() == b1) {
             texto.setText("1");
        } else if (e.getSource() == b2) {
             texto.setText("2");
        } else if (e.getSource() == b3) {
             texto.setText("3");
        } else if (e.getSource() == b4) {
            texto.setText("4");
        } else if (e.getSource() == b5) {
            texto.setText("5");
        } else if (e.getSource() == b6) {
            texto.setText("6");
        } else if (e.getSource() == b7) {
            texto.setText("7");
        } else if (e.getSource() == b8) {
             texto.setText("8");
        } else if (e.getSource() == b9) {
             texto.setText("9");
        } else if (e.getSource() == b0) {
             texto.setText("0");
        }

    }

}
