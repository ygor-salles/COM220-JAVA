package exerc2;

public class Aluno {

    int codigo, idade;
    String nome, end;

    public Aluno(int pcodigo, String pnome, String pend, int pidade) throws Exception {
        codigo = pcodigo;
        nome = pnome;
        end = pend;
        setIdade(pidade);
    }

    public void setCodigo(int pcodigo) {
        codigo = pcodigo;
    }

    public void setEnd(String pend) {
        end = pend;
    }

    public void setNome(String pnome) {
        nome = pnome;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getEnd() {
        return end;
    }

    public String getNome() {
        return nome;
    }
    //trata uma execao para idade entre 15 e 90 anos
    public void setIdade(int pidade) throws Exception {
        if ((idade < 15) || (idade > 90)) {
            throw new Exception("A idade deve estar entre 15 e 90 anos.");
        }
        idade = pidade;
    }

    public int getIdade() {
        return idade;
    }
}
