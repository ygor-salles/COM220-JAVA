
import java.awt.BorderLayout;
import javax.swing.*;
import javax.swing.event.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Samantha
 */
public class Movendo extends JFrame implements ListSelectionListener {

    JList lista1, lista2;
    DefaultListModel list1, list2;

    public Movendo(String titulo) {
        super(titulo);
    }

    public void addcomponents(String[] l1, String[] l2) {
        //instanciando as listas dinamicas
        list1 = new DefaultListModel();
        list2 = new DefaultListModel();

        //adicionando os elemtentos l1 e l2 nas listas
        for (int i = 0; i < l1.length; i++) {
            list1.addElement(l1[i]);
        }
        for (int i = 0; i < l2.length; i++) {
            list2.addElement(l2[i]);
        }
        // Cria a lista passando o modelo (forma dinamica )como parametro
        lista1 = new JList(list1);
        lista1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lista1.setFixedCellWidth(100);//Tamanho da largura da lista
        lista1.setVisibleRowCount(5);
        lista1.addListSelectionListener(this);
        lista2 = new JList(list2);
        lista2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lista2.setFixedCellWidth(100);
        lista2.setVisibleRowCount(5);
        lista2.addListSelectionListener(this);

        JScrollPane scroll1 = new JScrollPane(lista1,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        JScrollPane scroll2 = new JScrollPane(lista2,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        JPanel painel = new JPanel();
        painel.add(scroll1);
        painel.add(scroll2);
        getContentPane().add(painel, BorderLayout.CENTER);
        this.pack();
        this.setBounds(500,400,400,500);
        this.setSize(500, 150);//Define o tamanho da largura e da altura do painel
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

    }

    public static void main(String[] args) {
        Movendo mv = new Movendo("Movendo de uma lista para outra");
        String[] l1 = {"Caio", "Samantha", "Sabrina", "Stephanie", "Junior"},
                l2 = {"Kelly", "Felipe", "Jonas", "Joao", "Kamy"};
        mv.addcomponents(l1, l2);
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (e.getSource() == lista1) {
            if (e.getValueIsAdjusting() == false) {
                int x = lista1.getSelectedIndex();
                if (x == -1) {
                    return;
                }
                list2.addElement(list1.getElementAt(x));
                list1.remove(x);
            }
        } else if (e.getValueIsAdjusting() == false) {
            int y = lista2.getSelectedIndex();
            if (y == -1) {
                return;
            }
            list1.addElement(list2.getElementAt(y));
            list2.remove(y);
        }
    }

}
