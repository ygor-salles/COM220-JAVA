/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula13;

/**
 *
 * @author Samantha
 */
public class Aluno {
    
    private int codigo;
    private String nome;
    private String endereco;
    
    public Aluno(int pcodigo, String pnome, String pendereco){
        codigo = pcodigo;
        nome = pnome;
        endereco = pendereco;
    }
    //Metodo de recuperação de informação
    public int getCodigo() {
        return codigo;
    }
    //Metodo de recuperação de informação  
    public String getNome() {
        return nome;
    }
    //Metodo de recuperação de informação
    public String getEndereco() {
        return endereco;
    }
    //Metodo de atribuiçao de informação
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    //Metodo de atribuiçao de informação
    public void setNome(String nome) {
        this.nome = nome;
    }
    //Metodo de atribuiçao de informação
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
}
