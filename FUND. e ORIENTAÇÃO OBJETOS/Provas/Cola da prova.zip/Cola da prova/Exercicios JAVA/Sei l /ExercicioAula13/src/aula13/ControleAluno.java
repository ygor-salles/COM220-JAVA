
package aula13;
/**
 *
 * @author Samantha
 */

import java.util.Vector;

public class ControleAluno {
    private Vector listaAluno = new Vector();
    private LimiteAluno objLimiteAluno;
    
    // Construtor da classe
    public ControleAluno(){
        objLimiteAluno = new LimiteAluno(this);
    }
    //Metodo responsavel por fazer inserção de um aluno no vetor;
    public void insereAluno(int pcodigo, String pnome, String pendereco){
        Aluno novo = new Aluno(pcodigo,pnome,pendereco);
        listaAluno.add(novo);  
    }
     //Metodo responsavel por excluir algum aluno
    public void excluiAluno(int pcodigo){
     for (int i = 0;i < listaAluno.size(); i++){
         if(pcodigo == ((Aluno) listaAluno.elementAt(i)).getCodigo())
         {
             listaAluno.removeElementAt(i);
         }
     }   
    }
    //Metodo responsavel por preparar um texto
    //contendo todas as informaloes de alunos cadastrados
    //para serem apresentadas ao usuario
    public String imprimeAluno(int pos){
           Aluno objAlun = (Aluno)listaAluno.elementAt(pos);
           String resultado = "Codigo: "+objAlun.getCodigo()+
                     "\nNome: "+objAlun.getNome()+
                     "\nEndereço: "+objAlun.getEndereco();
        return resultado;
    }
    //Metodo responsavel por preparar a apresentacao das informaçoes
    // de um determinado aluno
    public String imprimeAlunos(){
        String result="";
        for(int i=0;i < listaAluno.size();i++){
            result+= imprimeAluno(i)+"\n";
        }
        return result;
    }
    //Metodo principal responsavel apenas por criar um obj da 
    //classe ControleAluno
    public static void main(String args[]){
        new ControleAluno();
    }
}
