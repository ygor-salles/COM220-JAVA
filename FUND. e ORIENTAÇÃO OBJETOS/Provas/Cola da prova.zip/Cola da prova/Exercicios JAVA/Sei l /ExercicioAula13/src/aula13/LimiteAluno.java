/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula13;

/**
 *
 * @author Samantha
 */
import javax.swing.JOptionPane;

public class LimiteAluno {
    private ControleAluno ctrAluno;
    
    //Construtor da classe
    public LimiteAluno(ControleAluno objPControleAlun){
        ctrAluno = objPControleAlun;
        capturaDados();
    }
    //Responsavel pelo menu principal
    private void capturaDados(){
        int codigo=0;
        String nome="",endereco="";
        int op=0;
        do {
            op=Integer.parseInt(JOptionPane.showInputDialog("Cadastro de Alunos\n[1]Inserir Aluno\n[2]Excluir Aluno\n[3]Mostrar Alunos\n[4]Sair"));
            switch(op){
                case 1:
                    codigo = Integer.parseInt(JOptionPane.showInputDialog("Código do Aluno"));
                    nome = JOptionPane.showInputDialog("Nome do Aluno");
                    endereco = JOptionPane.showInputDialog("Endereço do Aluno");
                    insereAluno(codigo, nome, endereco);
                    break;
                case 2:
                    codigo = Integer.parseInt(JOptionPane.showInputDialog("Código do Aluno"));
                    excluirAluno(codigo);
                    break;
                case 3:
                    imprimeAlunos();
                    break;
		default:
                    System.exit(0);
            }
        }while ((op>0) && (op <4));
    }
    private void insereAluno(int codigo, String nome, String endereco) {
	ctrAluno.insereAluno(codigo, nome, endereco);
    }
    private void excluirAluno(int codigo) {
	ctrAluno.excluiAluno(codigo);
    }
    private void imprimeAlunos() {
	JOptionPane.showMessageDialog(null, ctrAluno.imprimeAlunos());
    }
    
}