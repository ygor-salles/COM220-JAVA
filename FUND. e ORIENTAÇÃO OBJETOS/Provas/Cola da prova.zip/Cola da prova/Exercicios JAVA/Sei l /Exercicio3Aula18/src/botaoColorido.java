import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;

public class botaoColorido extends JFrame implements ActionListener {
	JToggleButton botao;
	JPanel painel;

	public botaoColorido(String titulo) {
		super(titulo);
	}

	public void addBotao() {
		botao = new JToggleButton("Botao Colorir");
		botao.addActionListener(this);
		painel = new JPanel();
		painel.add(botao);
		this.add(painel);
		this.setSize(350, 150);
                this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		botaoColorido btCl = new botaoColorido("Painel Colorido");
		btCl.addBotao();
	}

    @Override
    public void actionPerformed(ActionEvent e) {
        Color newColor = JColorChooser.showDialog(null, "Tabela de Cores",Color.blue);
			painel.setBackground(newColor);
    }
}
