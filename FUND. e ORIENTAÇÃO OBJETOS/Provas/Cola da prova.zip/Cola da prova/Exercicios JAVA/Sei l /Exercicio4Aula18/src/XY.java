import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;
//através do MouseListener que eu dô alguma funcionalidade para o mouse. 
public class XY extends JFrame implements MouseListener {
	JPanel painel;
	JLabel cxtexto;
	String png = "src/mapa.png";
        
	public XY(String titulo) {
		super(titulo);
        }
	
	public void addComponents(){
		cxtexto = new JLabel(new ImageIcon(png));
		cxtexto.addMouseListener(this);
		painel = new JPanel();
		painel.add(cxtexto);
		this.add(painel);
		this.setSize(750,300);
                this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		XY pg = new XY("Posicao X Y");
		pg.addComponents();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		cxtexto.setText(e.getPoint().toString());
                System.out.println(e.getPoint().toString());	
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

}
