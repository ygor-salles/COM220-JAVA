package exercicio2;

/**
 *
 * @author Samantha
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ToggleButtons extends JFrame implements ItemListener {
    //ItemEvent, indica que um item de uma lista de opções foi selecionado

    JToggleButton botao1, botao2, botao3, botao4, botao5;

    public ToggleButtons(String titulo) {
        super(titulo);
    }

    public void addButton() {
        botao1 = new JToggleButton("Carro"); //o botao1 recebe o nome de carro
        botao2 = new JToggleButton("Moto");
        botao3 = new JToggleButton("Caminhao");
        botao4 = new JToggleButton("Onibus");
        botao5 = new JToggleButton("Bicileta");
        JPanel p = new JPanel();
        getContentPane().setLayout(new GridLayout(1, 3)); //cria uma grid para colocar os botoes um ao lado do outro
        getContentPane().add(botao1);
        getContentPane().add(botao2);
        getContentPane().add(botao3);
        getContentPane().add(botao4);
        getContentPane().add(botao5);

        botao1.addItemListener(this);//deixa os botoes para clique
        botao2.addItemListener(this);
        botao3.addItemListener(this);
        botao4.addItemListener(this);
        botao5.addItemListener(this);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(500,300,300,500);
        this.pack();
        this.setVisible(true);
    }

    public static void main(String[] args) {
        ToggleButtons botoes = new ToggleButtons("BOTOES");//a janela de botoes recebe como titulo BOTOES
        botoes.addButton();
    }

    @Override
    public void itemStateChanged(ItemEvent e) { 
        if (e.getSource() == botao1) {////seleciona o botao 1 se ele for clicado
            botao2.setSelected(false);
            botao3.setSelected(false);
            botao4.setSelected(false);
            botao5.setSelected(false);
        } else if (e.getSource() == botao2) {
            botao1.setSelected(false);
            botao3.setSelected(false);
            botao4.setSelected(false);
            botao5.setSelected(false);
        } else if (e.getSource() == botao3) {
            botao2.setSelected(false);
            botao1.setSelected(false);
            botao4.setSelected(false);
            botao5.setSelected(false);
        } else if (e.getSource() == botao4) {
            botao3.setSelected(false);
            botao2.setSelected(false);
            botao1.setSelected(false);
            botao5.setSelected(false);
        } else if (e.getSource() == botao5) {
            botao4.setSelected(false);
            botao3.setSelected(false);
            botao2.setSelected(false);
            botao1.setSelected(false);
        }
    }

}
