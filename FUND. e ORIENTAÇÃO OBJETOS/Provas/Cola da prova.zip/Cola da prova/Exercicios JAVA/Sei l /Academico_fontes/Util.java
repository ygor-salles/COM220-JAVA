
public class Util {

    public static final String MASCULINO = "M";
    public static final String FEMININO = "F";

    public static final int MIN_IDADE = 10;
    public static final int MAX_IDADE = 120;

    public static final String GRADUACAO = "Graduação";
    public static final String ESPECIALIZACAO = "Especialização";
    public static final String MESTRADO = "Mestrado";
    public static final String DOUTORADO = "Doutorado";

    public static final String CC = "Ciências da Computação";
    public static final String SI = "Sistemas de Informação";
}
