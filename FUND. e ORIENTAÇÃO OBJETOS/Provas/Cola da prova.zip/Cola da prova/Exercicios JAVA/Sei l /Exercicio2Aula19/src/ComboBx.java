
import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class ComboBx extends JFrame implements ActionListener{
    JComboBox combo;
    JTextField texto;
    
    public ComboBx(String titulo){
        super(titulo);
    }
    public void addcomponents(){
        JPanel painel = new JPanel();
        texto = new JTextField(20);
        combo = new JComboBox();
        combo.setPreferredSize( new Dimension(100,20) );//Largura e altura do combobox
        texto.addActionListener(this);
        painel.add(texto);
        painel.add(combo);
        this.add(painel);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(400, 300, 300, 400);//localizacao do painel
        this.setSize(500,90);//tamanho do painel
        this.setVisible(true);
        
    }
    public static void main(String[] args){
        ComboBx cmb = new ComboBx("Adicionar a lista de opcoes");
        cmb.addcomponents();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String texto1 = texto.getText();
		if (texto1.equals("")) {

		} else {
                    //adiciona o texto1 no combobox
			combo.addItem(texto1);
		}

		texto.setText(null);
    }
    
}
