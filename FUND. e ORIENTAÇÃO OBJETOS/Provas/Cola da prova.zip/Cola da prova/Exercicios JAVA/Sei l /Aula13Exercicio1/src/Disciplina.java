public class Disciplina {
	private int codigo;
	private String nome;
	private int cargaHoraria;

	public Disciplina(int pCodigo, String pNome, int pCargaHoraria) {
		codigo = pCodigo;
		nome = pNome;
		cargaHoraria = pCargaHoraria;
	}

	// M�todos de atribui��o
	public void setCodigo(int pCodigo) {
		codigo = pCodigo;
	}

	public void setNome(String pNome) {
		nome = pNome;
	}

	public void setCargaHoraria(int pCargaHoraria) {
		cargaHoraria = pCargaHoraria;
	}

	// M�todos de recupera��o
	public int getCodigo() {
		return codigo;
	}

	public String getNome() {
		return nome;
	}

	public int getCargaHoraria() {
		return cargaHoraria;
	}
}