import javax.swing.*;

public class LimiteDisciplina {
	private ControleDisciplina ctrDisc = new ControleDisciplina();

	// M�todo utilizado para inserir os dados (simulando uma tela decadastro)
	public void capturaDados() {
		ctrDisc.insereDisciplina(1, "Desenvolvimento OO", 108);
		ctrDisc.insereDisciplina(2, "Estrutura de dados", 60);
		ctrDisc.insereDisciplina(3, "Data Warehouse", 60);
	}

	// M�todo utilizado para imprimir a lista de disciplinas (simulandouma tela
	// de consulta)
	public void imprimeDisciplinas() {
		System.out.println(ctrDisc.imprimeDisciplinas());
	}

	// M�todo utilizado para imprimir uma disciplina espec�fica(simulando uma
	// tela de consulta)
	public void imprimeDisciplina(int pCodigo) {
		System.out.println(ctrDisc.imprimeDisciplina(pCodigo));
	}

	// M�todo principal da classe
	public static void main(String par[]) {
		LimiteDisciplina limDisc = new LimiteDisciplina();
		limDisc.capturaDados();
		limDisc.imprimeDisciplinas();
		System.out.println("-------------------");
		limDisc.imprimeDisciplina(2);
	}
}