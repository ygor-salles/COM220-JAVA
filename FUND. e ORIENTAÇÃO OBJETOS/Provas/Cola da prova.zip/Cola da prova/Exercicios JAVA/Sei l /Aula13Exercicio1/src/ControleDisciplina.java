import java.util.*;

public class ControleDisciplina {
	private Vector listaDisciplina = new Vector();

	// M�todo de inser��o
	public void insereDisciplina(int pCodigo, String pNome, int pCargaHoraria) {
		Disciplina disc = new Disciplina(pCodigo, pNome, pCargaHoraria);
		listaDisciplina.add(disc);
	}

	// M�todo de impress�o da lista de disciplinas
	public String imprimeDisciplinas() {
		String result = "";
		for (int intIdx = 0; intIdx < listaDisciplina.size(); intIdx++) {
			Disciplina disc = (Disciplina) listaDisciplina.elementAt(intIdx);
			result += imprimeDisciplina(disc.getCodigo());
		}
		return result;
	}

	public String imprimeDisciplina(int pCodigo) {
		for (int intIdx = 0; intIdx < listaDisciplina.size(); intIdx++) {
			if (((Disciplina) listaDisciplina.elementAt(intIdx)).getCodigo() == pCodigo) {
				return "C�digo: "
						+ ((Disciplina) listaDisciplina.elementAt(intIdx))
								.getCodigo()
						+ " Nome: "
						+ ((Disciplina) listaDisciplina.elementAt(intIdx))
								.getNome()
						+ " Carga horaria: "
						+ ((Disciplina) listaDisciplina.elementAt(intIdx))
								.getCargaHoraria()+"\n";
			}
		}
		return "";
	}
}