package aula11;

public class Carro extends TransporteTerrestre implements Motorizado, Conduzivel {
    int numeroCilindradas;
    
    public Carro(String nome, int np, int va, boolean p, String t, int nc){
       super(nome,np,va,p,t);
       numeroCilindradas=nc;
    }
    
    public void estarParado(boolean ParadoC){
        super.estaParado(ParadoC);
    }
      
    public void embrear(int marcha){
          marcha+=marcha;
      }
         
    @Override
    public void abastecer(int numLitros){
        numLitros +=numLitros;    
    }
    
    @Override
    public void curvar(float angulo){
        angulo+=angulo;
        System.out.println("Angulo"+angulo);
    } 
    
    @Override
     public void estacionar(boolean estacionar){
        super.estacionar(estacionar);
     }

  
    @Override
    public void ligaMotor(){
            System.out.println("Motor Ligado");
        }
          
    
     public String toString() {
         return ("\nNome: " +nome+ "\nNumero Passageiros: "
                 +numeroPassageiros+ "\nVelocidade: " 
                 +velocidadeAtual+ "\nParado: " 
                 +parado+ "\nTipo: "+tipo+
                 "\nNumero Cilindradas: "+numeroCilindradas);
     } 
    
}
