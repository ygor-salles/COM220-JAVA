package aula11;

public class Bicicleta extends TransporteTerrestre implements Conduzivel{
    int numeroRaios;
    
    public Bicicleta(String nome, int np, int va, boolean p, String t, int nr){
       super(nome,np,va,p,t);
       numeroRaios=nr;
    }
    
    public void estarParado(boolean ParadoB){
        super.estaParado(ParadoB);
    }
       
    @Override
    public void estacionar(boolean estacionarB){
        super.estacionar(estacionarB);
     }
        
    @Override
   public void curvar(float angulo){
        angulo+=angulo;
         System.out.println("Angulo"+angulo);
    }
   
     public void pedalar(boolean pedalar){
        if(pedalar==true){
            System.out.println("já esta pedalando");
        }
        else{
            pedalar=true;
            System.out.println("Começou a pedalar");
        }
          
    } 
    @Override
      public String toString() {
         return ("\nNome: " +nome+ "\nNumero Passageiros: "
                 +numeroPassageiros+ "\nVelocidade: " 
                 +velocidadeAtual+ "\nParado: " 
                 +parado+ "\nTipo: "+tipo+
                 "\nNumero Raios: "+numeroRaios);
     } 
}
