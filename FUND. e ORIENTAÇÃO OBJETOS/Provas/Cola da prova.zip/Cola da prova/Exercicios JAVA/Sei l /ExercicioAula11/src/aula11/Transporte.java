package aula11;

public abstract class Transporte {
    String nome;
    int numeroPassageiros, velocidadeAtual;
    boolean parado;

    public Transporte(String nome, int nump, int velocidadea, boolean p) {
        this.nome = nome;
        numeroPassageiros=nump;
        velocidadeAtual=velocidadea;
        parado=p;
    }    
    
    public boolean estaParado(boolean estaParado){ 
    if(estaParado==true)
        return true;
    else
        return false;
    }
     
  
    
}
