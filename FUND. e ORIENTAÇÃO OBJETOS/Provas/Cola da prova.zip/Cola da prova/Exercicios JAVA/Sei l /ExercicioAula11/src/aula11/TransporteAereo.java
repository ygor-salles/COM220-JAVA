package aula11;

public abstract class TransporteAereo extends Transporte{
    int altitudeAtual;
   
   public TransporteAereo(String nome, int nump, int velocidadea, boolean p, int alt) {
       super(nome,nump,velocidadea,p);
       altitudeAtual=alt;
    }
   
    public void subir(int metros){
        altitudeAtual +=metros;
    }
    
      public void descer(int metros){
        altitudeAtual -=metros;
    }
 
}
