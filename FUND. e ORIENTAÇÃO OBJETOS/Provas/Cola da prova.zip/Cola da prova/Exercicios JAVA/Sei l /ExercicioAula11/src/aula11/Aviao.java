package aula11;

public class Aviao extends TransporteAereo implements Motorizado,Conduzivel{
    int numeroMotores;
    
    public Aviao(String nome, int nump, int velocidadea, boolean p, int al, int nm){
       super(nome, nump, velocidadea, p, al);
       numeroMotores=nm;
    }
    
    public void estarParado(boolean Parado){
        super.estaParado(Parado);
    }
    
    @Override
    public void subir(int metros){
        super.subir(metros);
    }
    
    @Override
    public void descer(int metros){
        super.descer(metros);
    }
    
    @Override
    public void abastecer(int numeroLitros){
        numeroLitros +=numeroLitros;   
    }
    
    @Override
     public void curvar(float angulo){
        angulo+=angulo;
         System.out.println("Angulo"+angulo);
    }
       
 
    @Override
   public void ligaMotor() {
        System.out.println("Motor Ligado");
    }
  
    @Override
   public String toString() {
         return ("Nome: " +nome+ "\n Numero Passageiros: "+numeroPassageiros+ "\n Velocidade: " 
                 +velocidadeAtual+ "\nParado: " 
                 +parado+ "\nAltitude: "+altitudeAtual+
                 "\nNumero Motores: "+numeroMotores);
     } 
}
