package aula11;

public class Balao extends TransporteAereo {
    int pesoLargada;
    
    public Balao(String nome, int np, int va, boolean p, int alt, int nm, int pel){
       super(nome, np, va, p, alt);
       pesoLargada=pel;
    }
    
    public void estarParado(boolean Parado){
        super.estaParado(Parado);
    }
    
    @Override
    public void subir(int metros){
        super.subir(metros);
    }
    
    @Override
    public void descer(int metros){
        super.descer(metros);
    }
    
    public void largarPeso(float peso){
        pesoLargada-=peso;
    }
    
     public void aquecerAr(float temp){
        temp+=temp;
    }
    
}
    
     
       
