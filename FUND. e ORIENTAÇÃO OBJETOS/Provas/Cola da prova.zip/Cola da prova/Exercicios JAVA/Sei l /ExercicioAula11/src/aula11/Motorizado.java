package aula11;

public interface Motorizado {
    public abstract void ligaMotor();
    public abstract void abastecer(int numeLitros );
    
}
