package aula11;
import java.util.*;

public class Teste {
    public static void main(String[] args) {
    ArrayList<Motorizado>  A1 = new ArrayList<Motorizado>();
    A1.add(new Aviao("M1Aviao", 1, 1, false, 1, 1));
    A1.add(new Carro("M2Carro", 1, 1, false, "Carro", 1));
    ArrayList<Conduzivel>  A2 = new ArrayList<Conduzivel>();
    A2.add(new Aviao("C1Aviao", 1, 1, false, 1, 1));
    A2.add(new Carro("C2Carro", 1, 1, false, "Carro", 1));
    A2.add(new Bicicleta("C3Bicicleta", 1, 1, false, "Bicicleta", 1));
    
   
   for (int i = 0; i < A1.size(); i++) {  
       System.out.println(A1.toString());  
       }
   for (int i = 0; i < A2.size(); i++) {  
       System.out.println(A2.toString());  
       }
  /* for (Motorizado p : A1){
       p.ligaMotor();
       System.out.println(A1.toString());
       }
   
   for (Conduzivel p2 : A2){
      p2.curvar(50);
       System.out.println(A2.toString()); 
       }
   */
    }
    
}
