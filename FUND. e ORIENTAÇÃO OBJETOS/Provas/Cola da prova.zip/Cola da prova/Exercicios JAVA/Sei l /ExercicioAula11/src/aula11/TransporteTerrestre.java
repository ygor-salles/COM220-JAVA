package aula11;

public abstract class TransporteTerrestre extends Transporte{
    String tipo;
    
 public TransporteTerrestre(String nome, int np, int va, boolean p, String t){
       super(nome,np,va,p);
       this.tipo=t;
    }
   
   public void estacionar(boolean estacionar){
        if(estacionar==true){
            System.out.println("Esta Estacionado");
        }
        else{
            estacionar=true;
            System.out.println("Carro acaba de ser Estacionado");
        }   
    }
 }
