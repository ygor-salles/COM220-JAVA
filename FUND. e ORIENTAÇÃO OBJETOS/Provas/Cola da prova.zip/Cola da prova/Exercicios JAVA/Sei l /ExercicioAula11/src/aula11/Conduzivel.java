package aula11;

public interface Conduzivel {
     public abstract void curvar(float angulo); 
}
