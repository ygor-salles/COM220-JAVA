package main;

public class aplicacao {
	public static void main(String[] args) throws Exception {
		new ctrPrincipal();
	}
}
