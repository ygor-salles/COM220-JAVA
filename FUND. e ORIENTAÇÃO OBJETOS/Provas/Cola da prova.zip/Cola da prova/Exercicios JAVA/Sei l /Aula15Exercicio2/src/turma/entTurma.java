package turma;
import java.io.Serializable;
import java.util.Vector;

public class entTurma implements Serializable {
	private String strACodigoTurma = "";
	private String strANomeTurma = "";
	private String strACodigoDisicplina = "";
	private Vector VecAAlunos = new Vector();

	public String getCodigoTurma() {
		return strACodigoTurma;
	}

	public void setCodigoTurma(String strACodigoTurma) {
		this.strACodigoTurma = strACodigoTurma;
	}

	public String getNomeTurma() {
		return strANomeTurma;
	}

	public void setNomeTurma(String strANomeTurma) {
		this.strANomeTurma = strANomeTurma;
	}

	public String getCodigoDisicplina() {
		return strACodigoDisicplina;
	}

	public void setCodigoDisicplina(String strACodigoDisicplina) {
		this.strACodigoDisicplina = strACodigoDisicplina;
	}

	public Vector getVecAAlunos() {
		return VecAAlunos;
	}

	public void setVecAAlunos(Vector vecAAlunos) {
		VecAAlunos = vecAAlunos;
	}
}