package disciplina;
import java.io.Serializable;

public class entDisciplina implements Serializable {
	private String strACodigo = "";
	private String strANome = "";
	private String intCargaHoraria = "";
	
	public String getCodigo() {
		return strACodigo;
	}

	public String getIntCargaHoraria() {
		return intCargaHoraria;
	}

	public void setIntCargaHoraria(String intCargaHoraria) {
		this.intCargaHoraria = intCargaHoraria;
	}

	public void setCodigo(String strACodigo) {
		this.strACodigo = strACodigo;
	}

	public String getNome() {
		return strANome;
	}

	public void setNome(String strAnome) {
		this.strANome = strAnome;
	}

}
