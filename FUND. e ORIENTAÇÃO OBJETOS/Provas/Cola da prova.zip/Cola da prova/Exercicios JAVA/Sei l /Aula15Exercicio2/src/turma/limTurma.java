package turma;

import java.util.Vector;

import javax.swing.JOptionPane;

import disciplina.entDisciplina;

import estudante.ctrEstudante;
import estudante.entEstudante;

public class limTurma {
	private String strACodigoTurma = "";
	private String strANomeTurma = "";
	private String strACodDisciplina = "";
	private Vector vecAAlunosSelecionados = new Vector();
	private Vector vecADadosForm = new Vector();
	private ctrTurma ctrTur;

	public limTurma(ctrTurma param) {
		ctrTur = param;
	}

	public Vector montaForm(Vector listaDeAlunos, Vector listaDeDisciplinas)
			throws Exception {
		Vector result = new Vector();
		montaFormDadosTurma();
		montaFormDadosEstudante(listaDeAlunos);
		montaFormDadosDisciplina(listaDeDisciplinas);
		result.addElement(strACodigoTurma);
		result.addElement(strANomeTurma);
		result.addElement(strACodDisciplina);
		result.addElement(vecAAlunosSelecionados);
		return result;
	}

	private void montaFormDadosTurma() {
		strACodigoTurma = JOptionPane.showInputDialog("Codigo da Turma");
		strANomeTurma = JOptionPane.showInputDialog("Nome");
	}

	private void montaFormDadosDisciplina(Vector x) {
		String codigo = "";
		codigo = JOptionPane.showInputDialog("C�digo da Disciplina");
		for (int i = 0; i < x.size(); i++) {
			if (codigo.equals(((entDisciplina) x.elementAt(i)).getCodigo())) {
				strACodDisciplina = codigo;
			}
		}
	}

	private void montaFormDadosEstudante(Vector x) {
		int op = 0;
		String codigo = "";
		do {
			op = Integer
					.parseInt(JOptionPane
							.showInputDialog("Inserir Alunos na Turma\n[1]Inserir Aluno na Turma\n[2]Remover Aluno da Turma\n[3]Sair"));
			switch (op) {
			case 1:
				codigo = JOptionPane.showInputDialog("C�digo do Aluno");
				for(int i=0;i<x.size();i++){
					if(codigo.equals(((entEstudante)x.elementAt(i)).getCodigo())){
						vecAAlunosSelecionados.addElement(codigo);
					}
				};
				break;
			case 2:
				codigo = JOptionPane.showInputDialog("C�digo do Aluno");
				for(int i=0;i<x.size();i++){
					if(codigo==((entEstudante)x.elementAt(i)).getCodigo()){
						vecAAlunosSelecionados.removeElementAt(i);
					}
				}
				break;
			}
		} while ((op > 0) && (op < 3));
	}
}
