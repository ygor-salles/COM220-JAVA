package estudante;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

import javax.swing.JOptionPane;

import disciplina.entDisciplina;

public class ctrEstudante {
	private final String arquivo = "alunos.dat";
	private limEstudante objALimEstudante = null;
	private entEstudante objAEntEstudante = null;
	private String[] strADadosForm = { "", "", "" };
	private Vector vecAEstudante = new Vector();

	public ctrEstudante() {

	}

	public boolean cadEstudante() throws IOException {
		objALimEstudante = new limEstudante(this);
		strADadosForm = objALimEstudante.montaForm();
		cadastra();
		return true;
	}

	private void cadastra() throws IOException {
		objAEntEstudante = new entEstudante();
		objAEntEstudante.setCodigo(strADadosForm[0]);
		objAEntEstudante.setNome(strADadosForm[1]);
		objAEntEstudante.setMatricula(strADadosForm[2]);
		addVetor(objAEntEstudante);
		salva();
	}

	private void salva() throws IOException {
		serializaEstudante();
	}

	public void addVetor(entEstudante objAEntEstudante) {
		vecAEstudante.addElement(objAEntEstudante);
	}

	private void serializaEstudante() throws IOException {
		FileOutputStream objFileOS = new FileOutputStream(arquivo);
		ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
		objOS.writeObject(vecAEstudante);
		objOS.flush();
		objOS.close();
	}

	private Vector desserializaEstudante() throws Exception {
		Vector vet = new Vector();
		File objFile = new File(arquivo);
		if (objFile.exists()) {
			FileInputStream objFileIS = new FileInputStream(arquivo);
			ObjectInputStream objIS = new ObjectInputStream(objFileIS);
			vet = (Vector) objIS.readObject();
			objIS.close();
		}
		return vet;
	}

	public void visualizaEstudantes() throws Exception {
		vecAEstudante = getListaEstudantes();
		String result = "Codigo    Nome      Matr�cula\n";
		for (int i = 0; i < vecAEstudante.size(); i++) {
			result += ((entEstudante) vecAEstudante.elementAt(i)).getCodigo()
					+ "      "
					+ ((entEstudante) vecAEstudante.elementAt(i)).getNome()
					+ "      "
					+ ((entEstudante) vecAEstudante.elementAt(i))
							.getMatricula() + "\n";
		}
		JOptionPane.showMessageDialog(null, result, "Alunos",
				JOptionPane.INFORMATION_MESSAGE);
	}

	public Vector getListaEstudantes() throws Exception {
		vecAEstudante = desserializaEstudante();
		return vecAEstudante;
	}

	public void finalize() {

	}
}
