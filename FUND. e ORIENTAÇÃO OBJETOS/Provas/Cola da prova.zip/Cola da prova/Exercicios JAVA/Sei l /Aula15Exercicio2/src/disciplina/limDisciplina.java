package disciplina;

import javax.swing.JOptionPane;

public class limDisciplina {
	private ctrDisciplina ctrDis;

	public limDisciplina(ctrDisciplina param) {
		ctrDis = param;
	}

	public String[] montaForm() {
		String[] result = { "", "", "" };
		try {
			ctrDis.getListaDisciplinas();
			result[0] = JOptionPane.showInputDialog("C�digo da Disciplina");
			try{
				for(int i =0; i<ctrDis.getListaDisciplinas().size();i++){
					if(result[0].equals(((entDisciplina)ctrDis.getListaDisciplinas().elementAt(i)).getCodigo())){
						throw new Exception("C�digo de disciplina j� em uso");
					}
				}
				
			}catch (Exception xs){
				JOptionPane.showMessageDialog(null, xs.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
				return null;
			}
			result[1] = JOptionPane.showInputDialog("Nome da Disciplina");
			result[2] = JOptionPane
					.showInputDialog("Carga Hor�ria da Disciplina");
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, exc.getMessage(), "Erro",
					JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
}