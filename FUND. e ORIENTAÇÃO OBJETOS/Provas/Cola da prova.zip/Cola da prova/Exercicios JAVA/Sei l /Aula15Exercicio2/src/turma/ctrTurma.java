package turma;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

import javax.swing.JOptionPane;

import disciplina.entDisciplina;

import estudante.entEstudante;
import main.ctrPrincipal;

public class ctrTurma {
	private String arquivo = "turmas.dat";
	private entTurma objAEntTurma = null;
	private limTurma objALimTurma = null;
	private ctrPrincipal objCtrPrincipal = null;
	private Vector vecATurmas = new Vector();
	private Vector vecAListaEstudantes = new Vector();
	private Vector vecAListaDisciplinas = new Vector();
	private Vector vecADadosForm = new Vector();

	public ctrTurma(ctrPrincipal ctrPr) throws Exception {

		vecAListaEstudantes = (Vector)(ctrPr.getObjACtrEstudante())
				.getListaEstudantes();
		vecAListaDisciplinas = (Vector) ctrPr.getObjACtrDisciplina()
				.getListaDisciplinas();

	}

	public boolean cadTurma() throws Exception {
		objALimTurma = new limTurma(this);
		vecADadosForm = objALimTurma.montaForm(vecAListaEstudantes,
				vecAListaDisciplinas);

		cadastra();
		return true;

	}

	private void cadastra() throws IOException {
		objAEntTurma = new entTurma();
		objAEntTurma.setCodigoTurma((String) vecADadosForm.elementAt(0));
		objAEntTurma.setNomeTurma((String) vecADadosForm.elementAt(1));
		objAEntTurma.setCodigoDisicplina((String) vecADadosForm.elementAt(2));
		objAEntTurma.setVecAAlunos((Vector) vecADadosForm.elementAt(3));
		addVetor(objAEntTurma);
		salva();

	}

	private void salva() throws IOException {
		serializaTurma();
	}

	public void addVetor(entTurma objAEntTurma) {
		vecATurmas.addElement(objAEntTurma);
	}

	private void serializaTurma() throws IOException {
		FileOutputStream objFileOS = new FileOutputStream(arquivo);
		ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
		objOS.writeObject(vecATurmas);
		objOS.flush();
		objOS.close();

	}

	private Vector desserializaTurma() throws Exception {
		Vector vet = new Vector();
		File objFile = new File(arquivo);
		if (objFile.exists()) {
			FileInputStream objFileIS = new FileInputStream(arquivo);
			ObjectInputStream objIS = new ObjectInputStream(objFileIS);
			vet = (Vector) objIS.readObject();
			objIS.close();
		}
		return vet;
	}

	public void visualizaTurmas() throws Exception {
		vecATurmas = getTurmas();
		Vector alunos = new Vector();
		String result = "";
		for (int i = 0; i < vecATurmas.size(); i++) {
			result += "Codigo: "
					+ ((entTurma) vecATurmas.elementAt(i)).getCodigoTurma()
					+ "\nNome da Turma: "
					+ ((entTurma) vecATurmas.elementAt(i)).getNomeTurma()
					+ "\nC�digo da Disciplina: "
					+ ((entTurma) vecATurmas.elementAt(i))
							.getCodigoDisicplina() + "\n";
			result += "Alunos Matriculados\n";
			alunos = ((entTurma) vecATurmas.elementAt(i)).getVecAAlunos();
			for (int z = 0; z < alunos.size(); z++) {
				result += (String)alunos.elementAt(z)+"\n";
			}
			result += "\n";
		}
		JOptionPane.showMessageDialog(null, result, "Turmas",
				JOptionPane.INFORMATION_MESSAGE);
	}

	public Vector getTurmas() throws Exception {
		vecATurmas = desserializaTurma();
		return vecATurmas;
	}

	public void finalize() {

	}

}
