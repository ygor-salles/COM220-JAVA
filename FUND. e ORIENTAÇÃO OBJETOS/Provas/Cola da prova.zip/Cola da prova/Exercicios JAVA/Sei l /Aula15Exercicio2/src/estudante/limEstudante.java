package estudante;

import javax.swing.JOptionPane;

public class limEstudante {
	private ctrEstudante ctrEst;

	public limEstudante(ctrEstudante param) {
		ctrEst = param;
	}

	public String[] montaForm() {
		String[] result = {"","",""};
		try {
			ctrEst.getListaEstudantes();

			result[0] = JOptionPane.showInputDialog("C�digo do Estudante");
			result[1] = JOptionPane.showInputDialog("Nome do Estudante");
			result[2] = JOptionPane.showInputDialog("Matr�cula do Estudante");
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, exc.getMessage(), "Erro",
					JOptionPane.ERROR_MESSAGE);
		}
		return result;

	}
}