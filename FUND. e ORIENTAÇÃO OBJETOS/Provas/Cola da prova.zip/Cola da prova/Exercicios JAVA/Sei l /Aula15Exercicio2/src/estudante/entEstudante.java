package estudante;

import java.io.Serializable;

public class entEstudante implements Serializable {
	private String strACodigo = "";
	private String strANome = "";
	private String intAMatricula = "";

	public String getMatricula() {
		return intAMatricula;
	}

	public void setMatricula(String intAMatricula) {
		this.intAMatricula = intAMatricula;
	}

	public String getCodigo() {
		return strACodigo;
	}

	public void setCodigo(String strACodigo) {
		this.strACodigo = strACodigo;
	}

	public String getNome() {
		return strANome;
	}

	public void setNome(String strANome) {
		this.strANome = strANome;
	}

}
