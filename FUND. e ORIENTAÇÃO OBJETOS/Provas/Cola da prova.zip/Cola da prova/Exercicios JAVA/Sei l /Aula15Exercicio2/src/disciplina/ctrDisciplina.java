package disciplina;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

import javax.swing.JOptionPane;

import main.ctrPrincipal;

import disciplina.entDisciplina;
import estudante.entEstudante;

public class ctrDisciplina {
	private final String arquivo = "disciplinas.dat";
	private limDisciplina objALimDisciplina = null;
	private entDisciplina objAEntDisciplina = null;
	private String[] strADadosForm = { "", "", "" };
	private Vector ADisciplinas = new Vector();

	public ctrDisciplina() throws IOException {
	}

	private void cadastra() throws IOException {
		objAEntDisciplina = new entDisciplina();
		objAEntDisciplina.setCodigo(strADadosForm[0]);
		objAEntDisciplina.setNome(strADadosForm[1]);
		objAEntDisciplina.setIntCargaHoraria(strADadosForm[2]);
		addVector(objAEntDisciplina);
		salva();
	}

	public boolean cadDisciplina() throws Exception {
		objALimDisciplina = new limDisciplina(this);
		strADadosForm = objALimDisciplina.montaForm();
		cadastra();
		
		
		return true;
	}

	private void salva() throws IOException {
		serializaDisciplinas();
	}

	public void addVector(entDisciplina objAEntDisciplina) {
		ADisciplinas.addElement(objAEntDisciplina);
	}

	private void serializaDisciplinas() throws IOException {
		FileOutputStream objFileOS = new FileOutputStream(arquivo);
		ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
		objOS.writeObject(ADisciplinas);
		objOS.flush();
		objOS.close();
	}

	private Vector desserializaDisciplinas() throws Exception {
		Vector vet = new Vector();
		File objFile = new File(arquivo);
		if (objFile.exists()) {
			FileInputStream objFileIS = new FileInputStream(arquivo);
			ObjectInputStream objIS = new ObjectInputStream(objFileIS);
			vet = (Vector) objIS.readObject();
			objIS.close();
		}
		return vet;
	}

	public Vector getListaDisciplinas() throws Exception {
		ADisciplinas = desserializaDisciplinas();
		return ADisciplinas;
	}

	public void visualizaDisciplina() throws Exception {
		String result = "";
		ADisciplinas = getListaDisciplinas();
		result = "C�digo   Nome da Disciplina   Carga Hor�ria\n";
		for (int i = 0; i < ADisciplinas.size(); i++) {
			result +=
					((entDisciplina) ADisciplinas.elementAt(i))
					.getCodigo()
					+ "           "
					+ ((entDisciplina) ADisciplinas.elementAt(i)).getNome()
					+ "           "
					+ ((entDisciplina) ADisciplinas.elementAt(i))
							.getIntCargaHoraria()
					+ "\n";
		}
		JOptionPane.showMessageDialog(null, result,"Disciplinas",JOptionPane.INFORMATION_MESSAGE);
	}

	public void finalize() {

	}
}
