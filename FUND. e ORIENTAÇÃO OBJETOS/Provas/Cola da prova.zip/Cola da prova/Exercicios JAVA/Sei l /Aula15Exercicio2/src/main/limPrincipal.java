package main;

import javax.swing.JOptionPane;

import disciplina.ctrDisciplina;

public class limPrincipal {
	private ctrPrincipal ctrPri;
	
	public limPrincipal(ctrPrincipal ctrPrinci) throws Exception {
		ctrPri = ctrPrinci;
	}
	
	public int montaMenu() {
		int op = 0;
		op = Integer.parseInt(JOptionPane.showInputDialog("Sistema de Cadastro Acad�mico\n[1]Cadastrar Disicplinas\n[2]Cadastrar Alunos\n[3]Cadastrar Turmas\n[4]Exibir Alunos Cadastrados\n[5]Exibir Disciplinas Cadastradas\n[6]Exibir Turmas Cadastradas\n[7]Sair"));
		return op;
	}
}
