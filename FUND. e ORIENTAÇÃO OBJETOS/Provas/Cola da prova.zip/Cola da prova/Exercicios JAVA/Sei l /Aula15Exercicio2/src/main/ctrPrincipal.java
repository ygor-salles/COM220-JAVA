package main;
import java.io.IOException;

import turma.ctrTurma;
import disciplina.ctrDisciplina;
import disciplina.entDisciplina;
import estudante.ctrEstudante;
import estudante.entEstudante;

public class ctrPrincipal {
	private int intAOperacao = -1;
	
	private ctrDisciplina objACtrDisciplina = new ctrDisciplina();
	private limPrincipal objALimPrincipal;
	private ctrEstudante objACtrEstudante = new ctrEstudante();
	private ctrTurma objACtrTurma = new ctrTurma(this);;
	
	public ctrPrincipal() throws Exception{
		objALimPrincipal = new limPrincipal(this);
		intAOperacao = objALimPrincipal.montaMenu();
		run();
	}

	public ctrDisciplina getObjACtrDisciplina() throws Exception {
		objACtrDisciplina.getListaDisciplinas();
		return objACtrDisciplina;
	}

	public ctrEstudante getObjACtrEstudante() throws Exception {
		objACtrEstudante.getListaEstudantes();
		return objACtrEstudante;
	}

	public void run() throws Exception {
		if(intAOperacao == 1){
			cadDisciplina();
		}
		if(intAOperacao == 2){
			cadEstudante();
		}
		if(intAOperacao == 3){
			cadTurma();
		}
		if(intAOperacao == 4){
			objACtrEstudante.visualizaEstudantes();
		}
		if(intAOperacao == 5){
			objACtrDisciplina.visualizaDisciplina();
		}
		if(intAOperacao == 6){
			objACtrTurma.visualizaTurmas();
		}
		if(intAOperacao == 7){
			System.exit(0);
		}
		new ctrPrincipal();
	}

	private boolean cadDisciplina() throws Exception {
		objACtrDisciplina.cadDisciplina();
		return true;
	}

	private boolean cadEstudante() throws Exception {
		objACtrEstudante.cadEstudante();
		return true;
	}

	private boolean cadTurma() throws Exception {
		objACtrTurma.cadTurma(); 
		return true;
	}
	
	public void finalize() {

	}
}
