import java.awt.BorderLayout;
import javax.swing.*;
import javax.swing.event.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Samantha
 */
public class ExcluiItemLista extends JFrame implements ListSelectionListener {

    JList lista1;
    DefaultListModel list1;

    public ExcluiItemLista(String titulo) {
        super(titulo);
    }

    public void adicionacomponentes(String[] l1) {
        JPanel painel = new JPanel();
        //Adicionando dados na JList de forma dinâmica
        list1 = new DefaultListModel();
        //For é utilizado pra adicionar os itens da lista que se encontra na main, na lista de forma dinamica
        for (int i = 0; i < l1.length; i++) {
            list1.addElement(l1[i]);
        }
        // Cria a lista passando o modelo (forma dinamica )como parametro
        lista1 = new JList(list1);
        lista1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);//Um item apenas pode ser selecionado
        lista1.setFixedCellWidth(100);//Define a largura
        lista1.setVisibleRowCount(5);//Define quantos itens serao visiveis ate ter o row
        lista1.addListSelectionListener(this);
        
        // adicionar dados no list
        // ..
        //scroll
        JScrollPane scroll1 = new JScrollPane(lista1,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        painel.add(scroll1);
        getContentPane().add(painel, BorderLayout.CENTER);
        this.pack();
        this.setSize(300, 150);//Define o tamanho da largura e da altura do painel
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

    }

    public static void main(String[] args) {
        ExcluiItemLista x = new ExcluiItemLista("Excluir itens da Lista"); 
        //Define a lista de itens a serem apresentados 
        String[] l1 = {"Felipe", "Caio", "Maria", "Kelly", "Fernanda","Juliana","Junior",
                        "Cintia", "Sabrina", "Stephanie"};
        x.adicionacomponentes(l1);
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (e.getSource() == lista1) {
            if (e.getValueIsAdjusting() == false) {
                int x = lista1.getSelectedIndex();
                if (x == -1) {
                    return;
                } 
                // removendo o item "x" que foi selecionado da JLIST
                list1.remove(x);
            }
        } 
    }

}
