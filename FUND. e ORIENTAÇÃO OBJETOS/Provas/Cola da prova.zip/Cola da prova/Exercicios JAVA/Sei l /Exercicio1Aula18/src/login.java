
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class login extends JFrame implements ActionListener {
    JTextField texto;
    JTextField texto2;
    static Vector cadastro;
    
    public login(){
        super();
    }    
    public void addLogin(){
        JLabel lbl1 = new JLabel("Nome");
        JLabel lbl2 = new JLabel("Senha");
        texto = new JTextField(20);
        texto2 = new JPasswordField(20);
        JPanel p = new JPanel();
        texto.addActionListener(this);
        texto2.addActionListener(this);
        p.add(lbl1,0);
        p.add(texto,1);
        p.add(lbl2,2);
        p.add(texto2,3);
        this.add(p);
        this.setTitle("LOGIN");
        this.setBounds(500,300,300,500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.pack();       
    }
    public static void main(String[] args){
        login usuario = new login();
        usuario.addLogin();
        cadastro = new Vector();
        String[] usuario1 = { "caio", "123456"}, usuario2 = { "samy", "567890"}, usuario3 = { "KellySouza", "098765"},
                    usuario4 = { "joao", "654321"}, usuario5 = { "Maria", "24680"};
        cadastro.add(usuario1);
        cadastro.add(usuario2);
        cadastro.add(usuario3);
        cadastro.add(usuario4);
        cadastro.add(usuario5);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String [] tempLogin = {(String)texto.getText(),(String)texto2.getText()};
        for (int i = 0;i < cadastro.size();i++){
            String[] temp = (String[])cadastro.elementAt(i);
            if((tempLogin[0].equals(temp[0])&&(tempLogin[1].equals(temp[1])))){
                JOptionPane.showMessageDialog(null,"Usuário Cadastrada","Acesso Permitido",JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Usuário não cadastrado","Acesso Negado",JOptionPane.INFORMATION_MESSAGE);
    }
    
}
