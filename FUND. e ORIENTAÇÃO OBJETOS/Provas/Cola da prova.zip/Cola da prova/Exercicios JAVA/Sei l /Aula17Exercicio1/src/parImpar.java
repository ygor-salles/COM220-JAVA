/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class parImpar extends JFrame {

	public parImpar() {
		super();
                this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void windowClosing(WindowEvent arg0) {
		if (JOptionPane.showConfirmDialog(this,
				"Tem certeza que deseja fechar a janela?") == 0) {
			this.dispose();
		}

	}
	public static void main(String[] args) {
		parImpar X = new parImpar();
		int computador = (int) (Math.random() * 10);
		Object[] option = { "Par", "Ímpar" };
		Object opcao = JOptionPane.showInputDialog(X,"Escolha Par ou Ímpar", "Jogo de Azar contra o Computador",
				JOptionPane.QUESTION_MESSAGE, null, option, option[0]);
                int jogador = Integer.parseInt(JOptionPane.showInputDialog(X,"Escolha Valor"));
		int soma = computador + jogador;
		if (((String) opcao).equals("Par")) {
			if ((soma % 2) == 0) {
				JOptionPane.showMessageDialog(X, "Par" + "\nVocê: "
						+ jogador + "\nComputador: " + computador + "\nSoma: "
						+ soma + "\nParabéns você venceu","Resultado", JOptionPane.PLAIN_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(X, "Ímpar" + "\nVocê: "
						+ jogador + "\nComputador: " + computador + "\nSoma: "
						+ soma + "\nParabéns você venceu","Resultado",JOptionPane.PLAIN_MESSAGE);
			}
		} else if (((String) opcao).equals("Ímpar")) {
			if ((soma % 2) == 1) {
				JOptionPane.showMessageDialog(X, "Ímpar" + "\nVocê: "
						+ jogador + "\nComputador: " + computador + "\nSoma: "
						+ soma + "\nQue pena voce perdeu","Resultado",JOptionPane.PLAIN_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(X, "Par" + "\nVocê: "
						+ jogador + "\nComputador: " + computador + "\nSoma: "
						+ soma + "\nQue pena voce perdeu","Resultado",JOptionPane.PLAIN_MESSAGE);
			}
		}
                             
                
	}
}
