public class motocicleta extends veiculo {
	String estilo;

	public motocicleta(String marca, String cor, boolean motorLigado,
			String estilo) {
		this.marca = marca;
		this.cor = cor;
		this.motorLigado = motorLigado;
		this.estilo = estilo;
	}
}
