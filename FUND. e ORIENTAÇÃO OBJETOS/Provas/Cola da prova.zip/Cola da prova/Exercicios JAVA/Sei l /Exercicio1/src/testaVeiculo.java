import java.util.Scanner;

public class testaVeiculo {
	motocicleta m = null;
	carro c = null;

	public static void main(String args[]) {
		// motocicleta m;
		// carro c;
		new testaVeiculo();
		// leitura(m,c);
		// motocicleta m = new motocicleta("Kawasaki", "vermelha", false,
		// "custom");
		// carro c = new carro("Ferrari", "Preta", false, false);
		// mostraAtributo(m, c);
	}

	public testaVeiculo() {
		leitura();
		mostraAtributo();
	}

	private void leitura() {
		Scanner x = new Scanner(System.in);
		System.out.println("Qual a marca da moto?");
		String marca = x.next();
		System.out.println("Qual a cor moto?");
		String cor = x.next();
		System.out.println("Qual o estilo?");
		String estilo = x.next();
		System.out.println("O motor está ligado?");
		String estado = x.next();
		System.out.println("----------------------------");
		System.out.println("Qual a marca do carro?");
		String marcac = x.next();
		System.out.println("Qual a cor carro?");
		String corc = x.next();
		System.out.println("O porta-malas está cheio?");
		String portamalas = x.next();
		System.out.println("O motor está ligado?");
		String estadoc = x.next();

		if (estado.equals("sim"))
			m = new motocicleta(marca, cor, true, estilo);
		else
			m = new motocicleta(marca, cor, false, estilo);

		if (estadoc.equals("sim")) {
			if (portamalas.equals("sim"))
				c = new carro(marcac, corc, true, true);
			else
				c = new carro(marcac, corc, false, true);
		} else {
			if (portamalas.equals("sim"))
				c = new carro(marcac, corc, true, false);
			else
				c = new carro(marcac, corc, false, false);
		}
	}

	private void mostraAtributo() {
		System.out.println("-------------------Moto-------------------");
		System.out.println("Esta é um(a) " + m.marca + " " + m.cor + " "
				+ m.estilo);
		m.ligaMotor();
		m.desligaMotor();
		System.out.println("-------------------Carro------------------");
		System.out.println("Este é um(a) " + c.marca + " " + c.cor);
		c.ligaMotor();
		c.desligaMotor();
		c.enchePortaMalas();
		c.esvaziaPortaMalas();
	}

}