public class veiculo {
	String marca;
	String cor;
	boolean motorLigado;

	public void ligaMotor() {
		if (motorLigado == true)
			System.out.println("Motor j� est� ligado");
		else {
			this.motorLigado = true;
			System.out.println("Motor ligado");
		}
	}

	public void desligaMotor() {
		if (motorLigado == false)
			System.out.println("Motor j� est� desligado");
		else {
			motorLigado = false;
			System.out.println("Motor desligado");
		}
	}
}
