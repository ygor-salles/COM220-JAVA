public class carro extends veiculo {
	private boolean portaMalasCheio;

	public carro(String marca, String cor, boolean motorLigado,
			boolean portaMalasCheio) {
		this.marca = marca;
		this.cor = cor;
		this.motorLigado = motorLigado;
		this.portaMalasCheio = portaMalasCheio;
	}

	public void enchePortaMalas() {
		if (portaMalasCheio == true)
			System.out.println("Porta Malas já está Cheio");
		else {
			portaMalasCheio = true;
			System.out.println("Porta Malas foi Cheio");
		}
	}

	public void esvaziaPortaMalas() {
		if (portaMalasCheio == false)
			System.out.println("Porta Malas já estava vazio");
		else {
			portaMalasCheio = false;
			System.out.println("Porta Malas foi esvaziado");
		}
	}
}
