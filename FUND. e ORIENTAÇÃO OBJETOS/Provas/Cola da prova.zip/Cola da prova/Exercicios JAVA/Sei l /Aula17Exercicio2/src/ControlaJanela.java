/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ControlaJanela extends JFrame implements WindowListener {
	public ControlaJanela(String titulo) {
		super(titulo);
	}

	public void adicionaComponentes() {
		JPanel p = new JPanel();
                p.add(new JLabel("Ola mundo"));
		this.add(p);
		this.addWindowListener(this);
                this.setSize(300,200);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		ControlaJanela cj = new ControlaJanela("Controla Janela");
		cj.adicionaComponentes();
	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		System.out.println("Janela habilitada");

	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		if (JOptionPane.showConfirmDialog(this,
				"Tem certeza que deseja fechar a janela?") == 0) {
			this.dispose();
		}

	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		System.out.println("Desativou a janela");

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		System.out.println("Abriu a Janela");

	}
}

