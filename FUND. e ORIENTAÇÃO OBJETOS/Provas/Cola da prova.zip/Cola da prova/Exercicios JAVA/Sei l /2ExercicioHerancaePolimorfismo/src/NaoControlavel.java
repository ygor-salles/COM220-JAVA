/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class NaoControlavel extends Personagem {

    private String iaID;
// Constructor
    public NaoControlavel(String nomePersonagem, String iaID) {
        super(nomePersonagem);
        this.iaID = iaID;
    }

    @Override
    public String getNomePersonagem() {
        return "Personagem NÃO Controlável "
                + super.getNomePersonagem();
    }

    @Override
    public String getID() {
        return " Inteligencia Artifical do Tipo: " + iaID;
    }
}
