/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
import java.util.ArrayList;
public class TestaPersonagem {

    public static void main(String[] args) {
        ArrayList<Personagem> tipopersonagem = new ArrayList<Personagem>();
        tipopersonagem.add(new Controlavel("'Grul, o Bárbaro' ", "Pedro"));
        tipopersonagem.add(new NaoControlavel("'Adria' ", "Vendedora de Pocoes"));
        for(Personagem p : tipopersonagem){
            System.out.println (p.getNomePersonagem() + "" + p.getID());
        }                 
        }       
  }
