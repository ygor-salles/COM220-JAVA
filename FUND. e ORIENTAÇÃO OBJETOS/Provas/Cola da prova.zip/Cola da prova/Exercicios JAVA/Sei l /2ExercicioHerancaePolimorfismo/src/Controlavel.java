/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class Controlavel extends Personagem {

    private String jogadorID;
// Constructor
    public Controlavel(String nomePersonagem, String jogadorID) {
        super(nomePersonagem);
        this.jogadorID = jogadorID;
    }

    @Override
    public String getNomePersonagem() {
        return "Personagem Controlável " + super.getNomePersonagem();
    }

    @Override
    public String getID() {
        return " Nome do Jogador: "+ jogadorID;
    }
}
