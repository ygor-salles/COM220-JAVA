/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class Main {
    public static void main(String[] args){
    Ponto inicio=new Ponto(2,3);
    Ponto fim=new Ponto(5,5);
    Reta r = new Reta(inicio, fim);
    Reta r2 = new Reta(4,9,1,0);
    System.out.println(r2.toString());
    System.out.println(r.toString());
        System.out.println(r.tamanhoReta());
        System.out.println(r2.tamanhoReta());
    System.out.println(inicio.getX() + inicio.getY());
}    
}
