
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samantha
 */
public class Reta {
    private Ponto inicio;
    private Ponto fim;
    
    public Reta(){
    }
    public Reta(Ponto i, Ponto f){
        this.inicio=i;
        this.fim=f;
    }
    public Reta(int i1, int i2, int f1, int f2){
        Ponto i = new Ponto(i1,i2);
        Ponto f = new Ponto (f1,f2);
        this.inicio = i;
        this.fim = f;
    }
    
    @Override
    public String toString() { 
     return "Reta comeca em:"+getInicio()+" e termina em:"+getFim(); 
    } 
    
//falta atributos reta

    /**
     * @return the inicio
     */
    public Ponto getInicio() {
        return inicio;
    }

    /**
     * @param inicio the inicio to set
     */
    public void setInicio(Ponto inicio) {
        this.inicio = inicio;
    }

    /**
     * @return the fim
     */
    public Ponto getFim() {
        return fim;
    }

    /**
     * @param fim the fim to set
     */
    public void setFim(Ponto fim) {
        this.fim = fim;
    }
    
        public int getXInicio() {
        return this.inicio.getX();
    }

    /**
     * @param inicio the inicio to set
     */
    public void setXInicio(int inicio) {
        this.inicio.setX(inicio);
    }
    
    public int getYInicio() {
        return this.inicio.getY();
    }

    /**
     * @param inicio the inicio to set
     */
    public void setYInicio(int inicio) {
        this.inicio.setY(inicio);
    }
public int getXfinal() {
        return this.fim.getX();
    }

    /**
     * @param inicio the inicio to set
     */
    public void setXfinal(int fim) {
        this.fim.setX(fim);
    }
    public int getYfinal() {
        return this.fim.getY();
    }

    /**
     * @param inicio the inicio to set
     */
    public void setYfinal(int fim) {
        this.fim.setY(fim);
    }
    public void setXYinicial(int x, int y){
        this.inicio.setX(x);
        this.inicio.setY(y);
    }
    public void setXYfinal(int x, int y){
        this.fim.setX(x);
        this.fim.setY(y);
    }
    
    public double tamanhoReta(){
        int xi,xf,yi,yf;
        xi=this.getXInicio();
        xf=this.getXfinal();
        yi=this.getYInicio();
        yf=this.getYfinal();
        
        double t = Math.sqrt(((xf-xi)*(xf-xi))+((yf-yi)*(yf-yi)));
        return t;
    }
}
