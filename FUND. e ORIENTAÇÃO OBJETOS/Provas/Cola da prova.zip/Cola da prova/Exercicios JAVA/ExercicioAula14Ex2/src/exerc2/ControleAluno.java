package exerc2;

import java.util.Vector;

public class ControleAluno {

    private LimiteAluno limiteAluno;
    private Vector vetor = new Vector();

    public ControleAluno() {
        limiteAluno = new LimiteAluno(this);
    }

    public void insereAluno(int codigo, String nome, String end, int idade) throws Exception {
        Aluno aluno = new Aluno(codigo, nome, end, idade);
        vetor.add(aluno);
    }

    public boolean removerAluno(int codigo) {
        boolean result = false;
        for (int i = 0; i < vetor.size(); i++) {
            Aluno obj = (Aluno) vetor.elementAt(i);
            if (codigo == obj.getCodigo()) {
                vetor.remove(i);
                result = true;
            }
        }
        return result;
    }

    public String imprimeAluno(int codigo) {
        String result = "";
        for (int i = 0; i < vetor.size(); i++) {
            Aluno aluno = (Aluno) vetor.elementAt(i);
            if (aluno.getCodigo() == codigo) {
                result = "Código: " + aluno.getCodigo()
                        + " Nome: " + aluno.getNome()
                        + " Idade: " + aluno.getIdade()
                        + " Endereço: " + aluno.getEnd();
            }
        }
        return result;
    }

    public String imprimeAlunos() {
        String result = "";
        for (int i = 0; i < vetor.size(); i++) {
            Aluno aluno = (Aluno) vetor.elementAt(i);
            result += "Código: " + aluno.getCodigo()
                    + " Nome: " + aluno.getNome()
                    + " Idade: " + aluno.getIdade()
                    + " Endereço: " + aluno.getEnd() + "\n";
        }
        return result;
    }
}
