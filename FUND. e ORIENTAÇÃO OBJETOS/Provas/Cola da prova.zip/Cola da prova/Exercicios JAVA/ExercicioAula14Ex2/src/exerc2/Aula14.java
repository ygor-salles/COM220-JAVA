
package exerc2;

public class Aula14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ControleAluno controleAluno = new ControleAluno();
    }
}
