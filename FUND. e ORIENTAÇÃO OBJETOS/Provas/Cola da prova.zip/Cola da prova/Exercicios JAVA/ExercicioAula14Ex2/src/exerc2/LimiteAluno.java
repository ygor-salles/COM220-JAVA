package exerc2;

import javax.swing.JOptionPane;

public class LimiteAluno {

    ControleAluno controleAluno;

    public LimiteAluno(ControleAluno c) {
        this.controleAluno = c;
        capturaDados();
    }

    public void capturaDados() {
        int escolha = 0;
        do {
            do {
                try {
                    escolha = Integer.parseInt(JOptionPane.showInputDialog(
                            "Escolha uma opção do menu:\n"
                            + "[1] Cadastrar aluno\n"
                            + "[2] Remover aluno\n"
                            + "[3] Listar um aluno\n"
                            + "[4] Listar todos os alunos\n"
                            + "[5] Finalizar"));
                } catch (Exception exc) {
                }
            } while ((escolha < 1) || (escolha > 5));
            if (escolha != 5) {
                execEscolha(escolha);
            } else {
                System.exit(0);
            }
        } while (true);
    }

    private void execEscolha(int escolha) {
        switch (escolha) {
            case 1:
                cadastraAluno();
                break;
            case 2:
                removerAluno();
                break;
            case 3:
                int codigoProcura = Integer.parseInt(JOptionPane.showInputDialog("Informe o código:"));
                imprimeAluno(codigoProcura);
                break;
            case 4:
                imprimeAlunos();
                break;
            case 5:
                System.exit(0);
                break;
        }
    }

    private void cadastraAluno() {
        try {
            String nome, end;
            int codigo = Integer.parseInt(JOptionPane.showInputDialog("Informe o código:"));
            nome = JOptionPane.showInputDialog("Informe o nome:");
            int idade = Integer.parseInt(JOptionPane.showInputDialog("Informe a idade:"));
            end = JOptionPane.showInputDialog("Informe o endereço:");
            controleAluno.insereAluno(codigo, nome, end, idade);
        } catch (Exception exc) {
            JOptionPane.showMessageDialog(null, exc.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removerAluno() {
        boolean result = false;
        int codigoRemover = Integer.parseInt(JOptionPane.showInputDialog("Informe o código:"));
        result = controleAluno.removerAluno(codigoRemover);
        if (result == false) {
            JOptionPane.showMessageDialog(null, "O código " + codigoRemover + " não foi encontado!!",
                    "Remover Aluno",
                    JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "o Aluno de código " + codigoRemover + " foi removido com sucesso!!",
                    "Remover Aluno",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void imprimeAlunos() {
        JOptionPane.showMessageDialog(null,
                controleAluno.imprimeAlunos(),
                "Relação de Alunos",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void imprimeAluno(int codigo) {
        JOptionPane.showMessageDialog(null,
                controleAluno.imprimeAluno(codigo),
                "Informações do Aluno",
                JOptionPane.INFORMATION_MESSAGE);
    }
}