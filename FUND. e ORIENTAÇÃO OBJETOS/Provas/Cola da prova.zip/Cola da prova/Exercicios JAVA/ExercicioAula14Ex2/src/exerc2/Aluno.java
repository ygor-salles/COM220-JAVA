package exerc2;

public class Aluno {

    int codigo, idade;
    String nome, end;

    public Aluno(int codigo, String nome, String end, int idade) throws Exception {
        this.codigo = codigo;
        this.nome = nome;
        this.end = end;
        setIdade(idade);
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getEnd() {
        return end;
    }

    public String getNome() {
        return nome;
    }

    public void setIdade(int idade) throws Exception {
        if ((idade < 15) || (idade > 90)) {
            throw new Exception("A idade deve estar entre 15 e 90 anos.");
        }
        this.idade = idade;
    }

    public int getIdade() {
        return idade;
    }
}
