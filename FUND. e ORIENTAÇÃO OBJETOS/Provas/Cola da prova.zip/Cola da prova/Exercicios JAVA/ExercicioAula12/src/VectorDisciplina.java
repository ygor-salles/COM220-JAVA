import java.util.*;

public class VectorDisciplina {

	private Vector vetorDisciplina = new Vector();

	public void insereDisciplina(int pCodigo, String pNome, int pCargaHoraria) {
		Disciplina disc = new Disciplina(pCodigo, pNome, pCargaHoraria);
		vetorDisciplina.add(disc);
	}

	public String imprimeDisciplinas() {
		String result = "";
		for (int i = 0; i < vetorDisciplina.size(); i++) {
			Disciplina disc = (Disciplina) vetorDisciplina.elementAt(i);
			result += imprimeDisciplina(disc.getCodigo());
		}
		return result;
	}

	public String imprimeDisciplina(int pCodigo) {
		for (int i = 0; i < vetorDisciplina.size(); i++) {
			if (((Disciplina) vetorDisciplina.elementAt(i)).getCodigo() == pCodigo) {
				return "Codigo: "
						+ ((Disciplina) vetorDisciplina.elementAt(i))
								.getCodigo()
						+ " Nome: "
						+ ((Disciplina) vetorDisciplina.elementAt(i)).getNome()
						+ " Carga horaria: "
						+ ((Disciplina) vetorDisciplina.elementAt(i))
								.getCargaHoraria() + "\n";
			}
		}
		return "";
	}

	public void excluiDisciplina(int codigo) {
		for (int i = 0; i < vetorDisciplina.size(); i++) {
			if (codigo == ((Disciplina) vetorDisciplina.elementAt(i))
					.getCodigo()) {
				vetorDisciplina.removeElementAt(i);
			}
		}
	}

}