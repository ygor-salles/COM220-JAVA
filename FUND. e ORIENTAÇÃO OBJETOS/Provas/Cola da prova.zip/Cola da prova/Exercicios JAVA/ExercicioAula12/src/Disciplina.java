public class Disciplina {
	private int codigo, cargaHoraria;
	private String nome = "";

	public Disciplina(){
	}
	
	public Disciplina(int pcodigo, String pnome, int pcargaHoraria) {
		setCodigo(pcodigo);
		setNome(pnome);
		setCargaHoraria(pcargaHoraria);
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCargaHoraria() {
		return cargaHoraria;
	}

	public void setCargaHoraria(int cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
