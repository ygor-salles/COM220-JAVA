import java.util.Vector;

import javax.swing.JOptionPane;

public class TestaDisciplina {
	static VectorDisciplina vdisc = new VectorDisciplina();
	
	public static void main(String[] args) {
		menu();
	}

	public static void menu() {
		int op = 0;

		int codigo = 0;
		String nome = "";
		int cargaHoraria = 0;

		do {
			op = Integer.parseInt(JOptionPane.showInputDialog("Cadastro de Disciplinas\n[1]Inserir Disciplina\n[2]Excluir Disciplina\n[3]Imprimir Disciplinas\n[4]Sair"));
			switch (op) {
			case 1:
				codigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo da Disciplina"));
				nome = JOptionPane.showInputDialog("Nome da Disciplina");
				cargaHoraria = Integer.parseInt(JOptionPane.showInputDialog("Carga Horaria da Disciplina"));
				inserirDisciplina(codigo,nome,cargaHoraria);
				break;
			case 2:
				codigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo da Disciplina")); 
				excluirDisciplina(codigo);
				break;
			case 3:
				imprimirDisciplinas();
				break;
			default:
				System.exit(0);
			}
		} while ((op > 0) && (op < 4));
		System.exit(0);
	}

	private static void inserirDisciplina(int codigo, String nome, int cargaHoraria) {
		vdisc.insereDisciplina(codigo,nome,cargaHoraria);
	}

	private static void excluirDisciplina(int codigo) {
		vdisc.excluiDisciplina(codigo);

	}

	private static void imprimirDisciplinas() {
		JOptionPane.showMessageDialog(null,vdisc.imprimeDisciplinas());
	}
}
