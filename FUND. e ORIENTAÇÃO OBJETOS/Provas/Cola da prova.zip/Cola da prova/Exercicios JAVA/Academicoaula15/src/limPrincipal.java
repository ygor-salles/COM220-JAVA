
	import javax.swing.*;

	public class limPrincipal {

		public int montaMenu(){
		   int escolha=-1;
		   String escolhaInformada = "";
		   do{
	          try {
	              escolhaInformada =
	                JOptionPane.showInputDialog(
	                     "Escolha uma opção do menu:\n"+
	                     "[1] Adiciona disciplina\n"+
	                     "[2] Adiciona estudante\n"+
	                     "[3] Adiciona turma\n"+
                             "[4] Lista disciplina\n"+
                             "[6] Lista estudante\n"+
                             "[8] Lista turma\n"+
	                     "[0] Finaliza");
	              escolha = Integer.parseInt(escolhaInformada);
	            } catch (Exception exc) {}
	        } while ((escolha < 0) || (escolha > 8));
		    return escolha;
		}		  
}
