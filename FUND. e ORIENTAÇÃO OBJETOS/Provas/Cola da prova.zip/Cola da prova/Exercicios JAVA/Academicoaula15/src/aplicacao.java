
public class aplicacao {

	public static void main(String[] args) {
		ctrPrincipal ctrPrinc = new ctrPrincipal();
		ctrPrinc.run();
	}
}
