import java.util.*;
import java.io.*;
import javax.swing.*;

public class ctrEstudante {
	
  private limEstudante objALimEstudante = new limEstudante();
  private entEstudante objAEntEstudante;
  private String[] aDadosForm;
  private Vector vecAEstudantes = new Vector();

  public ctrEstudante() throws Exception{
      desserializaEstudante();
  }
 
  public boolean cadEstudante(){
    objAEntEstudante = new entEstudante();    
    cadastra();
    objAEntEstudante.setCodigo(aDadosForm[0]);
    objAEntEstudante.setNome(aDadosForm[1]);
    addVetor(objAEntEstudante);
    return true;
  }
 
  private void cadastra(){
	aDadosForm = objALimEstudante.montaForm();
  }
  
 
   public String getEstudante(entEstudante objEstudante) {
        return "Código: " + objEstudante.getCodigo()
                + " Nome: " + objEstudante.getNome() + "\n";
    }
  
  public boolean listaEstudante(){
       String lista = "";
       entEstudante objAEntEstudante = null;
    
        for (int i = 0; i < vecAEstudantes.size(); i++) {
            objAEntEstudante = (entEstudante) vecAEstudantes.elementAt(i);
            lista += getEstudante(objAEntEstudante);
        }
        if (lista.equalsIgnoreCase("")) {
           JOptionPane.showMessageDialog(null, "Não tem alunos cadastrados");
        } else {
            JOptionPane.showMessageDialog(null, lista, "Relação de alunos", JOptionPane.INFORMATION_MESSAGE);
        }
   
                   
    return true;
  }
  
  public void addVetor(entEstudante pEst){
	  vecAEstudantes.add(pEst);
  }
  
  private void serializaEstudante() throws Exception{
	    FileOutputStream objFileOS = new FileOutputStream("estudantes.dat");
	    ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
	    objOS.writeObject(vecAEstudantes);
	    objOS.flush();
	    objOS.close();	  
  }
  
  private void desserializaEstudante() throws Exception {
	    File objFile = new File("estudantes.dat");
	    if (objFile.exists()) {
	      FileInputStream objFileIS = new FileInputStream("estudantes.dat");
	      ObjectInputStream objIS = new ObjectInputStream(objFileIS);
	      vecAEstudantes = (Vector)objIS.readObject();
	      objIS.close();
	    }	  
  }
  
  public Vector getListaEstudantes(){
	  return vecAEstudantes;
  } 
  
  public void finalize() throws Exception{
	  serializaEstudante();
  }
  
}