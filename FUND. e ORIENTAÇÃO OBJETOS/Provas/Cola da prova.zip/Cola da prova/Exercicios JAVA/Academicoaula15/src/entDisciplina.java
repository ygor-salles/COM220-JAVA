
import java.io.Serializable;

public class entDisciplina implements Serializable {
  private String strACodigo;
  private String strANome;


  public void setCodigo(String pCodigo) { strACodigo = pCodigo;  }

  public void setNome(String pNome) { strANome = pNome;  }

  public String getCodigo() {  return strACodigo;   }

  public String getNome() {   return strANome;   }

}
